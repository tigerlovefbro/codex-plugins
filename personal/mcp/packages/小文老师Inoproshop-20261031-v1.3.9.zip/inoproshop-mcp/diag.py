# -*- coding: utf-8 -*-
"""小文老师Inoproshop MCP 诊断工具：定位 AI 客户端不识别 MCP 的原因。"""
import io
import json
import os
import subprocess
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
print("=" * 56)
print(" 小文老师Inoproshop MCP 诊断")
print("=" * 56)
print(" 包目录   :", HERE)
vf = os.path.join(HERE, "version.txt")
ver = io.open(vf, "r", encoding="utf-8").read().strip() if os.path.isfile(vf) else "?"
print(" 版本     :", ver)

# 1) Claude 配置检查
apd = os.environ.get("APPDATA", "")
cands = [os.path.join(apd, "Claude", "claude_desktop_config.json"),
         os.path.join(apd, "Claude", "config.json")]
found = [c for c in cands if os.path.isfile(c)]
if found:
    for c in found:
        print(" 发现 Claude 配置:", c)
        try:
            data = json.load(io.open(c, "r", encoding="utf-8-sig"))
            entry = (data.get("mcpServers") or {}).get("inoproshop")
            if entry:
                print("   -> [OK] 已包含 inoproshop 配置：")
                print("        ", json.dumps(entry, ensure_ascii=False)[:220])
                args = entry.get("args") or []
                for a in args:
                    if a.endswith(".cmd"):
                        print("   -> 命令指向:", a)
                        if not os.path.isfile(a):
                            print("   -> [X] 注意：这个路径不存在！文件夹移动过，")
                            print("           请把文件夹放回原路径，或重跑 安装向导.cmd 选 1 重新配置")
            else:
                print("   -> [X] 没有 inoproshop 条目！")
                print("           解决办法：双击 安装向导.cmd，选 1（Claude Desktop）")
        except Exception as e:
            print("   -> [X] 配置解析失败:", e)
else:
    print(" 未发现 Claude 配置文件（本机未安装 Claude Desktop，")
    print(" 或从未跑过向导的自动配置）")

# 2) MCP 服务器握手测试
print("-" * 56)
print(" 正在自检 MCP 服务器（约 5 秒）...")
py = os.path.join(HERE, "runtime", "python", "python.exe")
if not os.path.isfile(py):
    py = sys.executable
env = dict(os.environ)
env["PYTHONIOENCODING"] = "utf-8"
try:
    p = subprocess.Popen([py, os.path.join(HERE, "mcp_server.py")],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, env=env, cwd=HERE)
    reqs = [json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                        "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                                   "clientInfo": {"name": "diag", "version": "1"}}}),
            json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})]
    p.stdin.write(("\n".join(reqs) + "\n").encode("utf-8"))
    p.stdin.flush()
    out = []
    deadline = time.time() + 25
    while time.time() < deadline and len(out) < 2:
        line = p.stdout.readline()
        if not line:
            break
        out.append(line.decode("utf-8", "replace").strip())
    p.stdin.close()
    try:
        p.wait(timeout=5)
    except Exception:
        p.terminate()
    tools = None
    for l in out:
        try:
            o = json.loads(l)
            if o.get("id") == 2 and "result" in o:
                tools = len(o["result"].get("tools", []))
        except Exception:
            pass
    if tools:
        print(" [OK] 服务器握手成功，共 %d 个工具（MCP 本体没问题）" % tools)
        print("     问题在客户端配置/重启，见上方提示。")
    else:
        print(" [X] 服务器无响应。原始输出：")
        for l in out:
            print("     ", l[:160])
except Exception as e:
    print(" [X] 启动失败:", e)

print("=" * 56)
print(" 下一步：把本窗口整屏截图发给小文老师。")
try:
    input(" 按回车退出...")
except Exception:
    pass
