# 小文老师Inoproshop —— 让 AI 直接操作汇川 InoProShop 的 MCP 服务器

> 版本：1.3.0　适配：**InoProShop V1.10.0.3**（基于 CODESYS V3.5 SP11 内核 + ScriptEngine 3.5.11.10）
>
> 无需“训练”任何模型：把本目录发给同事，按本文档配置一次，他的 AI（Claude Desktop / Cline / DeepSeek Harness 等任何支持 MCP 的客户端）即可直接新建工程、编写 ST 程序、编译、改代码。

## 🚀 傻瓜式上手（给同事看这个）

**不想看长文档？看《[傻瓜操作指南.md](傻瓜操作指南.md)》——三步搞定：**

1. 解压到 `C:\inoproshop-mcp`
2. 双击 `安装向导.cmd`，按提示选客户端（Claude Desktop 全自动配置），看到 ✔ 自检通过
3. 重启 AI 客户端，说一句“用 inoshop_demo_bubble_sort 演示一下”

---

## 1. 工作原理

```
AI (MCP 客户端)
   │  stdio JSON-RPC
   ▼
mcp_server.py  (本机 Python 3.8+，纯标准库，无需 pip 安装任何包)
   │  写 JSON 请求文件
   ▼
bridge/inoproshop_bridge.py  ← 由 InoProShop 内部脚本引擎执行
   │  ScriptEngine API (projects / system / PouType …)
   ▼
InoProShop IDE（自动启动：InoProShop.exe --profile=... --runscript=bridge）
```

- 桥接脚本运行在 InoProShop 自带的嵌入式 Python（2.7.7）中，通过官方 ScriptEngine 对象模型操作 IDE；
- MCP 服务器与桥接之间用临时目录下的 JSON 文件队列通信（`%TEMP%\inoshop-mcp\`），无端口、无网络、安全稳定；
- MCP 服务器会在需要时自动启动/重启 InoProShop（默认先结束旧实例），并等待桥接就绪。

### 1.1 界面生命周期（重要）

InoProShop 的脚本引擎机制：**脚本运行期间 IDE 界面会屏蔽鼠标操作**。因此桥接采用“按需运行 + 自动释放”策略：

```
AI 调用工具 → 桥接运行（IDE 界面暂时锁定，由 AI 操作）
    ↓ 空闲 3 分钟（可配置）或 AI 调用 inoshop_bridge_shutdown
自动保存工程 → 桥接脚本正常结束 → IDE 保持打开，界面恢复可交互（人可以继续点）
```

- AI 操作结束后无需任何动作，**3 分钟后界面自动恢复可点击**；想立即恢复就调用 `inoshop_bridge_shutdown`；
- 桥接退出后再调用其他工具：服务器发现 IDE 正被人工使用（无桥接）时**不会强杀窗口**，而是返回提示，让 AI 先提醒你保存工程，再调用 `inoshop_bridge_restart` 重新接入（该操作会关闭当前窗口，未保存修改会丢失）；
- 若你希望服务器无条件强杀重启，设置 `INOSHOP_AUTO_KILL_MANUAL=1`。

## 2. 部署步骤（同事机器上，一次性）

1. 复制整个 `inoproshop-mcp` 目录到本机，建议路径 **不含空格**，例如 `C:\inoproshop-mcp`；
2. 确认已安装：
   - InoProShop **V1.10.0.3**（其他版本请改 `INOSHOP_PROFILE` 为对应 profile 名，例如 `InoProShop(V1.9.1.6)`）；
   - ~~Python 3.8+~~ **无需安装**：包内 `runtime\python` 已内置 Python 3.12（向导会自动优先使用；若机器上另有可用 Python 也会自动识别）。
3. **整个包只有一个运行入口：`安装向导.cmd`**——
   - 双击运行 = 安装向导（全中文提示，结束会显示退出码）；
   - AI 客户端配置里调用时带 `--server` 参数 = 自动进入服务器模式。
4. 把下面的配置写入 AI 客户端的 MCP 配置：

**Claude Desktop**（`claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "inoproshop": {
      "command": "cmd",
      "args": ["/c", "C:\\inoproshop-mcp\\安装向导.cmd", "--server"],
      "env": {
        "INOSHOP_PROFILE": "InoProShop(V1.10.0.3)"
      }
    }
  }
}
```

**其他客户端（通用 stdio）**：见 `config-examples/generic_stdio_config.json`。

5. 重启 AI 客户端，在工具列表里应能看到 `inoshop_*` 开头的 22 个工具（另有 7 个知识资源与 1 个提示模板）。

### 2.1 退出码（DOS 窗口结束会显示，反馈问题时请一并提供）

| 退出码 | 含义 |
|---|---|
| 0 | 全部成功 |
| 1 | 向导内部错误（请截图反馈） |
| 2 | 环境检查未通过（缺 InoProShop/版本不符等） |
| 3 | MCP 自检失败 |
| 4 | 缺少可用的 Python 3.8 以上 |
| 5 | 安装包文件不完整（请完整解压） |

> 首次调用任何工具时，服务器会自动启动 InoProShop 并注入桥接脚本（冷启动约 1~3 分钟，期间 InoProShop 窗口会打开，属正常现象）。之后 IDE 常驻，操作即时。

## 2.5 启动环境检查（弹窗提示）

MCP 服务器**每次启动时会自动检查本机环境**：

| 检查项 | 要求 |
|---|---|
| 操作系统 | Windows |
| Python | 3.8 以上 |
| InoProShop | 已安装且 exe 存在 |
| InoProShop 版本 | **1.10.0.3**（前缀匹配，可用 `INOSHOP_REQUIRE_VERSION` 调整） |
| Profile | `InoProShop(V1.10.0.3).profile` 存在 |
| 桥接脚本 | 包内文件完整 |

**任何一项不符合 → 弹出 Windows 弹窗说明具体原因 → 服务器退出**（AI 客户端会显示"服务器断开"）。同事看到弹窗就能自己解决，不用猜。

- 跳过检查：`INOSHOP_ENV_CHECK=0`；
- 只写日志不弹窗（无人值守场景）：`INOSHOP_ENV_CHECK_POPUP=0`；
- AI 也可以主动调用 `inoshop_env_check` 工具查询详细报告（只报告、不退出）。

## 3. 快速演示：AI 一句话生成冒泡排序工程

在 AI 客户端里直接说：

> “用 inoshop_demo_bubble_sort 在 D:\Work\BubbleSortDemo.project 创建一个冒泡排序工程”

工具会自动完成：基于汇川 AM600 演示模板创建工程 → 新建冒泡排序功能块 `BubbleSort`（ST 语言，`arrIn` 输入数组 → `arrOut` 升序输出）→ 把任务程序 `POU1` 改写为调用者（`data` 数组 `[5,3,8,1,9,2,7,4,6,0]` 升序排序到 `sorted`）→ **编译验证** → 保存，并返回编译日志（应显示 `0 错误, 0 警告`）。

分步操作（等价）：

```
1. inoshop_project_create { "path": "D:\\Work\\BubbleSortDemo.project", "template": "standard" }
2. inoshop_pou_create { "name": "BubbleSort", "type": "FunctionBlock",
     "declaration": "FUNCTION_BLOCK BubbleSort\nVAR_INPUT\n\tarrIn : ARRAY[0..9] OF INT;\nEND_VAR\nVAR_OUTPUT\n\tarrOut : ARRAY[0..9] OF INT;\n\tdone : BOOL;\nEND_VAR\nVAR\n\ti, j : INT;\n\ttmp : INT;\nEND_VAR",
     "implementation": "arrOut := arrIn;\nFOR i := 0 TO 8 DO\n\tFOR j := 0 TO 8 - i DO\n\t\tIF arrOut[j] > arrOut[j + 1] THEN\n\t\t\ttmp := arrOut[j];\n\t\t\tarrOut[j] := arrOut[j + 1];\n\t\t\tarrOut[j + 1] := tmp;\n\t\tEND_IF\n\tEND_FOR\nEND_FOR\ndone := TRUE;" }
3. inoshop_text_write { "object": "POU1", "part": "implementation", "text": "bs(arrIn := data, arrOut => sorted);", "mode": "replace" }
4. inoshop_build
5. inoshop_project_save
```

> 提示：CODESYS/InoProShop 只编译**被任务引用的 POU**。AI 新写的程序要能被编译验证，需写入已在任务配置中的程序（如模板的 `POU1`），或手动把新 POU 挂到任务后再编译。

## 3.5 让 AI 学会“作者的代码风格”（知识包）

本 MCP 内置了从作者实际工程（伺服FB 项目）归纳的**编码风格手册**和**原版代码模板**。同事的 AI 拿到 MCP 后即可：

- **复现作者代码**：读取模板资源直接照抄 Sv_FB / DUT 接口的完整写法；
- **按作者风格写新功能块**：按风格手册的规则（分层、命名前缀、步序状态机、互锁与安全约束、中文注释）设计新 FB。

三种访问方式（AI 会自动选择其一）：

| 方式 | 说明 |
|---|---|
| **提示模板** `create_fb_in_author_style` | 让 AI 说出“用 create_fb_in_author_style 帮我写一个变频器 FB”即可获得完整创作指引 |
| **资源** `style://coding-style` 等 7 个 | 客户端支持 resources 时直接可见可读 |
| **工具** `inoshop_style_guide` / `inoshop_style_template` | 兜底：任何客户端都能通过工具调用读取 |

内置资源清单：

```
style://coding-style                  作者编码风格手册（9 章）
template://sv-fb-declaration          Sv_FB 声明区（作者原版）
template://sv-fb-implementation       Sv_FB 实现区（8 业务步序状态机，作者原版）
template://dut-sv-interface           DUT_Sv_Interface 对外接口（作者原版）
template://dut-sm3-power              DUT_SM3_Power 单指令接口（作者原版）
template://instantiation-example      实例化接线示例（LD/ST + HMI 对接）
template://clock-1hz-example          简单 FB 示例（TON 秒脉冲）
```

典型对话（同事侧）：

> “读一下作者的编码风格，然后按他的风格在 2_类模板 里写一个变频器控制 FB：i 前缀命令、o 前缀状态、步序状态机、中文注释，写完实例化到 1_程序组织调用单元 并编译。”

AI 会自动：读风格手册 → 取模板 → 用 `inoshop_pou_create` 写代码 → `inoshop_build` 验证 → 保存。

## 4. 工具清单（22 个）

| 工具 | 用途 |
|---|---|
| `inoshop_bridge_status` | 查看 IDE/桥接状态 |
| `inoshop_bridge_restart` | 重启 InoProShop 接入自动化（⚠ 会关闭当前窗口，先保存） |
| `inoshop_bridge_shutdown` | 保存工程并结束桥接脚本，**IDE 保持打开、界面恢复可交互** |
| `inoshop_bridge_exit` | 完全退出 InoProShop IDE（关闭窗口） |
| `inoshop_project_create` | 从模板创建并打开工程（standard/empty 或模板归档路径） |
| `inoshop_project_open` | 打开已有 `.project` / `.projectarchive` |
| `inoshop_project_save` | 保存 / 另存为 |
| `inoshop_project_close` | 关闭工程 |
| `inoshop_project_info` | 工程信息（应用、设备） |
| `inoshop_object_tree` | 工程对象树 |
| `inoshop_object_find` | 按名称查找对象 |
| `inoshop_object_delete` | 删除对象 |
| `inoshop_pou_create` | 创建 POU（Program/Function/FunctionBlock），可同时写入声明+实现 |
| `inoshop_text_read` | 读取声明区/实现区文本 |
| `inoshop_text_write` | 写/改文本（整体替换、追加、查找替换、锚点插入；可自动编译+保存） |
| `inoshop_build` | 编译，返回错误/警告列表 |
| `inoshop_messages` | 读取当前编译消息 |
| `inoshop_script_run` | 在脚本引擎执行任意 Python 片段（高级操作，可访问 `projects/system/online/project/app`） |
| `inoshop_demo_bubble_sort` | 一键冒泡排序演示：建工程 → 创建功能块 → 改写任务程序 → 编译 → 保存 |
| `inoshop_style_guide` | 读取作者编码风格手册（按 topic 取章节或全文） |
| `inoshop_style_template` | 读取作者代码模板（Sv_FB/DUT 接口/实例化/简单 FB） |
| `inoshop_env_check` | 检查本机环境（Python/InoProShop 版本/Profile/文件完整性），返回逐项报告 |

## 5. 常见问题

**Q：启动时报“InoProShop.exe not found”？**
设置 `INOSHOP_EXE` 环境变量指向实际路径，例如 `D:\Inovance Control\InoProShop\CODESYS\Common\InoProShop.exe`。

**Q：每次启动都弹 UAC 管理员授权？**
说明该机器注册表里有“以管理员身份运行”的兼容性标志。服务器默认给子进程加 `__COMPAT_LAYER=RUNASINVOKER` 绕过它，一般不会再弹窗。若仍弹出，可删除注册表项：
`HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers` 下指向 `InoProShop.exe` 的 `RUNASADMIN` 值（InoProShop 日常编程不需要管理员权限）。

**Q：InoProShop 打开后停在某个对话框（如设备选择向导）？**
脚本引擎的自动流程被模态对话框阻塞时会超时。使用 `inoshop_project_create`（模板创建）或 `inoshop_project_open`（打开完整工程）可避免向导；若手动操作 IDE 弹出了对话框，点掉后重试工具即可。

**Q：AI 操作期间我去点 IDE 界面没反应？**
正常现象：InoProShop 脚本引擎运行时界面会暂时锁定。AI 操作结束后约 3 分钟（或 AI 调用 `inoshop_bridge_shutdown`）自动保存并释放界面，之后即可正常点击。详见 1.1 节。

**Q：编译超时？**
首次编译设备代码较慢，可调大 `INOSHOP_REQUEST_TIMEOUT_MS`（默认 180000ms）与 `INOSHOP_START_TIMEOUT_MS`（默认 240000ms）。

**Q：同事的 InoProShop 版本不同？**
改 `INOSHOP_PROFILE` 为对应 profile 名（安装目录 `CODESYS\Profiles\*.profile` 里可查）。桥接与 MCP 本身兼容 CODESYS 内核 3.5.11 系列。

**Q：能不能连 PLC 在线操作？**
可以。用 `inoshop_script_run` 执行脚本引擎的 `online` 对象操作（登录、启停、读写变量），例如：

```python
result = app.online_application.login()
```

进阶在线工具可基于 ScriptEngine 官方 API 自行扩展（帮助文档见 InoProShop 安装目录 `CODESYS\Online Help\ScriptEngine.chm`）。

## 6. 环境变量一览

| 变量 | 默认值 | 说明 |
|---|---|---|
| `INOSHOP_EXE` | 自动检测（注册表） | InoProShop.exe 路径 |
| `INOSHOP_PROFILE` | `InoProShop(V1.10.0.3)` | profile 名 |
| `INOSHOP_BRIDGE_SCRIPT` | 目录内 bridge 脚本 | 桥接脚本路径 |
| `INOSHOP_BRIDGE_DIR` | `%TEMP%\inoshop-mcp` | 通信文件目录 |
| `INOSHOP_START_TIMEOUT_MS` | 240000 | IDE+桥接就绪等待 |
| `INOSHOP_REQUEST_TIMEOUT_MS` | 180000 | 单次操作超时 |
| `INOSHOP_KILL_EXISTING` | 1 | 重启桥接前先结束旧 InoProShop |
| `INOSHOP_IDLE_EXIT_MS` | 180000 | 桥接空闲多久后自动保存并释放界面（3 分钟；0=禁用） |
| `INOSHOP_AUTO_KILL_MANUAL` | 0 | 1=IDE 被人工使用时也强制重启桥接；0=返回提示不杀窗口 |
| `INOSHOP_COMPAT_LAYER` | `RUNASINVOKER` | 子进程兼容层覆盖（置空禁用） |
| `INOSHOP_ENV_CHECK` | 1 | 启动环境检查开关（0=跳过） |
| `INOSHOP_ENV_CHECK_POPUP` | 1 | 环境不符合时弹窗提示（0=只写日志） |
| `INOSHOP_REQUIRE_VERSION` | `1.10.0.3` | 要求的 InoProShop 版本（前缀匹配） |

## 7. 目录结构

```
inoproshop-mcp/
├── mcp_server.py                 MCP 服务器（纯标准库）
├── 安装向导.cmd                   唯一入口（二合一）：
│                                 双击=安装向导（全中文+退出码）
│                                 客户端带 --server 调用=服务器模式
├── setup_wizard.py               安装向导主体（环境检查/客户端配置/自检）
├── 傻瓜操作指南.md                 给同事的三步上手说明
├── bridge/
│   └── inoproshop_bridge.py      在 InoProShop 内运行的桥接脚本（Py2.7/3 双兼容）
├── docs/
│   └── style_guide.md            作者编码风格手册（9 章，AI 必读）
├── templates/                    作者原版代码模板（知识资源）
│   ├── sv_fb_declaration.st      伺服 FB 声明区
│   ├── sv_fb_implementation.st   伺服 FB 实现区（8 业务步序状态机）
│   ├── dut_sv_interface.st       对外接口 DUT
│   ├── dut_sm3_power.st          单指令接口 DUT
│   ├── instantiation_example.txt 实例化接线示例
│   └── clock_1hz_example.st      简单 FB 示例
├── config-examples/
│   ├── claude_desktop_config.json
│   └── generic_stdio_config.json
└── README.md
```

## 8. 安全说明

- MCP 服务器只在**本机 stdio** 上运行，不监听任何网络端口；
- 桥接与服务器之间仅通过本机临时目录的 JSON 文件通信；
- `inoshop_script_run` 能执行任意脚本引擎代码——请只在自己信任的 AI 客户端中使用；
- 默认会结束已运行的 InoProShop 再带桥接启动（`INOSHOP_KILL_EXISTING=1`），如有未保存工程请先保存。
