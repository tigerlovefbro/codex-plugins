# -*- coding: utf-8 -*-
"""
小文老师Inoproshop 安装向导（傻瓜式）
================================
自动检查环境 -> 自动配置 AI 客户端 -> 自检 -> 给出第一句话建议。
纯标准库，双击 安装向导.cmd 即可运行。
"""
import io
import json
import os
import subprocess
import sys


def _setup_console():
    """Console encoding: keep the native console codepage when it can print
    Chinese (GBK on Chinese Windows), otherwise fall back to UTF-8."""
    enc = (sys.stdout.encoding or "").lower().replace("-", "").replace("_", "")
    if enc in ("utf8", "gbk", "gb2312", "gb18030", "cp936"):
        return
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    try:
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


_setup_console()

HERE = os.path.dirname(os.path.abspath(__file__))
SERVER = os.path.join(HERE, "mcp_server.py")
WIZARD_CMD = os.path.join(HERE, u"安装向导.cmd")
PY = sys.executable

LINE = "=" * 60

# 退出码（与 安装向导.cmd 中的说明保持一致）
RC_OK = 0            # 全部成功
RC_INTERNAL = 1      # 向导内部错误（截图反馈）
RC_ENV_FAIL = 2      # 环境检查未通过
RC_SELFTEST_FAIL = 3  # MCP 自检失败
RC_NO_PYTHON = 4     # 缺少可用的 Python 3.8+

EXIT_TEXT = {
    RC_OK: u"全部通过",
    RC_INTERNAL: u"向导内部错误",
    RC_ENV_FAIL: u"环境检查未通过",
    RC_SELFTEST_FAIL: u"MCP 自检失败",
    RC_NO_PYTHON: u"缺少可用的 Python 3.8+",
    5: u"安装包文件不完整",
}


def package_version():
    vf = os.path.join(HERE, "version.txt")
    try:
        lines = io.open(vf, "r", encoding="utf-8").read().strip().splitlines()
        if lines and lines[0].strip():
            return lines[0].strip()
    except Exception:
        pass
    try:
        import re
        m = re.search(r'SERVER_VERSION = "([0-9.]+)"',
                      io.open(SERVER, "r", encoding="utf-8").read())
        if m:
            return u"v%s" % m.group(1)
    except Exception:
        pass
    return u"v1.0.0"


PKG_VERSION = package_version()

# 工作室宣传信息（DOS 窗口展示）
STUDIO_BANNER = (u"  ★ 小文老师Inoproshop MCP —— 安装向导（傻瓜式）\n"
                 u"  ★ 当前版本：%s（最新版请向小文老师确认）\n"
                 u"  ★ 十天学会PLC！工控培训 / 项目合作\n"
                 u"  ★ 业务电话：15929878510\n"
                 u"  ★ 官方主页：https://space.bilibili.com/455446576") % PKG_VERSION


def p(msg=""):
    print(msg)
    sys.stdout.flush()


def print_studio_banner():
    p(LINE)
    p(STUDIO_BANNER)
    p(LINE)


CLIENT_LABEL = u""


def write_receipt(rc):
    """生成《安装回执.txt》——客户反馈问题时直接发这个文件即可。"""
    import datetime
    import getpass
    import platform
    try:
        os_name = platform.system()
        rel = platform.release()
        if os_name == "Windows" and rel == "11":
            os_label = u"Windows 11"
        elif os_name == "Windows" and rel == "10":
            os_label = u"Windows 10"
        else:
            os_label = u"%s %s" % (os_name, rel)
        user = u""
        try:
            user = getpass.getuser()
        except Exception:
            pass
        ino = u"未检测到"
        try:
            found = find_inoproshop()
            if found:
                ino = u" / ".join(sorted(set(d for d, _ in found)))
        except Exception:
            pass
        lines = [
            u"=" * 50,
            u" 小文老师Inoproshop MCP 安装回执",
            u"=" * 50,
            u" 安装日期 : %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            u" 电脑     : %s / %s" % (platform.node(), os_label),
            u" 当前用户 : %s" % user,
            u" 版本     : 小文老师Inoproshop %s" % PKG_VERSION,
            u" 退出代码 : %s (%s)" % (rc, EXIT_TEXT.get(rc, u"未知")),
            u" InoProShop: %s" % ino,
            (u" AI 客户端 : %s" % CLIENT_LABEL) if CLIENT_LABEL else u" AI 客户端 : 未记录",
            u"-" * 50,
            u" 遇到问题时，请把本文件直接发给小文老师，",
            u" 无需截图。",
            u"=" * 50,
        ]
        path = os.path.join(HERE, u"安装回执.txt")
        io.open(path, "w", encoding="utf-8").write(u"\r\n".join(lines))
        return path
    except Exception:
        return None


def ask(prompt, default=""):
    try:
        v = input(prompt).strip()
        return v if v else default
    except Exception:
        return default


def find_inoproshop():
    """Registry-based InoProShop detection (same logic as the server)."""
    import winreg
    candidates = []
    seen = set()
    for root, view in ((winreg.HKEY_LOCAL_MACHINE, 0),
                       (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),
                       (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY)):
        for sub in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                    r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            try:
                key = winreg.OpenKey(root, sub, 0, winreg.KEY_READ | view)
            except OSError:
                continue
            try:
                i = 0
                while True:
                    try:
                        name = winreg.EnumKey(key, i)
                        i += 1
                    except OSError:
                        break
                    try:
                        k = winreg.OpenKey(key, name, 0, winreg.KEY_READ | view)
                        try:
                            display = winreg.QueryValueEx(k, "DisplayName")[0]
                        except OSError:
                            display = ""
                        if "InoProShop" in str(display):
                            try:
                                loc = winreg.QueryValueEx(k, "InstallLocation")[0]
                                cand = os.path.abspath(
                                    os.path.join(str(loc), "CODESYS", "Common", "InoProShop.exe"))
                                key_id = os.path.normcase(cand)
                                if key_id in seen:
                                    pass
                                elif os.path.isfile(cand):
                                    seen.add(key_id)
                                    candidates.append((str(display).strip(), cand))
                            except OSError:
                                pass
                    finally:
                        try:
                            winreg.CloseKey(k)
                        except Exception:
                            pass
            finally:
                try:
                    winreg.CloseKey(key)
                except Exception:
                    pass
    return candidates


def step_env_check():
    p(LINE)
    p(u"[1/4] 环境检查")
    p(LINE)
    ok = True
    # Python
    p(u"  Python：%s（%s）" % (PY, sys.version.split()[0]))
    if sys.version_info < (3, 8):
        p(u"  !!! Python 版本过低，请安装 3.8 以上")
        ok = False
    # InoProShop
    found = find_inoproshop()
    if found:
        for disp, exe in found:
            p(u"  InoProShop：%s -> %s" % (disp, exe))
    else:
        p(u"  !!! 未检测到 InoProShop 安装（请先安装 InoProShop V1.10.0.3）")
        ok = False
    # package files
    for f in (SERVER, WIZARD_CMD):
        if not os.path.isfile(f):
            p(u"  !!! 缺少文件：%s" % f)
            ok = False
    p(u"  安装包目录：%s" % HERE)
    if not ok:
        p(u"\n环境不完整，请先解决上面的 !!! 项，再重新运行本向导。")
        p(u"退出码 2（环境检查未通过）")
        return False
    p(u"\n  [OK]  环境检查通过")
    return True


def claude_config_paths():
    base = os.environ.get("APPDATA", "")
    return [os.path.join(base, "Claude", "claude_desktop_config.json"),
            os.path.join(base, "Claude", "config.json")]


def write_claude_config():
    p(LINE)
    p(u"[配置] Claude Desktop 自动配置")
    p(LINE)
    target = None
    for c in claude_config_paths():
        if os.path.isfile(c):
            target = c
            break
    if target is None:
        p(u"没有找到 Claude Desktop 的配置文件（可能未安装或从未启动过）。")
        p(u"将创建默认配置：%s" % claude_config_paths()[0])
        target = claude_config_paths()[0]
        os.makedirs(os.path.dirname(target), exist_ok=True)
    data = {}
    if os.path.isfile(target):
        try:
            data = json.load(io.open(target, "r", encoding="utf-8-sig"))
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    mcp = data.setdefault("mcpServers", {})
    entry = {
        "command": "cmd",
        "args": ["/c", WIZARD_CMD, "--server"],
    }
    if "inoproshop" in mcp and mcp.get("inoproshop") == entry:
        p(u"已配置过，无需重复操作。")
        return target
    backup = target + ".bak"
    try:
        if os.path.isfile(target):
            with io.open(target, "r", encoding="utf-8-sig") as f:
                with io.open(backup, "w", encoding="utf-8") as b:
                    b.write(f.read())
    except Exception:
        pass
    mcp["inoproshop"] = entry
    with io.open(target, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    p(u"  [OK]  已写入：%s" % target)
    p(u"  [OK]  原配置备份：%s" % backup)
    p(u"  重启 Claude Desktop 后生效。")
    return target


def write_dsh_config():
    """DeepSeek Harness 全自动配置：向 cordis.patch.yml 追加 mcp-client 补丁条目。"""
    home = os.path.expanduser("~")
    profiles_dir = os.path.join(home, ".dsh", "profiles")
    targets = []
    if os.path.isdir(profiles_dir):
        seen = set()
        for name in ("desktop", "web") + tuple(sorted(os.listdir(profiles_dir))):
            p = os.path.join(profiles_dir, name, "cordis.patch.yml")
            if p in seen:
                continue
            seen.add(p)
            if os.path.isfile(p):
                targets.append(p)
    if not targets:
        dsh_home = os.path.join(home, ".dsh")
        if not os.path.isdir(dsh_home):
            return None  # DSH 未安装
        p = os.path.join(profiles_dir, "desktop", "cordis.patch.yml")
        try:
            if not os.path.isdir(os.path.dirname(p)):
                os.makedirs(os.path.dirname(p))
            io.open(p, "a", encoding="utf-8").close()
        except OSError:
            return None
        targets = [p]
    path_yaml = WIZARD_CMD.replace("'", "''")
    entry = (u"\n- insert:\n"
             u"    - id: mcp-inoproshop\n"
             u"      name: \"@deepseek-ai/dsh-mcp-client\"\n"
             u"      config:\n"
             u"        transport: stdio\n"
             u"        serverName: inoproshop\n"
             u"        command: cmd\n"
             u"        args:\n"
             u"          - /c\n"
             u"          - '%s'\n"
             u"          - --server\n"
             u"        toolCallTimeoutMs: 900000\n") % path_yaml
    written = []
    for p in targets:
        try:
            text = io.open(p, "r", encoding="utf-8").read()
        except OSError:
            text = u""
        if "mcp-inoproshop" in text:
            written.append((p, u"已存在"))
            continue
        if text.strip() == u"":
            text = u"# DeepSeek Harness profile patch layer（由 小文老师Inoproshop 向导维护）\n[]\n"
        stripped = text.rstrip()
        if stripped.endswith("]"):
            new_text = stripped[:-1].rstrip() + entry + u"\n]\n"
        else:
            new_text = text.rstrip() + u"\n" + entry
        try:
            with open(p, "w", encoding="utf-8", newline="\n") as f:
                f.write(new_text)
            written.append((p, u"已写入"))
        except OSError as e:
            written.append((p, u"失败: %s" % e))
    return written


def print_dsh_guide():
    p(LINE)
    p(u"[配置] DeepSeek Harness")
    p(LINE)
    result = write_dsh_config()
    if result:
        p(u"  [OK] 已自动写入 DeepSeek Harness 的 MCP 配置：")
        for path, state in result:
            p(u"       %s  %s" % (path, state))
        p(u"  请完全退出 DeepSeek Harness 后重新打开（配置重启生效）。")
    else:
        p(u"  未检测到 DeepSeek Harness 安装（%USERPROFILE%\\.dsh 不存在）。")
        p(u"  请在 DeepSeek Harness 中手动添加 MCP 服务器（stdio）：")
        p(u"     名称：   inoproshop")
        p(u"     命令：   cmd")
        p(u"     参数：   /c \"%s\" --server" % WIZARD_CMD)


def print_generic_config():
    p(LINE)
    p(u"[配置] 其他客户端（Cline / Cherry Studio / 通义 等）")
    p(LINE)
    cfg = {
        "mcpServers": {
            "inoproshop": {
                "command": "cmd",
                "args": ["/c", WIZARD_CMD, "--server"],
            }
        }
    }
    text = json.dumps(cfg, ensure_ascii=False, indent=2)
    p(u"  把下面这段配置粘到你的客户端 MCP 设置里：")
    p("")
    p(text)
    p("")
    save_to = os.path.join(os.path.expanduser("~"), "Desktop", "inoproshop_mcp_config.json")
    try:
        with io.open(save_to, "w", encoding="utf-8") as f:
            f.write(text)
        p(u"  [OK]  也已保存到桌面：%s" % save_to)
    except Exception:
        pass


def self_test():
    p(LINE)
    p(u"[3/4] 自检（不会启动 InoProShop，只验证 MCP 服务器本身）")
    p(LINE)
    try:
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        proc = subprocess.Popen(
            [PY, SERVER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env, cwd=HERE)
        lines = []
        init = {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "wizard", "version": "1"}}}
        proc.stdin.write((json.dumps(init, ensure_ascii=False) + "\n").encode("utf-8"))
        proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"}) + "\n").encode("utf-8"))
        proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": 3, "method": "resources/list"}) + "\n").encode("utf-8"))
        proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": 4, "method": "prompts/list"}) + "\n").encode("utf-8"))
        proc.stdin.flush()
        import time
        deadline = time.time() + 30
        while time.time() < deadline and len(lines) < 4:
            line = proc.stdout.readline()
            if not line:
                break
            lines.append(json.loads(line.decode("utf-8", "replace").strip()))
        proc.stdin.close()
        try:
            proc.wait(timeout=10)
        except Exception:
            proc.terminate()
        tools = resources = prompts = None
        for l in lines:
            res = l.get("result", {})
            if "tools" in res:
                tools = len(res["tools"])
            if "resources" in res:
                resources = len(res["resources"])
            if "prompts" in res:
                prompts = len(res["prompts"])
        if tools is None:
            p(u"  !!! 自检失败（服务器无响应），请把本窗口截图发给发给你的人。")
            return False
        p(u"  [OK]  自检通过：%d 个工具 / %d 个知识资源 / %d 个提示模板" % (tools, resources or 0, prompts or 0))
        return True
    except Exception as e:
        p(u"  !!! 自检失败：%s" % e)
        return False


def main():
    print_studio_banner()
    if not step_env_check():
        p(u"\n[失败] 退出码 2（环境检查未通过）")
        write_receipt(RC_ENV_FAIL)
        ask(u"\n按回车退出...")
        sys.exit(RC_ENV_FAIL)
    p("")
    p(u"[2/4] 选择你的 AI 客户端：")
    p(u"   1) Claude Desktop        （自动写入配置，无需手动操作）")
    p(u"   2) DeepSeek Harness      （自动写入配置，零操作）")
    p(u"   3) 其他客户端             （Cline/Cherry Studio 等，给一段配置）")
    p(u"   0) 跳过配置，只做自检")
    choice = ask(u"   请选择 [1/2/3/0]，默认 3：", "3")
    global CLIENT_LABEL
    CLIENT_LABEL = {u"1": u"Claude Desktop（自动配置）", u"2": u"DeepSeek Harness（自动配置）",
                    u"3": u"其他客户端", u"0": u"跳过配置"}.get(choice, u"跳过配置")
    if choice == "1":
        write_claude_config()
    elif choice == "2":
        print_dsh_guide()
    elif choice == "3":
        print_generic_config()
    # choice "0"（或任意其他输入）：跳过配置，直接自检
    p("")
    if not self_test():
        p(u"\n[失败] 退出码 3（MCP 自检失败）")
        write_receipt(RC_SELFTEST_FAIL)
        ask(u"\n按回车退出...")
        sys.exit(RC_SELFTEST_FAIL)
    p("")
    p(LINE)
    p(u"[4/4] 完成！接下来：")
    p(u"   1. 完全退出并重新打开你的 AI 客户端；")
    p(u"   2. 新建对话，对 AI 说下面任意一句：")
    p(u"      「用 inoshop_demo_bubble_sort 在 D:\\Work 下创建一个冒泡排序工程演示一下」")
    p(u"      「读一下作者的编码风格，然后按他的风格写一个变频器功能块」")
    p(u"      「打开我的工程 <路径>，读一下里面的程序」")
    p(LINE)
    p(u"  ★ 第一次操作时 AI 会自动启动 InoProShop（约 2 分钟），属正常现象。")
    p(u"  ★ AI 干活时 InoProShop 界面会锁定（防止误点），干完活自动解锁。")
    p(u"  ★ 详细说明见同目录 README.md")
    p(u"  ★ 本向导退出码 0（成功）")
    p("")
    print_studio_banner()
    p(u"  装好了！打开你的 AI 客户端，对它说：")
    p(u"      「小文老师，帮我复现你的伺服FB」")
    p(u"      「用 inoshop_demo_bubble_sort 演示一下」")
    p(u"   第一次就能体验 AI 全自动生成 PLC 工程。")
    p(u"  （不会用？看视频课：https://space.bilibili.com/455446576）")
    p("")
    receipt = write_receipt(RC_OK)
    if receipt:
        p(u"  [OK] 安装回执已生成：%s" % receipt)
        p(u"  [OK] 遇到问题把《安装回执.txt》发给小文老师即可，无需截图。")
    ask(u"\n按回车退出...")


def _guard_entry():
    """Crash-proof entry: never let the console window flash-close."""
    if sys.version_info < (3, 8):
        try:
            print(u"[X] Python 版本过低：%s（需要 3.8 以上）" % sys.version.split()[0])
            print(u"    请安装 Python 3.8+：https://www.python.org/downloads/")
            print(u"[失败] 退出码 4（缺少可用的 Python 3.8 以上）")
            try:
                write_receipt(RC_NO_PYTHON)
            except Exception:
                pass
            input(u"按回车退出...")
        except Exception:
            pass
        sys.exit(RC_NO_PYTHON)
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        import traceback
        try:
            p(u"")
            p(u"[X] 向导运行出错：%s" % e)
            p(u"")
            p(traceback.format_exc())
            p(u"[失败] 退出码 1（向导内部错误）")
            write_receipt(RC_INTERNAL)
            ask(u"\n请截图上面的错误信息发给发给你的人。按回车退出...")
        except Exception:
            pass
        sys.exit(RC_INTERNAL)


if __name__ == "__main__":
    _guard_entry()
