# InoProShop 编码风格手册（作者工程标准）

> 本手册从作者实际工程（硅棒线21_Rst，伺服FB 项目）归纳而成。
> AI 在为本工程创建或修改代码时，必须遵守以下全部规范。

## 1. 工程分层（文件夹规范）

应用（Application）下固定四层，用"数字前缀_中文名"命名：

| 文件夹 | 职责 | 放什么 |
|---|---|---|
| `1_程序组织调用单元` | 业务与实例化层 | 主程序、启动程序、FB 的实例化 POU |
| `2_类模板` | 复用层（类库） | 通用功能块：Sv_FB、RfidReader、Clock_1HZ |
| `3_变量表` | 接口层 | 按设备划分的 GVL（HMI、变频器、Modbus、RFID…） |
| `4_数据类型DUT` | 数据结构层 | 接口结构体 DUT_Sv_Interface、DUT_SM3_* 等 |

## 2. 命名规范

| 前缀 | 含义 | 示例 |
|---|---|---|
| `i` | 输入形参（命令/设定） | `iPowerCmd`、`iJogCwCmd`、`iAbsPos` |
| `o` | 输出形参（状态/反馈） | `oPowerDone`、`oAbsBusy`、`oSvError` |
| `s` | FB 内部静态变量 | `sFbReady`、`sPowerDone`、`sAbsErr` |
| `Step…Work` | 步序变量（INT） | `StepPowerWork`、`StepJogWork` |
| `MC_<指令>_DB` | 库运动 FB 实例 | `MC_Power_DB`、`MC_Jog_DB` |
| `MC_<指令>_interface` | 该指令的接口实例 | `MC_Jog_interface` |
| `DUT_SM3_<指令>` | 单指令接口 DUT | `DUT_SM3_Jog`、`DUT_SM3_Abs` |
| 设备拼音缩写+编号 | FB 实例名 | `XHTSJ_1`（循环提升机）、`YZJ_1`（移栽机）、`MovCar`（小车） |
| `…_InterFace` | 对外大接口实例 | `XHTSJ_1_InterFace` |
| `HMI_<设备>_<功能>` | HMI 变量 | `HMI_car_RelCmd`、`HMI_Car_RelVel` |
| 全大写常量 | FB 内状态常量 | `STATUS_READY`、`DATA_CNT_FIRST_SEND_PACK` |

## 3. FB 骨架（新 FB 照此结构）

声明区按固定顺序分段，每段一行注释说明：

```
FUNCTION_BLOCK <名字>
VAR_INPUT      // 输入形参（只读）：所有命令与设定参数，i 前缀
VAR_OUTPUT     // 输出形参（只写）：所有状态与反馈，o 前缀
VAR_IN_OUT     // 输入输出形参（读写-共享地址）：如 AxisNumber:AXIS_REF_SM3
VAR            // 静态形参：
               //   1) 库 FB 实例（MC_*_DB）
               //   2) 各业务接口实例（MC_*_interface / *_InterFace）
               //   3) 静态状态区（s 前缀：sFbReady、sPowerDone、sXxxErr…）
               //   4) 步序区（StepXxxWork:INT，每业务一个）
               //   5) 防冷启动标志（如 PowerTemp:BOOL）
END_VAR
```

规则：
- 每个变量行尾用 `//中文说明` 注释；
- 输出状态要成对设计：Done/Err、Busy 单独；如 `oAbsBusy/oAbsDone/oAbsErr`；
- 对外总开关固定叫 `iFbEnable`，FB 就绪固定叫 `sFbReady`（输出 `oFbReady`）。

## 4. 步序状态机规范（核心）

- **每个业务一个独立 `CASE StepXxxWork OF`**，业务之间互不干扰；
- 步号约定（照此编排，新业务也按这个节奏）：

| 步号 | 含义 |
|---|---|
| 0 | 初始化/清理接口与静态标志 |
| 10 | 等待启动命令（含全部互锁条件） |
| 15/20 | 参数校验（不合法 → 900） |
| 30 | 点火（发 Execute/命令位 =1） |
| 40 | 复位命令位（=0） |
| 50 | 等待结果（oDone→成功路径；oErr→900） |
| 60~80 | 写成功标志 → 等待命令释放 → 清理 → 回 0 |
| 900 | 错误：写错误标志 sXxxErr:=1 |
| 910 | 等待命令释放 → 清错误标志 → 回 0 |

- **互锁写法**：进入业务的等待步（10），必须同时检查：
  `sFbReady=1 AND sPowerDone=1 AND 本业务命令=1 AND 其他全部命令=0 AND 其他业务 Step<=10（空闲）`；
- **使能业务独立**：使能(StepPowerWork)与清理(StepPowerClear)分两个 CASE；清理靠 `NOT sFbReady AND sPowerClear=0 AND PowerTemp=1` 触发（防冷启动）；
- 初始化只执行一次：`IF iFbEnable AND sFbReady=0 THEN … sFbReady:=1 END_IF`，并在初始化里校验外部命令全部为 0 才置就绪。

## 5. 安全约束（新业务不可省略）

1. 任何运动业务前置：`sFbReady=1 AND sPowerDone=1`；
2. 绝对定位必须先回原（`sHomeDone`），否则跳 900；
3. 参数合理性校验：速度必须在上下限内（iJogSpeedL/H），加减速与速度比例 1~10 倍；
4. 正反转命令互斥：同时按下 → 900 报警；
5. 暂停(Halt)/停止(Stop)完成后，**联动清理** Jog/Home/Abs/Rel 的接口命令位与步序（StepJogWork:=70 等），防误点火；
6. 接口映射统一放实现区末尾 `{region 接口映射}`，直接取轴状态（`AxisNumber.bError / fActPosition / fActVelocity`）。

## 6. 注释规范

- 全部用**中文**注释；
- 用 `{region 业务名} … {endregion}` 给实现区分段（接口区/初始化与清理/各业务/接口映射）；
- 每个步号必须写 `N://这一行做什么`；
- 库 FB 调用逐形参注释：`Enable:= MC_Power_interface.iFB_Enable, //FB使能//BOOL`；
- 实例声明行尾写用途全称：`XHTSJ_1: Sv_FB;//循环提升机实例背景`。

## 7. 接口规范（FB 与外部解耦）

- 每个运动单元对外一个大接口 DUT（如 `DUT_Sv_Interface`），HMI/上位机只读写接口，不直接碰 FB；
- 每个库运动指令一个细接口 DUT（`DUT_SM3_Power/Jog/Abs/Rel/Reset/Home/Halt/Stop`），字段命名沿用 i/o 前缀，与库 FB 形参一一对应；
- 接口默认值（如 Jog 速度 3.0、上下限 20/1.0）直接写在 DUT 初始值里。

## 8. 实例化规范

- 实例化集中在 `1_程序组织调用单元`；
- **LD（梯形图）版实例化面向维护工人**——信号接线直观可查，网络里保留中文注释与全称；
- ST 版实例化 POU 保留给高级用户/后续迁移；
- 每个实例行尾注释设备全称与用途。

## 9. 其他工程习惯

- 变频器等 Modbus 设备：控制字/速度字/频率字走 GVL 直接地址（`%QW47~52`），首扫程序写初始控制字（如 `%QW52:=6`）；
- 掉电保持用 PersistentVars（PERSISTENT RETAIN）；
- 启动任务用 TaskEventPreStart 挂 POU_FirstPg；
- 运动库固定用汇川定制版（SM3_Drive_ETC_Inovance 等），不混用 3S 原版。
