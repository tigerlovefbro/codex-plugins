# -*- coding: utf-8 -*-
"""
小文老师Inoproshop MCP Server
=====================
Model Context Protocol server that lets an AI assistant operate
InoProShop (CODESYS-based PLC IDE, Inovance) through its ScriptEngine API.

Architecture:

    AI (MCP client) -> this server (stdio JSON-RPC)
                    -> JSON request files
                    -> bridge script running inside InoProShop ScriptEngine
                    -> InoProShop object model (projects / system / ...)

Pure Python standard library. Requires Python 3.8+.
The InoProShop bridge script is executed by the IDE itself via
`InoProShop.exe --profile=... --runscript=...` (embedded Python 2.7,
fully compatible bridge code).

Environment variables (all optional, with auto-detection defaults):
    INOSHOP_EXE             Path to InoProShop.exe
    INOSHOP_PROFILE         Profile name (default: InoProShop(V1.10.0.3))
    INOSHOP_BRIDGE_SCRIPT   Path to bridge\inoproshop_bridge.py
    INOSHOP_BRIDGE_DIR      Directory for the request/result file queue
    INOSHOP_START_TIMEOUT_MS  Max wait for IDE+bridge readiness (default 240000)
    INOSHOP_REQUEST_TIMEOUT_MS Timeout per bridge request (default 180000)
    INOSHOP_KILL_EXISTING   "1" (default) kills a running InoProShop before
                            (re)starting the bridge, "0" keeps it
    INOSHOP_COMPAT_LAYER    Extra AppCompat override for the IDE child process
                            (default RUNASINVOKER so a stale "run as
                            administrator" compatibility flag does not force
                            a UAC prompt; set to empty to disable)
    INOSHOP_ENV_CHECK      "1" (default) runs the startup environment gate;
                            "0" disables it
    INOSHOP_ENV_CHECK_POPUP "1" (default) shows a Windows message box when the
                            environment check fails; "0" only writes stderr
    INOSHOP_REQUIRE_VERSION  Required InoProShop version, prefix match
                            (default "1.10.0.3")
"""
import json
import os
import re
import sys
import io
import time
import uuid
import shutil
import subprocess
import traceback

SERVER_NAME = "小文老师InoproshopMCP"
SERVER_VERSION = "1.3.9"

HERE = os.path.dirname(os.path.abspath(__file__))
BRIDGE_DEFAULT = os.path.join(HERE, "bridge", "inoproshop_bridge.py")
DOCS_DIR = os.path.join(HERE, "docs")
TEMPLATES_DIR = os.path.join(HERE, "templates")


# ---------------------------------------------------------------------------
# knowledge pack: the author's coding style + code templates (MCP resources)
# ---------------------------------------------------------------------------
def _load_text(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return f.read()


def _style_sections():
    """Split style_guide.md into sections keyed by heading."""
    path = os.path.join(DOCS_DIR, "style_guide.md")
    text = _load_text(path) if os.path.isfile(path) else ""
    sections = {"all": text}
    current = None
    for line in text.splitlines():
        if line.startswith("## "):
            current = line[3:].strip()
            sections[current] = line + "\n"
        elif current is not None:
            sections[current] += line + "\n"
    return sections


STYLE_SECTIONS = _style_sections()

STYLE_TOPICS = {
    "overview": u"1. 工程分层（文件夹规范）",
    "layers": u"1. 工程分层（文件夹规范）",
    "naming": u"2. 命名规范",
    "fb_skeleton": u"3. FB 骨架（新 FB 照此结构）",
    "state_machine": u"4. 步序状态机规范（核心）",
    "safety": u"5. 安全约束（新业务不可省略）",
    "comments": u"6. 注释规范",
    "interface": u"7. 接口规范（FB 与外部解耦）",
    "instantiation": u"8. 实例化规范",
    "habits": u"9. 其他工程习惯",
}

RESOURCE_DEFS = [
    {"uri": "style://coding-style", "name": u"作者编码风格手册",
     "description": u"作者的 InoProShop 编码规范：工程分层、命名前缀、FB 骨架、步序状态机、安全约束、注释与接口规范。写新功能块前必读。",
     "path": os.path.join(DOCS_DIR, "style_guide.md")},
    {"uri": "template://sv-fb-declaration", "name": u"Sv_FB 声明区模板（作者原版）",
     "description": u"伺服功能块 Sv_FB 的完整声明区：VAR_INPUT/VAR_OUTPUT/VAR_IN_OUT/VAR 结构、全部变量与中文注释。",
     "path": os.path.join(TEMPLATES_DIR, "sv_fb_declaration.st")},
    {"uri": "template://sv-fb-implementation", "name": u"Sv_FB 实现区模板（作者原版）",
     "description": u"伺服功能块 Sv_FB 的完整实现：8 类业务（使能/点动/回原/绝对/相对/复位/暂停/停止）的步序状态机源码。",
     "path": os.path.join(TEMPLATES_DIR, "sv_fb_implementation.st")},
    {"uri": "template://dut-sv-interface", "name": u"DUT_Sv_Interface 接口模板（作者原版）",
     "description": u"伺服统一对外接口结构体：HMI/上位机只读写此接口。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sv_interface.st")},
    {"uri": "template://dut-sm3-power", "name": u"DUT_SM3_Power 单指令接口模板（作者原版）",
     "description": u"单运动指令接口结构体示例；Jog/Abs/Rel/Reset/Home/Halt/Stop 按同一模式编写。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_power.st")},
    {"uri": "template://dut-sm3-jog", "name": u"DUT_SM3_Jog（作者原版）",
     "description": u"点动接口结构体（作者原版，硅棒线21_Rst）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_jog.st")},
    {"uri": "template://dut-sm3-abs", "name": u"DUT_SM3_Abs（作者原版）",
     "description": u"绝对定位接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_abs.st")},
    {"uri": "template://dut-sm3-rel", "name": u"DUT_SM3_Rel（作者原版）",
     "description": u"相对定位接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_rel.st")},
    {"uri": "template://dut-sm3-reset", "name": u"DUT_SM3_Reset（作者原版）",
     "description": u"复位接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_reset.st")},
    {"uri": "template://dut-sm3-home", "name": u"DUT_SM3_Home（作者原版）",
     "description": u"回原接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_home.st")},
    {"uri": "template://dut-sm3-halt", "name": u"DUT_SM3_Halt（作者原版）",
     "description": u"暂停接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_halt.st")},
    {"uri": "template://dut-sm3-stop", "name": u"DUT_SM3_Stop（作者原版）",
     "description": u"停止接口结构体（作者原版）。",
     "path": os.path.join(TEMPLATES_DIR, "dut_sm3_stop.st")},
    {"uri": "template://instantiation-example", "name": u"实例化接线示例（作者工程实际写法）",
     "description": u"FB 实例声明（XHTSJ_1/BLTJF_1/YZJ_1/MovCar）、LD 接线与 HMI 对接的完整示例。",
     "path": os.path.join(TEMPLATES_DIR, "instantiation_example.txt")},
    {"uri": "template://clock-1hz-example", "name": u"简单 FB 示例 Clock_1HZ",
     "description": u"无步序的简单功能块写法（TON 秒脉冲），写简单类 FB 时参照。",
     "path": os.path.join(TEMPLATES_DIR, "clock_1hz_example.st")},
]

TEMPLATE_NAMES = {
    "sv_fb_declaration": "sv_fb_declaration.st",
    "sv_fb_decl": "sv_fb_declaration.st",
    "sv_fb_implementation": "sv_fb_implementation.st",
    "sv_fb_impl": "sv_fb_implementation.st",
    "dut_interface": "dut_sv_interface.st",
    "dut_sv_interface": "dut_sv_interface.st",
    "dut_sm3_power": "dut_sm3_power.st",
    "instantiation": "instantiation_example.txt",
    "instantiation_example": "instantiation_example.txt",
    "clock_1hz": "clock_1hz_example.st",
    "clock_fb": "clock_1hz_example.st",
}

# 小文老师伺服 FB 的 9 个原版 DUT（部署用）
DUT_FILES = {
    "DUT_Sv_Interface": "dut_sv_interface.st",
    "DUT_SM3_Power": "dut_sm3_power.st",
    "DUT_SM3_Jog": "dut_sm3_jog.st",
    "DUT_SM3_Abs": "dut_sm3_abs.st",
    "DUT_SM3_Rel": "dut_sm3_rel.st",
    "DUT_SM3_Reset": "dut_sm3_reset.st",
    "DUT_SM3_Home": "dut_sm3_home.st",
    "DUT_SM3_Halt": "dut_sm3_halt.st",
    "DUT_SM3_Stop": "dut_sm3_stop.st",
}


def _dut_texts():
    d = {}
    for name, fname in DUT_FILES.items():
        p = os.path.join(TEMPLATES_DIR, fname)
        if os.path.isfile(p):
            d[name] = _load_text(p)
    return d


DUT_TEXTS = _dut_texts()


def _sv_fb_texts():
    decl = os.path.join(TEMPLATES_DIR, "sv_fb_declaration.st")
    impl = os.path.join(TEMPLATES_DIR, "sv_fb_implementation.st")
    return (_load_text(decl) if os.path.isfile(decl) else "",
            _load_text(impl) if os.path.isfile(impl) else "")

STYLE_PROMPT_TEXT = u"""你要按照本工程作者的编码风格，创建/修改 InoProShop（CODESYS 内核）功能块代码。

工作流程（按顺序执行）：
1. 学习风格：调用 inoshop_style_guide（可多次，按 topic 取不同章节），至少读 overview、naming、fb_skeleton、state_machine、safety 五章；必要时读取资源 style://coding-style。
2. 取模板：调用 inoshop_style_template 获取代码模板（sv_fb_declaration / sv_fb_implementation / dut_interface / dut_sm3_power / instantiation / clock_1hz）。
3. 设计新功能块：
   - 明确业务的命令输入（i 前缀）、状态输出（o 前缀，Done/Err 成对）、设备引用（VAR_IN_OUT）、内部静态区（s 前缀 + Step 步序 + 防冷启动标志）；
   - 每业务一个 CASE 步序状态机，步号按 0/10/20/30/40/50/60-80/900/910 编排，互锁条件照抄 Sv_FB 的写法；
   - 安全约束不可省略：先使能、先回原、参数校验、正反转互斥、暂停停止联动清理。
4. 写入工程：
   - 用 inoshop_project_open 打开目标工程；
   - FB 用 inoshop_pou_create 创建（parent 传 2_类模板，声明/实现文本按骨架与模板写全）；
   - 接口 DUT 通过 inoshop_script_run 用脚本引擎创建（create_dut），或提示用户手动创建；
   - 实例化放到 1_程序组织调用单元，行尾中文注释设备全称；
5. 验证：inoshop_build 确认 0 错误；inoshop_project_save 保存。
6. 完成后向用户报告：新增了哪些对象、每个步序的含义、与既有风格的差异点。

风格要点速查（详细规则以 inoshop_style_guide 为准）：
- 四层文件夹：1_程序组织调用单元 / 2_类模板 / 3_变量表 / 4_数据类型DUT；
- 命名：i 输入命令、o 输出状态、s 内部静态、Step*Work 步序、MC_*_DB 库实例、MC_*_interface 接口实例；
- FB 声明顺序：VAR_INPUT → VAR_OUTPUT → VAR_IN_OUT(AxisNumber:AXIS_REF_SM3) → VAR(库实例/接口/静态/步序/防冷启动标志)；
- 每个变量行尾 //中文注释；{region …} 分段；每个步号 N://说明；
- 对外只暴露接口 DUT，HMI 不直接碰 FB。"""

PROMPT_DEFS = [
    {"name": "create_fb_in_author_style",
     "description": u"按作者编码风格创建新的功能块（含风格学习、模板调用、状态机设计、写入工程与编译验证的完整指引）。",
     "text": STYLE_PROMPT_TEXT},
    {"name": "deploy_servo_fb",
     "description": u"用户说“小文老师，帮我复现你的伺服FB”（或“开始部署小文老师的伺服FB”“部署伺服FB”）时的一键复现流程。",
     "text": u"""用户说“小文老师，帮我复现你的伺服FB”（或类似“开始部署小文老师的伺服FB”“部署伺服FB”）时，执行以下复现流程：

1. 确认目标工程路径：用户没指定就用默认（<桥接目录>\\projects\\小文老师伺服FB.project），指定了就用他的（如 D:\\Work\\伺服FB.project）；
2. 调用 inoshop_deploy_servo_fb，参数 {"project_path": "<路径>"}。该工具会自动完成：
   建工程（AM600 模板）→ 创建 9 个原版 DUT（DUT_Sv_Interface + DUT_SM3_Power/Jog/Abs/Rel/Reset/Home/Halt/Stop）→ 创建伺服功能块 Sv_FB（原版声明 + 8 业务步序状态机实现）→ 在任务程序 POU1 中实例化（MovCar / Car_InterFace）→ 编译 → 保存；
3. 向用户汇报：工程路径、创建了哪些对象、编译结果（应显示 0 错误 0 警告）；
4. 提示用户：可用 inoshop_bridge_shutdown 释放界面，然后在 InoProShop 里点开 Sv_FB 查看代码；
5. 如果编译报错：把错误逐条告诉用户，并按小文老师风格尝试修复后重新编译。"""},
]

ENV_EXE = "INOSHOP_EXE"
ENV_PROFILE = "INOSHOP_PROFILE"
ENV_BRIDGE_SCRIPT = "INOSHOP_BRIDGE_SCRIPT"
ENV_BRIDGE_DIR = "INOSHOP_BRIDGE_DIR"
ENV_START_TIMEOUT = "INOSHOP_START_TIMEOUT_MS"
ENV_REQUEST_TIMEOUT = "INOSHOP_REQUEST_TIMEOUT_MS"
ENV_KILL_EXISTING = "INOSHOP_KILL_EXISTING"
ENV_COMPAT_LAYER = "INOSHOP_COMPAT_LAYER"
ENV_CHECK = "INOSHOP_ENV_CHECK"
ENV_CHECK_POPUP = "INOSHOP_ENV_CHECK_POPUP"
ENV_REQUIRE_VERSION = "INOSHOP_REQUIRE_VERSION"

DEFAULT_PROFILE = "InoProShop(V1.10.0.3)"
DEFAULT_REQUIRE_VERSION = "1.10.0.3"


def log(message):
    try:
        with io.open(os.path.join(bridge_dir(), "server.log"), "a", encoding="utf-8") as f:
            f.write(message + "\n")
    except Exception:
        pass


def _read_file(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return f.read()


def _write_file(path, content):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(content)
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass
    os.rename(tmp, path)


# ---------------------------------------------------------------------------
# configuration / auto detection
# ---------------------------------------------------------------------------
def bridge_dir():
    return os.environ.get(ENV_BRIDGE_DIR) or os.path.join(
        os.environ.get("TEMP", r"C:\Temp"), "inoshop-mcp")


def find_inoproshop_installs():
    """Scan registry for all InoProShop installs -> list of dicts
    {display, version, exe, exe_exists}."""
    results = []
    seen = set()
    for root, view in ((winreg.HKEY_LOCAL_MACHINE, 0),
                       (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),
                       (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY)):
        for sub in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                    r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            try:
                key = winreg.OpenKey(root, sub, 0, winreg.KEY_READ | view)
            except OSError:
                continue
            try:
                i = 0
                while True:
                    try:
                        name = winreg.EnumKey(key, i)
                        i += 1
                    except OSError:
                        break
                    try:
                        k = winreg.OpenKey(key, name, 0, winreg.KEY_READ | view)
                        try:
                            display = winreg.QueryValueEx(k, "DisplayName")[0]
                        except OSError:
                            display = ""
                        try:
                            version = winreg.QueryValueEx(k, "DisplayVersion")[0]
                        except OSError:
                            version = ""
                        try:
                            loc = winreg.QueryValueEx(k, "InstallLocation")[0]
                        except OSError:
                            loc = ""
                        if "InoProShop" in str(display) and (display, version) not in seen:
                            seen.add((display, version))
                            exe = os.path.join(str(loc), "CODESYS", "Common", "InoProShop.exe")
                            results.append({
                                "display": str(display),
                                "version": str(version),
                                "exe": exe,
                                "exe_exists": os.path.isfile(exe),
                            })
                    finally:
                        try:
                            winreg.CloseKey(k)
                        except Exception:
                            pass
            finally:
                try:
                    winreg.CloseKey(key)
                except Exception:
                    pass
    return results


def exe_path():
    p = os.environ.get(ENV_EXE)
    if p and os.path.isfile(p):
        return p
    for r in find_inoproshop_installs():
        if r["exe_exists"]:
            return r["exe"]
    raise RuntimeError(
        "InoProShop.exe not found. Set INOSHOP_EXE env var, e.g. "
        r"C:\Inovance Control\InoProShop\CODESYS\Common\InoProShop.exe")


def profile_name():
    return os.environ.get(ENV_PROFILE) or DEFAULT_PROFILE


def bridge_script():
    p = os.environ.get(ENV_BRIDGE_SCRIPT)
    if p and os.path.isfile(p):
        return p
    if os.path.isfile(BRIDGE_DEFAULT):
        return BRIDGE_DEFAULT
    raise RuntimeError("bridge script not found: " + BRIDGE_DEFAULT)


def int_env(name, default):
    try:
        return int(os.environ.get(name, str(default)))
    except Exception:
        return default


def start_timeout_ms():
    return int_env(ENV_START_TIMEOUT, 240000)


def request_timeout_ms():
    return int_env(ENV_REQUEST_TIMEOUT, 180000)


def kill_existing():
    return os.environ.get(ENV_KILL_EXISTING, "1") != "0"


def compat_layer():
    v = os.environ.get(ENV_COMPAT_LAYER)
    if v is None:
        return "RUNASINVOKER"
    return v


# ---------------------------------------------------------------------------
# startup environment check (popup + exit on mismatch)
# ---------------------------------------------------------------------------
def _version_tuple(v):
    """'1.10.0.3' -> (1,10,0,3); unparseable -> None."""
    if not v:
        return None
    nums = re.findall(r"\d+", str(v))
    if not nums:
        return None
    return tuple(int(x) for x in nums)


def _version_ge(found, required):
    """True when the found version is >= required (numeric comparison)."""
    a = _version_tuple(found)
    b = _version_tuple(required)
    if a is None or b is None:
        # unparseable -> fall back to prefix match
        return str(found).lower().startswith(str(required).lower())
    return a >= b


def env_check_report():
    """Check the host environment. Returns {ok, items, problems}."""
    expected = os.environ.get(ENV_REQUIRE_VERSION, DEFAULT_REQUIRE_VERSION)
    items = []
    problems = []
    ok = True

    def add(name, status, detail):
        items.append({"name": name, "status": status, "detail": detail})

    def fail(name, detail, problem):
        add(name, "FAIL", detail)
        problems.append(problem)
        return False

    # 1. Windows
    if sys.platform != "win32" and os.name != "nt":
        add(u"操作系统", "FAIL", sys.platform)
        problems.append(u"仅支持 Windows，当前系统：%s" % sys.platform)
        ok = False
    else:
        add(u"操作系统", "OK", "Windows")

    # 2. Python
    pyver = "%d.%d.%d" % sys.version_info[:3]
    if sys.version_info < (3, 8):
        ok = fail(u"Python", pyver,
                  u"Python 版本过低：%s（需要 3.8 以上）" % pyver) and ok
    else:
        add(u"Python", "OK", pyver)

    # 3. InoProShop install + version + profile
    installs = find_inoproshop_installs()
    if not installs:
        ok = fail(u"InoProShop", u"未检测到安装",
                  u"未检测到 InoProShop 安装（请先安装 InoProShop %s）" % expected) and ok
    else:
        chosen = None
        for r in installs:
            if r["exe_exists"]:
                chosen = r
                break
        if chosen is None:
            chosen = installs[0]
        add(u"InoProShop", "OK", u"%s -> %s" % (chosen["display"], chosen["exe"]))
        if not chosen["exe_exists"]:
            ok = fail(u"InoProShop.exe", chosen["exe"],
                      u"InoProShop.exe 不存在：%s" % chosen["exe"]) and ok
        ver = chosen["version"]
        ver_ok = _version_ge(ver, expected)
        if ver_ok:
            add(u"InoProShop 版本", "OK", u"已安装 %s（要求 >= %s）" % (ver, expected))
        else:
            ok = fail(u"InoProShop 版本", u"已安装 %s（要求 >= %s）" % (ver or u"未知", expected),
                      u"InoProShop 版本过低：已安装 %s，要求 %s 或更高版本。"
                      u"请到汇川官网下载升级：https://www.inovance.com/portal/serviceSupport/download"
                      % (ver or u"未知", expected)) and ok
        prof = "InoProShop(V%s)" % ver if ver else None
        profile_ok = False
        if prof and chosen["exe_exists"]:
            prof_path = os.path.join(os.path.dirname(chosen["exe"]), "..", "Profiles",
                                     prof + ".profile")
            profile_ok = os.path.isfile(prof_path)
        if profile_ok:
            add(u"Profile", "OK", prof)
        else:
            ok = fail(u"Profile", prof or u"-",
                      u"未找到 Profile：%s（自动化启动 IDE 需要它）" % (prof or u"未知")) and ok

    # 4. package integrity
    if os.path.isfile(BRIDGE_DEFAULT):
        add(u"桥接脚本", "OK", BRIDGE_DEFAULT)
    else:
        ok = fail(u"桥接脚本", BRIDGE_DEFAULT,
                  u"缺少桥接脚本文件：%s" % BRIDGE_DEFAULT) and ok

    return {"ok": ok, "items": items, "problems": problems,
            "required_version": expected}


def popup_env_failure(report):
    """Show a Windows message box describing the problems."""
    lines = [u"小文老师Inoproshop —— 环境检查未通过", u""]
    for p in report.get("problems", []):
        lines.append(u"[X] " + p)
    lines.append(u"")
    lines.append(u"请解决以上问题后，重新连接 MCP。")
    lines.append(u"（跳过检查：设置环境变量 INOSHOP_ENV_CHECK=0）")
    text = u"\n".join(lines)
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, u"小文老师Inoproshop 环境检查", 0x10)
    except Exception:
        pass


def startup_env_gate():
    """Run at process start. Returns normally when OK; pops a dialog and
    exits when the environment does not match requirements."""
    if os.environ.get(ENV_CHECK, "1") == "0":
        return
    report = env_check_report()
    log("env check: ok=%s problems=%s" % (report["ok"], report["problems"]))
    if report["ok"]:
        return
    sys.stderr.write("[小文老师Inoproshop] 环境检查未通过：\n")
    for p in report["problems"]:
        sys.stderr.write("  - %s\n" % p)
    sys.stderr.flush()
    if os.environ.get(ENV_CHECK_POPUP, "1") != "0":
        popup_env_failure(report)
    sys.exit(2)


# ---------------------------------------------------------------------------
# bridge client (file based protocol)
# ---------------------------------------------------------------------------
class BridgeClient(object):
    def __init__(self):
        self.bdir = bridge_dir()
        self.req_dir = os.path.join(self.bdir, "requests")
        self.res_dir = os.path.join(self.bdir, "results")
        self.ready = os.path.join(self.bdir, "bridge.ready")
        self.heartbeat = os.path.join(self.bdir, "bridge.heartbeat")
        self._launched_pid = None

    # ---- lifecycle ----
    def _ensure_dirs(self):
        for d in (self.bdir, self.req_dir, self.res_dir):
            if not os.path.isdir(d):
                os.makedirs(d)

    def _heartbeat_age(self):
        try:
            return time.time() - os.path.getmtime(self.heartbeat)
        except OSError:
            return None

    def _inoproshop_running(self):
        try:
            out = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq InoProShop.exe"],
                capture_output=True, timeout=10)
            return b"InoProShop.exe" in out.stdout
        except Exception:
            return True  # unknown -> fall back to heartbeat only

    def _ready_age(self):
        try:
            return time.time() - os.path.getmtime(self.ready)
        except OSError:
            return None

    def alive(self, max_age=180.0):
        age = self._heartbeat_age()
        if age is not None and age < max_age:
            # heartbeat file alone is not trustworthy: it stays "fresh" after
            # the IDE dies. Require the InoProShop process to actually run.
            return self._inoproshop_running()
        # cold-start window: heartbeat may not exist yet right after the
        # bridge wrote its ready marker
        if age is None:
            ready_age = self._ready_age()
            if ready_age is not None and ready_age < 60.0:
                return self._inoproshop_running()
        return False

    def _clear_markers(self):
        for p in (self.ready, self.heartbeat):
            try:
                os.remove(p)
            except OSError:
                pass

    def restart(self):
        exe = exe_path()
        prof = profile_name()
        script = bridge_script()
        self._ensure_dirs()
        log("restart: killing existing InoProShop (if any)")
        if kill_existing():
            try:
                subprocess.call(["taskkill", "/IM", "InoProShop.exe", "/T", "/F"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass
            time.sleep(2)
        self._clear_markers()
        env = dict(os.environ)
        env[ENV_BRIDGE_DIR] = self.bdir
        env["INOSHOP_IDLE_EXIT_MS"] = str(int_env("INOSHOP_IDLE_EXIT_MS", 180000))
        cl = compat_layer()
        if cl:
            env["__COMPAT_LAYER"] = cl
        cmd = [
            exe,
            # NOTE: no embedded quotes here. subprocess would escape them as \"
            # which InoProShop's argument parser does not accept (it then shows
            # the profile selection dialog). Args without spaces pass verbatim.
            "--profile=" + prof,
            "--runscript=" + script,
        ]
        log("restart: launching " + " ".join(cmd))
        proc = subprocess.Popen(
            cmd,
            cwd=os.path.dirname(exe),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        self._launched_pid = proc.pid
        deadline = time.time() + start_timeout_ms() / 1000.0
        while time.time() < deadline:
            if os.path.exists(self.ready):
                # give the bridge a moment to start its main loop
                time.sleep(1.5)
                return {"started": True, "pid": proc.pid, "waited_ready": True}
            time.sleep(1.0)
        raise RuntimeError(
            "InoProShop bridge did not become ready within %d ms. "
            "Check %s" % (start_timeout_ms(), os.path.join(self.bdir, "bridge.log")))

    def ensure_ready(self):
        if self.alive():
            return {"alive": True}
        if self._inoproshop_running():
            # The IDE is running but the bridge is gone (it ended after a task
            # finished and auto-released the UI, or it exited by idle timeout).
            # Default: automatically restart the IDE with the bridge so the
            # next sentence "just works". Set INOSHOP_AUTO_KILL_MANUAL=0 to
            # demand an explicit inoshop_bridge_restart instead.
            if os.environ.get("INOSHOP_AUTO_KILL_MANUAL", "1") == "1":
                log("ensure_ready: IDE running without bridge -> auto restart")
                return self.restart()
            raise RuntimeError(
                "InoProShop 正在运行，但自动化桥接未运行（可能正在被人工使用，"
                "或桥接已因空闲自动退出）。请先确认工程已保存，然后调用 "
                "inoshop_bridge_restart 重新接入自动化（该操作会关闭当前 IDE 窗口）。")
        log("ensure_ready: no IDE running -> launching with bridge")
        return self.restart()

    def status(self):
        return {
            "bridge_dir": self.bdir,
            "ready": os.path.exists(self.ready),
            "alive": self.alive(),
            "heartbeat_age": self._heartbeat_age(),
            "launched_pid": self._launched_pid,
        }

    # ---- request/response ----
    def request(self, op, params=None, timeout_ms=None):
        self.ensure_ready()
        timeout_ms = timeout_ms or request_timeout_ms()
        req_id = uuid.uuid4().hex
        payload = {"id": req_id, "op": op, "params": params or {}}
        req_path = os.path.join(self.req_dir, req_id + ".json")
        res_path = os.path.join(self.res_dir, req_id + ".json")
        _write_file(req_path, json.dumps(payload, ensure_ascii=False, indent=2))
        deadline = time.time() + timeout_ms / 1000.0
        while time.time() < deadline:
            if os.path.exists(res_path):
                try:
                    data = json.loads(_read_file(res_path))
                except Exception:
                    time.sleep(0.2)
                    continue
                try:
                    os.remove(res_path)
                except OSError:
                    pass
                if not data.get("ok"):
                    raise RuntimeError(data.get("error", "bridge error") +
                                       ("\n" + data.get("traceback", "")))
                return data.get("result")
            time.sleep(0.2)
        # timed out: drop the pending request file so a later bridge restart
        # does not process stale work
        try:
            os.remove(req_path)
        except OSError:
            pass
        raise TimeoutError("bridge request %s timed out after %d ms" % (op, timeout_ms))


CLIENT = BridgeClient()


# ---------------------------------------------------------------------------
# tool implementations
# ---------------------------------------------------------------------------
def t_bridge_status(params):
    # ping first: it triggers ensure_ready (cold-start if needed), so the
    # status snapshot below reflects the post-startup state
    ping_result = None
    try:
        ping_result = CLIENT.request("ping", {}, 20000)
    except Exception as e:
        ping_result = "ping error: %s" % e
    s = CLIENT.status()
    s["ping"] = ping_result
    return s


def t_bridge_restart(params):
    return CLIENT.restart()


def t_bridge_shutdown(params):
    try:
        result = CLIENT.request("shutdown", {}, 20000)
    except Exception:
        result = {"note": "bridge already gone"}
    return {"released": True, "result": result,
            "note": "桥接脚本已结束并保存工程，IDE 保持打开且界面恢复可交互。"}


def t_bridge_exit(params):
    try:
        CLIENT.request("exit_ide", {}, 20000)
    except Exception:
        pass
    return {"requested": True, "note": "InoProShop IDE is closing"}


# ---------------------------------------------------------------------------
# knowledge tools (fallback access for clients that do not surface
# resources/prompts): the author's coding style + code templates
# ---------------------------------------------------------------------------
def t_style_guide(params):
    topic = params.get("topic", "all")
    if topic == "all":
        text = STYLE_SECTIONS.get("all", "")
        return {"topic": "all", "text": text}
    heading = STYLE_TOPICS.get(topic)
    if heading is None or heading not in STYLE_SECTIONS:
        return {"topic": topic, "error": "unknown topic",
                "available_topics": sorted(STYLE_TOPICS.keys())}
    return {"topic": topic, "section": heading,
            "text": STYLE_SECTIONS[heading]}


def t_style_template(params):
    name = params.get("name", "")
    fname = TEMPLATE_NAMES.get(name)
    if fname is None:
        return {"name": name, "error": "unknown template",
                "available_templates": sorted(TEMPLATE_NAMES.keys())}
    path = os.path.join(TEMPLATES_DIR, fname)
    if not os.path.isfile(path):
        return {"name": name, "error": "template file missing: " + fname}
    return {"name": name, "file": fname, "text": _load_text(path)}


def t_env_check(params):
    """On-demand environment check (reports, never exits)."""
    return env_check_report()


def t_deploy_servo_fb(params):
    """一句话部署：建工程 -> 9 个原版 DUT -> Sv_FB -> POU1 实例化 -> 编译 -> 保存。"""
    path = params.get("project_path")
    if not path:
        path = os.path.join(bridge_dir(), "projects", u"小文老师伺服FB.project")
    steps = []
    steps.append((u"创建工程（AM600 模板）",
                  t_project_create({"path": path, "template": "standard"})))
    for name in DUT_FILES:
        r = CLIENT.request("eval", {"code": 'app.create_dut("%s", DutType.Structure)' % name})
        txt = DUT_TEXTS.get(name, "")
        body = txt
        if "STRUCT" in txt and "END_STRUCT" in txt:
            body = txt[txt.index("STRUCT"):txt.rindex("END_STRUCT") + len("END_STRUCT")]
        w = None
        for candidate in (txt, body):
            try:
                w = CLIENT.request("write_text", {"object": name, "part": "declaration",
                                                  "text": candidate, "mode": "replace"})
                break
            except Exception:
                w = None
        steps.append((u"创建 DUT %s" % name, {"create": r.get("value"),
                                             "write": w}))
    sv_decl, sv_impl = _sv_fb_texts()
    # 兼容补丁：模板工程自带的 SM3_Basic 版本较旧，MC_MoveAbsolute/Relative
    # 没有 Active 输出引脚（作者原工程用 SM3_Basic 4.10+ 才有）。
    # 部署时去掉这两行引脚映射，其余代码保持原版。
    compat_note = u""
    for pin in (u"\n\tActive=> MC_Abs_interface.oActive,",
                u"\n\tActive=> MC_Rel_interface.oActive,"):
        if pin in sv_impl:
            sv_impl = sv_impl.replace(pin, u"")
            compat_note = u"已去除旧版 SM3 库不存在的 Active 引脚映射（2 处）"
    steps.append((u"创建伺服功能块 Sv_FB",
                  t_pou_create({"name": "Sv_FB", "type": "FunctionBlock",
                                "declaration": sv_decl, "implementation": sv_impl})))
    if compat_note:
        steps.append((u"兼容适配", compat_note))
    decl_write = None
    try:
        cur = t_text_read({"object": "POU1", "part": "declaration"}).get("text", "")
        extra = (u"\tMovCar : Sv_FB;\t//1#小车实例背景\r\n"
                 u"\tCar_InterFace : DUT_Sv_Interface;\t//小车接口\r\n")
        if u"END_VAR" in cur:
            merged = cur.replace(u"END_VAR", extra + u"END_VAR", 1)
            decl_write = t_text_write({"object": "POU1", "part": "declaration",
                                       "text": merged, "mode": "replace"})
    except Exception as e:
        decl_write = {"error": str(e)}
    steps.append((u"任务程序 POU1 实例化 Sv_FB", decl_write))
    build = t_build({})
    steps.append((u"编译", build))
    save = t_project_save({})
    steps.append((u"保存", save))
    release = t_bridge_shutdown({})
    steps.append((u"完工释放界面", release))
    return {
        "project_path": path,
        "steps": steps,
        "build_success": bool(build.get("success", False)),
        "error_count": build.get("error_count", 0),
        "warning_count": build.get("warning_count", 0),
        "compile_log_tail": (build.get("log") or [])[-15:],
        "ui_released": True,
        "note": u"复现完成：工程已保存，InoProShop 界面已自动解锁，可直接查看 Sv_FB 代码。",
    }


def t_project_open(params):
    path = params.get("path")
    if not path:
        raise ValueError("path is required")
    return CLIENT.request("project_open", {"path": path})


def t_project_create(params):
    path = params.get("path")
    if not path:
        raise ValueError("path is required (must end with .project)")
    template = params.get("template", "standard")
    target = os.path.abspath(path)
    parent = os.path.dirname(target)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    if template == "empty":
        # bare project without device/application (no build possible)
        return CLIENT.request("project_create", {"path": target})
    # standard/demo/am600: seed from the InoProShop AM600 ST demo project
    base = exe_path()
    projects_dir = os.path.abspath(os.path.join(os.path.dirname(base), "..", "Projects"))
    src = os.path.join(projects_dir, "Demo for AM600", "002_Marquee(ST).project")
    if not os.path.isfile(src):
        raise RuntimeError(
            "demo template not found: " + src +
            " (set template='empty' for a bare project, or open an existing "
            "project with inoshop_project_open)")
    # seed copy: use a UNIQUE filename each time (a previous IDE instance may
    # still hold the old seed file locked), copy without file attributes
    # (installed files are read-only, and a read-only project cannot be saved).
    # Keep the seed inside the package dir (always user-writable) and retry on
    # transient locks (antivirus scanners etc.).
    seed_dir = os.path.join(HERE, "seed")
    if not os.path.isdir(seed_dir):
        os.makedirs(seed_dir)
    seed = os.path.join(seed_dir, "demo_seed_%s.project" % uuid.uuid4().hex[:8])
    copy_ok = False
    last_err = None
    for _ in range(3):
        try:
            shutil.copyfile(src, seed)
            copy_ok = True
            break
        except PermissionError as e:
            last_err = e
            time.sleep(1)
    if not copy_ok:
        raise RuntimeError(u"模板复制失败（文件被占用）：%s" % last_err)
    try:
        os.chmod(seed, 0o666)
    except OSError:
        pass
    opened = CLIENT.request("project_open", {"path": seed})
    saved = CLIENT.request("project_save", {"path": target})
    # best-effort cleanup of older seed files (keep the current one)
    try:
        for old in os.listdir(seed_dir):
            if old.startswith("demo_seed_") and old != os.path.basename(seed):
                try:
                    os.remove(os.path.join(seed_dir, old))
                except OSError:
                    pass
    except OSError:
        pass
    return {"opened_template": opened, "saved_as": saved, "template_source": src}


def t_project_save(params):
    return CLIENT.request("project_save", {"path": params.get("path")})


def t_project_close(params):
    return CLIENT.request("project_close", {"save": bool(params.get("save", False))})


def t_project_info(params):
    return CLIENT.request("project_info", {})


def t_object_tree(params):
    return CLIENT.request("tree", {"max_depth": int(params.get("max_depth", 3))})


def t_object_find(params):
    return CLIENT.request("find", {"name": params.get("name")})


def t_object_delete(params):
    return CLIENT.request("delete_object", {"name": params.get("name")})


def t_pou_create(params):
    name = params.get("name")
    if not name:
        raise ValueError("name is required")
    return CLIENT.request("create_pou", {
        "name": name,
        "type": params.get("type", "Program"),
        "parent": params.get("parent"),
        "return_type": params.get("return_type"),
        "declaration": params.get("declaration"),
        "implementation": params.get("implementation"),
    })


def t_text_read(params):
    return CLIENT.request("read_text", {
        "object": params.get("object"),
        "part": params.get("part", "implementation"),
    })


def t_text_write(params):
    build_after = bool(params.get("build_after", False))
    save_after = bool(params.get("save_after", False))
    result = CLIENT.request("write_text", {
        "object": params.get("object"),
        "part": params.get("part", "implementation"),
        "text": params.get("text", ""),
        "mode": params.get("mode", "replace"),
        "search": params.get("search"),
        "replace": params.get("replace"),
        "anchor": params.get("anchor"),
    })
    if build_after:
        result["build"] = CLIENT.request("build", {})
    if save_after:
        result["save"] = CLIENT.request("project_save", {})
    return result


def t_build(params):
    return CLIENT.request("build", {})


def t_messages(params):
    return CLIENT.request("messages", {})


def t_script_run(params):
    code = params.get("code")
    if not code:
        raise ValueError("code is required")
    return CLIENT.request("eval", {"code": code})


# ---------------------------------------------------------------------------
# demo: bubble sort
# ---------------------------------------------------------------------------
BUBBLE_DECL = u"""FUNCTION_BLOCK BubbleSort
VAR_INPUT
\tarrIn : ARRAY[0..9] OF INT;
END_VAR
VAR_OUTPUT
\tarrOut : ARRAY[0..9] OF INT;
\tdone : BOOL;
END_VAR
VAR
\ti, j : INT;
\ttmp : INT;
END_VAR"""

BUBBLE_IMPL = u"""// 冒泡排序：对 arrIn 升序排序后输出到 arrOut
arrOut := arrIn;
FOR i := 0 TO 8 DO
\tFOR j := 0 TO 8 - i DO
\t\tIF arrOut[j] > arrOut[j + 1] THEN
\t\t\ttmp := arrOut[j];
\t\t\tarrOut[j] := arrOut[j + 1];
\t\t\tarrOut[j + 1] := tmp;
\t\tEND_IF
\tEND_FOR
END_FOR
done := TRUE;
"""

# POU1 is the task-referenced program of the AM600 demo template; replacing it
# makes the demo code actually compiled (only task-referenced POUs are checked).
DEMO_DECL = u"""PROGRAM POU1
VAR
\tdata : ARRAY[0..9] OF INT := [5,3,8,1,9,2,7,4,6,0];
\tsorted : ARRAY[0..9] OF INT;
\tbs : BubbleSort;
END_VAR"""

DEMO_IMPL = u"""// 调用冒泡排序功能块：data 升序排序结果写入 sorted
bs(arrIn := data, arrOut => sorted);
"""


def t_demo_bubble_sort(params):
    path = params.get("project_path")
    if not path:
        path = os.path.join(bridge_dir(), "projects", "BubbleSortDemo.project")
    steps = []
    steps.append(("create project from AM600 demo template",
                  t_project_create({"path": path, "template": "standard"})))
    steps.append(("create POU BubbleSort (FUNCTION_BLOCK)",
                  t_pou_create({"name": "BubbleSort", "type": "FunctionBlock",
                                "declaration": BUBBLE_DECL, "implementation": BUBBLE_IMPL})))
    # merge our variables into the existing task program POU1 declaration
    # (the demo project may reference POU1 variables from I/O mapping etc.,
    # so the original declaration must be preserved)
    extra_decl = u"\tdata : ARRAY[0..9] OF INT := [5,3,8,1,9,2,7,4,6,0];\r\n" \
                 u"\tsorted : ARRAY[0..9] OF INT;\r\n" \
                 u"\tbs : BubbleSort;\r\n"
    decl_write = None
    try:
        cur = t_text_read({"object": "POU1", "part": "declaration"}).get("text", "")
        if u"END_VAR" in cur:
            merged = cur.replace(u"END_VAR", extra_decl + u"END_VAR", 1)
            decl_write = t_text_write({"object": "POU1", "part": "declaration",
                                       "text": merged, "mode": "replace"})
    except Exception as e:
        decl_write = {"merged": False, "error": str(e)}
    if decl_write is None:
        decl_write = t_text_write({"object": "POU1", "part": "declaration",
                                   "text": DEMO_DECL, "mode": "replace"})
    steps.append(("merge demo variables into task program POU1", decl_write))
    steps.append(("write POU1 implementation",
                  t_text_write({"object": "POU1", "part": "implementation", "text": DEMO_IMPL,
                                "mode": "replace"})))
    build = t_build({})
    steps.append(("build", build))
    save = t_project_save({})
    steps.append(("save", save))
    release = t_bridge_shutdown({})
    steps.append((u"完工释放界面", release))
    return {
        "project_path": path,
        "steps": steps,
        "build_success": bool(build.get("success", False)),
        "ui_released": True,
        "error_count": build.get("error_count", 0),
        "warning_count": build.get("warning_count", 0),
        "compile_log_tail": (build.get("log") or [])[-12:],
    }


# ---------------------------------------------------------------------------
# tool registry
# ---------------------------------------------------------------------------
TOOLS = [
    {"name": "inoshop_bridge_status", "description": "InoProShop IDE 与桥接状态（进程、心跳、桥接目录）。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_bridge_restart", "description": "重启 InoProShop 并接入自动化桥接。注意：会先关闭当前 IDE 窗口，未保存的修改会丢失——调用前先保存或让用户确认。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_bridge_shutdown", "description": "结束自动化桥接脚本：保存工程后释放界面，IDE 保持打开且恢复可交互（人工操作前建议调用）。桥接空闲约 3 分钟也会自动执行同样操作。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_bridge_exit", "description": "完全退出 InoProShop IDE（关闭窗口）。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_project_open", "description": "打开已有工程（.project 或 .projectarchive 路径）。",
     "inputSchema": {"type": "object", "properties": {"path": {"type": "string", "description": "工程文件绝对路径"}}, "required": ["path"]}},
    {"name": "inoshop_project_create", "description": "从模板创建新工程并打开。template 取值 standard(标准工程)/empty(空工程) 或模板归档绝对路径。",
     "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}, "template": {"type": "string", "default": "standard"}}, "required": ["path"]}},
    {"name": "inoshop_project_save", "description": "保存当前工程，可指定新路径另存为。",
     "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": []}},
    {"name": "inoshop_project_close", "description": "关闭当前工程，save=true 时先保存。",
     "inputSchema": {"type": "object", "properties": {"save": {"type": "boolean", "default": False}}, "required": []}},
    {"name": "inoshop_project_info", "description": "当前工程信息（名称、路径、活动应用、设备）。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_object_tree", "description": "工程对象树（设备/应用/POU 层级结构）。",
     "inputSchema": {"type": "object", "properties": {"max_depth": {"type": "integer", "default": 3}}, "required": []}},
    {"name": "inoshop_object_find", "description": "按名称查找对象，返回类型与路径信息。",
     "inputSchema": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
    {"name": "inoshop_object_delete", "description": "删除对象（POU/GVL 等），按名称定位。",
     "inputSchema": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
    {"name": "inoshop_pou_create", "description": "在应用下创建 POU（Program/Function/FunctionBlock），可同时写入声明与实现（ST 等文本语言）。",
     "inputSchema": {"type": "object", "properties": {
         "name": {"type": "string"},
         "type": {"type": "string", "enum": ["Program", "Function", "FunctionBlock"], "default": "Program"},
         "parent": {"type": "string", "description": "父对象名称，默认活动应用"},
         "return_type": {"type": "string", "description": "Function 的返回值类型"},
         "declaration": {"type": "string", "description": "变量声明区文本（含 POU 头，如 PROGRAM x ... END_VAR）"},
         "implementation": {"type": "string", "description": "实现区 ST 代码"}}, "required": ["name"]}},
    {"name": "inoshop_text_read", "description": "读取对象的声明区或实现区文本。part=declaration|implementation。",
     "inputSchema": {"type": "object", "properties": {"object": {"type": "string"}, "part": {"type": "string", "default": "implementation"}}, "required": ["object"]}},
    {"name": "inoshop_text_write", "description": "写入/修改对象文本。mode=replace(整体替换)/append/prepend/replace_first/replace_all/insert_before/insert_after。可自动编译与保存。",
     "inputSchema": {"type": "object", "properties": {
         "object": {"type": "string"}, "part": {"type": "string", "default": "implementation"},
         "text": {"type": "string"}, "mode": {"type": "string", "default": "replace"},
         "search": {"type": "string"}, "replace": {"type": "string"}, "anchor": {"type": "string"},
         "build_after": {"type": "boolean", "default": False}, "save_after": {"type": "boolean", "default": False}},
         "required": ["object"]}},
    {"name": "inoshop_build", "description": "编译当前工程，返回错误/警告/信息列表。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_messages", "description": "读取当前编译消息（错误/警告/信息）。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_script_run", "description": "在 InoProShop 脚本引擎中执行任意 Python 代码片段（可访问 projects/system/online/project/app 等对象），用于高级操作。",
     "inputSchema": {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]}},
    {"name": "inoshop_demo_bubble_sort", "description": "一键演示：从模板创建工程，创建冒泡排序功能块 BubbleSort，并把任务程序 POU1 改写为调用者（保证代码被编译器验证），编译并保存。",
     "inputSchema": {"type": "object", "properties": {"project_path": {"type": "string", "description": "目标 .project 路径，默认桥接目录 projects\\BubbleSortDemo.project"}}, "required": []}},
    {"name": "inoshop_style_guide", "description": "读取作者编码风格手册（按 topic 取章节：overview/naming/fb_skeleton/state_machine/safety/comments/interface/instantiation/habits，或 all 取全文）。写新代码前必须先读。",
     "inputSchema": {"type": "object", "properties": {"topic": {"type": "string", "default": "all"}}, "required": []}},
    {"name": "inoshop_style_template", "description": "读取作者代码模板：sv_fb_declaration(伺服FB声明)/sv_fb_implementation(伺服FB实现)/dut_interface/dut_sm3_power/instantiation(实例化接线)/clock_1hz(简单FB)。",
     "inputSchema": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
    {"name": "inoshop_env_check", "description": "检查本机环境是否符合要求（Windows/Python 版本/InoProShop 安装与版本/Profile/桥接脚本完整性），返回逐项检查报告。服务器启动时也会自动执行同样检查，不通过会弹窗提示并退出。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "inoshop_deploy_servo_fb", "description": "一句话部署小文老师伺服FB：自动建工程（AM600 模板）→ 创建 9 个原版 DUT（DUT_Sv_Interface + DUT_SM3_Power/Jog/Abs/Rel/Reset/Home/Halt/Stop）→ 创建伺服功能块 Sv_FB（原版 8 业务步序状态机）→ 任务程序 POU1 实例化（MovCar/Car_InterFace）→ 编译 → 保存。",
     "inputSchema": {"type": "object", "properties": {"project_path": {"type": "string", "description": "目标 .project 路径，默认 桥接目录\\projects\\小文老师伺服FB.project"}}, "required": []}},
]

HANDLERS = {
    "inoshop_bridge_status": t_bridge_status,
    "inoshop_bridge_restart": t_bridge_restart,
    "inoshop_bridge_shutdown": t_bridge_shutdown,
    "inoshop_bridge_exit": t_bridge_exit,
    "inoshop_project_open": t_project_open,
    "inoshop_project_create": t_project_create,
    "inoshop_project_save": t_project_save,
    "inoshop_project_close": t_project_close,
    "inoshop_project_info": t_project_info,
    "inoshop_object_tree": t_object_tree,
    "inoshop_object_find": t_object_find,
    "inoshop_object_delete": t_object_delete,
    "inoshop_pou_create": t_pou_create,
    "inoshop_text_read": t_text_read,
    "inoshop_text_write": t_text_write,
    "inoshop_build": t_build,
    "inoshop_messages": t_messages,
    "inoshop_script_run": t_script_run,
    "inoshop_demo_bubble_sort": t_demo_bubble_sort,
    "inoshop_style_guide": t_style_guide,
    "inoshop_style_template": t_style_template,
    "inoshop_env_check": t_env_check,
    "inoshop_deploy_servo_fb": t_deploy_servo_fb,
}


# ---------------------------------------------------------------------------
# MCP stdio transport
# ---------------------------------------------------------------------------
def send_message(obj):
    line = json.dumps(obj, ensure_ascii=False)
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def handle_request(msg):
    req_id = msg.get("id")
    method = msg.get("method")
    params = msg.get("params", {}) or {}

    if method == "initialize":
        return {"protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {"listChanged": False},
                    "resources": {"subscribe": False, "listChanged": False},
                    "prompts": {"listChanged": False},
                },
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}}

    if method == "tools/list":
        return {"tools": TOOLS}

    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments", {}) or {}
        handler = HANDLERS.get(name)
        if handler is None:
            return {"content": [{"type": "text", "text": "unknown tool: " + str(name)}],
                    "isError": True}
        try:
            result = handler(args)
            text = json.dumps(result, ensure_ascii=False, indent=2, default=str)
            return {"content": [{"type": "text", "text": text}], "isError": False}
        except Exception as e:
            log("tool %s failed: %s\n%s" % (name, e, traceback.format_exc()))
            text = "tool %s failed: %s\n%s" % (name, e, traceback.format_exc())
            return {"content": [{"type": "text", "text": text}], "isError": True}

    if method == "ping":
        return {}

    if method == "resources/list":
        res = []
        for r in RESOURCE_DEFS:
            res.append({"uri": r["uri"], "name": r["name"],
                        "description": r["description"], "mimeType": "text/plain"})
        return {"resources": res}

    if method == "resources/read":
        uri = params.get("uri", "")
        for r in RESOURCE_DEFS:
            if r["uri"] == uri:
                if not os.path.isfile(r["path"]):
                    return {"contents": [{"uri": uri, "mimeType": "text/plain",
                                          "text": "(resource file missing: %s)" % r["path"]}]}
                return {"contents": [{"uri": uri, "mimeType": "text/plain",
                                      "text": _load_text(r["path"])}]}
        return {"contents": [{"uri": uri, "mimeType": "text/plain",
                              "text": "unknown resource: " + str(uri)}]}

    if method == "prompts/list":
        prompts = []
        for p in PROMPT_DEFS:
            prompts.append({"name": p["name"], "description": p["description"],
                            "arguments": []})
        return {"prompts": prompts}

    if method == "prompts/get":
        pname = params.get("name", "")
        for p in PROMPT_DEFS:
            if p["name"] == pname:
                return {"description": p["description"],
                        "messages": [{"role": "user",
                                      "content": {"type": "text", "text": p["text"]}}]}
        return {"description": "", "messages": [{"role": "user",
                "content": {"type": "text", "text": "unknown prompt: " + str(pname)}}]}

    # unknown request method -> error per JSON-RPC
    return None


def main_loop():
    stdin = sys.stdin
    buffer = ""
    while True:
        chunk = stdin.readline()
        if not chunk:
            break
        line = chunk.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue
        method = msg.get("method")
        req_id = msg.get("id")
        if method and method.startswith("notifications/"):
            continue  # no response for notifications
        if req_id is None:
            continue
        response = {"jsonrpc": "2.0", "id": req_id}
        try:
            result = handle_request(msg)
            if result is None:
                response["error"] = {"code": -32601, "message": "method not found: " + str(method)}
            else:
                response["result"] = result
        except Exception as e:
            response["error"] = {"code": -32603,
                                 "message": str(e) + "\n" + traceback.format_exc()}
        send_message(response)


def _tty_banner_and_wait(input_fn=input):
    """Double-click protection: when run manually in a console window
    (stdin is a tty), explain what this file is instead of sitting in a
    meaningless black window."""
    sys.stdout.write(
        "\n[小文老师Inoproshop MCP] 这个脚本是给 AI 客户端调用的，不需要手动运行。\n"
        "正确用法：双击 安装向导.cmd 完成配置，之后客户端会自动调用本脚本。\n"
        "十天学会PLC！业务电话：15929878510\n"
        "官方主页：https://space.bilibili.com/455446576\n\n")
    sys.stdout.flush()
    try:
        input_fn(u"按回车退出...")
    except Exception:
        pass


def main():
    try:
        log("mcp server started (python %s)" % sys.version)
        # startup environment gate: popup + exit when the host does not match
        startup_env_gate()
        # manual double-click guard (MCP clients use a pipe, never a tty)
        try:
            is_tty = sys.stdin.isatty()
        except Exception:
            is_tty = False
        if is_tty:
            _tty_banner_and_wait()
            return
        main_loop()
    except SystemExit:
        raise
    except KeyboardInterrupt:
        pass
    except Exception as e:
        log("fatal: %s\n%s" % (e, traceback.format_exc()))
        raise


if __name__ == "__main__":
    import winreg  # noqa: F401  (Windows registry, used in exe_path)
    main()
