# -*- coding: utf-8 -*-
"""
InoProShop Bridge
=================
Runs INSIDE InoProShop's ScriptEngine (embedded Python 2.7) via:

    InoProShop.exe --profile="InoProShop(V1.10.0.3)" --runscript="<this file>"

The bridge keeps the IDE alive and executes JSON commands written by the
external MCP server using a file-based request/result protocol:

    <bridge dir>/requests/<id>.json   -> command  (written by MCP server)
    <bridge dir>/results/<id>.json    -> response (written by bridge)
    <bridge dir>/bridge.ready         -> readiness marker
    <bridge dir>/bridge.log           -> diagnostic log

Compatible with Python 2.7 and Python 3.x.
"""
from __future__ import print_function

import sys
import os
import io
import re
import json
import time
import shutil
import traceback
import datetime

PY2 = sys.version_info[0] == 2

BRIDGE_DIR = os.environ.get(
    "INOSHOP_BRIDGE_DIR",
    os.path.join(os.environ.get("TEMP", r"C:\Temp"), "inoshop-mcp"),
)
REQUEST_DIR = os.path.join(BRIDGE_DIR, "requests")
PROCESSING_DIR = os.path.join(BRIDGE_DIR, "processing")
RESULT_DIR = os.path.join(BRIDGE_DIR, "results")
READY_PATH = os.path.join(BRIDGE_DIR, "bridge.ready")
LOG_PATH = os.path.join(BRIDGE_DIR, "bridge.log")
POLL_INTERVAL_SEC = 0.2
HEARTBEAT_PATH = os.path.join(BRIDGE_DIR, "bridge.heartbeat")
# After this many ms without requests the bridge saves the project and ends
# the script. A normally-ended script leaves the IDE OPEN and interactive
# (the UI is blocked while a script is running - this is the release valve).
IDLE_EXIT_MS = 0
try:
    IDLE_EXIT_MS = int(os.environ.get("INOSHOP_IDLE_EXIT_MS", "180000"))
except Exception:
    IDLE_EXIT_MS = 180000

CURRENT_PROJECT = None
CURRENT_PROJECT_PATH = None
SHUTDOWN_FLAG = False


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def to_unicode(value):
    if value is None:
        return u""
    if isinstance(value, unicode if PY2 else str):
        return value
    if PY2 and isinstance(value, str):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("utf-8", "replace")
    try:
        return unicode(value) if PY2 else str(value)
    except Exception:
        return u""


def safe_str(value):
    try:
        return to_unicode(value)
    except Exception:
        return u"<unprintable>"


def ensure_dirs():
    for d in (BRIDGE_DIR, REQUEST_DIR, PROCESSING_DIR, RESULT_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)


def log(message):
    try:
        ensure_dirs()
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with io.open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(u"[%s] %s\n" % (to_unicode(ts), to_unicode(message)))
    except Exception:
        pass


def read_json(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path, obj):
    ensure_dirs()
    tmp = path + ".tmp"
    # ensure_ascii=True: InoProShop returns object names in the ANSI codepage,
    # and IronPython's json encoder cannot mix them with unicode safely.
    data = json.dumps(obj, ensure_ascii=True, indent=2, default=safe_str)
    if PY2 and isinstance(data, str):
        data = data.decode("utf-8")
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(data)
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass
    os.rename(tmp, path)


def touch_ready():
    try:
        ensure_dirs()
        with io.open(READY_PATH, "w", encoding="utf-8") as f:
            f.write(u"ready\n")
    except Exception:
        pass


def heartbeat():
    try:
        ensure_dirs()
        with io.open(HEARTBEAT_PATH, "w", encoding="utf-8") as f:
            f.write(to_unicode(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    except Exception:
        pass


def obj_name(obj):
    try:
        return safe_str(obj.get_name())
    except Exception:
        return safe_str(obj)


def has(obj, name):
    try:
        return hasattr(obj, name)
    except Exception:
        return False


def obj_path(obj):
    """Best-effort 'a.b.c' path of an object."""
    parts = []
    seen = set()
    current = obj
    for _ in range(30):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        try:
            nm = current.get_name()
            if nm is None or safe_str(nm) == u"":
                break
            parts.append(safe_str(nm))
        except Exception:
            break
        try:
            parent = current.parent
        except Exception:
            try:
                parent = current.get_parent()
            except Exception:
                parent = None
        current = parent
    parts.reverse()
    return u".".join(parts)


def walk_tree(obj, depth, max_depth, out):
    out.append((depth, obj_name(obj), type(obj).__name__))
    if depth >= max_depth:
        return
    try:
        children = obj.get_children(False)
    except Exception:
        try:
            children = obj.get_children()
        except Exception:
            children = []
    try:
        for child in children:
            walk_tree(child, depth + 1, max_depth, out)
    except Exception:
        pass


def find_object(root, name):
    """Find an object by name (first match, depth-first).
    Handles list-returning APIs (e.g. project.find returns a List)."""
    try:
        if obj_name(root) == name:
            return root
    except Exception:
        pass
    try:
        children = root.get_children(False)
    except Exception:
        try:
            children = root.get_children()
        except Exception:
            children = []
    if children is None:
        children = []
    # get_children may itself return a list; if it returned something with
    # a single .get_children free shape, normalize anyway
    try:
        if not hasattr(children, "__iter__"):
            children = [children]
    except Exception:
        children = []
    try:
        for child in children:
            found = find_object(child, name)
            if found is not None:
                return found
    except Exception:
        pass
    return None


def _resolve(root, name):
    """Resolve object by name: try project.find (may return a List), then walk."""
    if root is None:
        raise Exception("no open project")
    try:
        found = root.find(name, True)
        if found is not None:
            if hasattr(found, "get_children") or hasattr(found, "textual_declaration"):
                return found
            try:
                if len(found) > 0:
                    return found[0]
            except Exception:
                pass
    except Exception:
        pass
    found = find_object(root, name)
    if found is None:
        raise Exception("object not found: " + safe_str(name))
    return found


def normalize_newlines(text):
    text = to_unicode(text)
    text = text.replace(u"\r\n", u"\n").replace(u"\r", u"\n")
    return text.replace(u"\n", u"\r\n")


def write_text_document(part, text):
    """Write text to a ScriptTextDocument object. Returns method used.
    Note: the .text property is read-only in IronPython; the supported
    whole-document write is replace(new_text)."""
    text = to_unicode(text)
    try:
        part.replace(text)
        return "replace"
    except Exception:
        pass
    try:
        old = safe_str(part.get_text())
        if old:
            part.remove(0, len(old))
        if text:
            part.append(text)
        return "remove+append"
    except Exception:
        pass
    try:
        part.text = text
        return "assignment"
    except Exception:
        pass
    raise Exception("cannot write text document")


def read_text_document(part):
    try:
        return safe_str(part.text)
    except Exception:
        pass
    try:
        return safe_str(part.get_text())
    except Exception:
        pass
    return u""


# --------------------------------------------------------------------------
# message collection
# --------------------------------------------------------------------------
def msg_field(msg, names):
    for n in names:
        try:
            v = getattr(msg, n)
            if v is not None and safe_str(v) != u"":
                return safe_str(v)
        except Exception:
            pass
    return None


def collect_messages():
    result = {"messages": [], "errors": [], "warnings": [], "infos": []}
    try:
        sys_obj = system  # noqa: F821  (injected global)
    except Exception as e:
        result["error"] = "system global missing: " + safe_str(e)
        return result
    raw = None
    method_used = None
    if has(sys_obj, "get_messages"):
        try:
            raw = sys_obj.get_messages()
            method_used = "system.get_messages()"
        except Exception:
            raw = None
    if raw is None and has(sys_obj, "messages"):
        try:
            raw = sys_obj.messages
            method_used = "system.messages"
        except Exception:
            raw = None
    if raw is None:
        result["error"] = "no message source found"
        return result
    result["method"] = method_used
    items = []
    try:
        for m in raw:
            items.append(m)
    except Exception:
        items = [raw]
    seen = set()
    for m in items:
        text = msg_field(m, ("message", "description", "text"))
        severity = msg_field(m, ("severity", "kind", "type"))
        location = msg_field(m, ("location", "source", "sourceposition"))
        if text is None:
            text = safe_str(m)
        key = (severity or "") + "|" + (text or "") + "|" + (location or "")
        if key in seen:
            continue
        seen.add(key)
        entry = {"message": text, "severity": severity or "info", "location": location}
        result["messages"].append(entry)
        if severity and severity.lower() in ("error", "e", "3"):
            result["errors"].append(entry)
        elif severity and severity.lower() in ("warning", "w", "2"):
            result["warnings"].append(entry)
        else:
            result["infos"].append(entry)
    result["error_count"] = len(result["errors"])
    result["warning_count"] = len(result["warnings"])
    result["info_count"] = len(result["infos"])
    # compile log lines from message categories (e.g. the "编译" category)
    log_lines = []
    try:
        for cat in sys_obj.get_message_categories():
            try:
                objs = sys_obj.get_message_objects(cat)
            except Exception:
                continue
            try:
                for o in objs:
                    log_lines.append(safe_str(o))
            except Exception:
                pass
    except Exception:
        pass
    result["log"] = log_lines
    err_n = None
    warn_n = None
    for s in log_lines:
        m = re.search(u"([0-9]+)\\s*\\u9519\\u8bef", s)  # "N 错误"
        if m:
            err_n = int(m.group(1))
        m = re.search(u"([0-9]+)\\s*\\u8b66\\u544a", s)  # "N 警告"
        if m:
            warn_n = int(m.group(1))
        m = re.search(u"([0-9]+)\\s*errors?", s, re.IGNORECASE)
        if m:
            err_n = int(m.group(1))
        m = re.search(u"([0-9]+)\\s*warnings?", s, re.IGNORECASE)
        if m:
            warn_n = int(m.group(1))
    if err_n is not None:
        result["error_count"] = max(result["error_count"], err_n)
        result["error_count_from_log"] = err_n
    if warn_n is not None:
        result["warning_count"] = max(result["warning_count"], warn_n)
        result["warning_count_from_log"] = warn_n
    return result


# --------------------------------------------------------------------------
# operations
# --------------------------------------------------------------------------
def op_ping(params):
    info = {
        "python": sys.version,
        "bridge_dir": BRIDGE_DIR,
        "project": obj_name(CURRENT_PROJECT) if CURRENT_PROJECT is not None else None,
        "project_path": CURRENT_PROJECT_PATH,
    }
    return info


def _primary_or_none():
    try:
        p = projects.primary  # noqa: F821
        return p
    except Exception:
        return None


def op_project_open(params):
    global CURRENT_PROJECT, CURRENT_PROJECT_PATH
    path = params.get("path")
    if not path:
        raise Exception("path required")
    path = os.path.abspath(path)
    # reuse if already the current one
    if CURRENT_PROJECT is not None:
        try:
            if CURRENT_PROJECT_PATH == path:
                return {"project": obj_name(CURRENT_PROJECT), "path": path, "reused": True}
        except Exception:
            pass
        # close current before opening another
        # (OEM builds may lack projects.close; project.close() is the
        # reliable method, projects.close is the fallback)
        try:
            CURRENT_PROJECT.close()
        except Exception:
            try:
                projects.close(CURRENT_PROJECT)  # noqa: F821
            except Exception as e:
                log("close failed: " + safe_str(e))
    last_err = None
    project = None
    # 1) open with silent/no-update flags (avoids modal dialogs)
    try:
        flags = VersionUpdateFlags.NoUpdates | VersionUpdateFlags.SilentMode  # noqa: F821
        project = projects.open(path, update_flags=flags)  # noqa: F821
    except Exception as e:
        last_err = e
    # 2) open path directly
    if project is None:
        try:
            project = projects.open(path)  # noqa: F821
        except Exception as e:
            last_err = e
    # 2) a primary project may already match
    if project is None:
        try:
            primary = _primary_or_none()
            if primary is not None:
                p = None
                try:
                    p = primary.path
                except Exception:
                    p = None
                if p and os.path.normcase(os.path.abspath(safe_str(p))) == os.path.normcase(path):
                    project = primary
        except Exception:
            pass
    if project is None:
        raise Exception("open failed: " + safe_str(last_err))
    CURRENT_PROJECT = project
    CURRENT_PROJECT_PATH = path
    return {"project": obj_name(project), "path": path}


def op_project_create(params):
    global CURRENT_PROJECT, CURRENT_PROJECT_PATH
    path = params.get("path")
    if not path:
        raise Exception("path required")
    path = os.path.abspath(path)
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    if os.path.exists(path):
        raise Exception("project already exists: " + safe_str(path))
    if CURRENT_PROJECT is not None:
        try:
            projects.close(CURRENT_PROJECT)  # noqa: F821
        except Exception:
            pass
        CURRENT_PROJECT = None
        CURRENT_PROJECT_PATH = None
    project = projects.create(path)  # noqa: F821
    CURRENT_PROJECT = project
    CURRENT_PROJECT_PATH = path
    return {"project": obj_name(project), "path": path}


def op_project_save(params):
    global CURRENT_PROJECT_PATH
    if CURRENT_PROJECT is None:
        raise Exception("no open project")
    target = params.get("path")
    if target:
        target = os.path.abspath(target)
        CURRENT_PROJECT.save_as(target)
        CURRENT_PROJECT_PATH = target
        return {"method": "save_as", "path": target}
    try:
        CURRENT_PROJECT.save()
        return {"method": "save"}
    except Exception as e1:
        # project may have been opened read-only (e.g. a sample project)
        try:
            CURRENT_PROJECT.save_as(CURRENT_PROJECT_PATH)
            return {"method": "save_as_same_path", "save_error": safe_str(e1)}
        except Exception as e2:
            raise Exception("save failed (save: %s | save_as: %s)" % (e1, e2))


def op_project_close(params):
    global CURRENT_PROJECT, CURRENT_PROJECT_PATH
    if CURRENT_PROJECT is None:
        return {"closed": False}
    save = bool(params.get("save", False))
    if save:
        try:
            CURRENT_PROJECT.save()
        except Exception as e:
            log("save on close failed: " + safe_str(e))
    method = None
    err = None
    try:
        CURRENT_PROJECT.close()
        method = "project.close()"
    except Exception as e1:
        try:
            projects.close(CURRENT_PROJECT)  # noqa: F821
            method = "projects.close(project)"
        except Exception as e2:
            err = "%s | %s" % (e1, e2)
            log("close failed: " + safe_str(err))
    CURRENT_PROJECT = None
    CURRENT_PROJECT_PATH = None
    return {"closed": method is not None, "method": method, "error": err}


def op_project_info(params):
    if CURRENT_PROJECT is None:
        primary = _primary_or_none()
        return {"open": False, "primary": obj_name(primary) if primary is not None else None}
    info = {"open": True, "name": obj_name(CURRENT_PROJECT), "path": CURRENT_PROJECT_PATH}
    try:
        app = CURRENT_PROJECT.active_application
        info["active_application"] = obj_name(app)
    except Exception as e:
        info["active_application"] = "ERR: " + safe_str(e)
    try:
        devices = []
        try:
            children = CURRENT_PROJECT.get_children(False)
        except Exception:
            children = CURRENT_PROJECT.get_children()
        for c in children:
            if "device" in type(c).__name__.lower() or has(c, "device_type"):
                devices.append(obj_name(c))
        info["devices"] = devices
    except Exception:
        pass
    return info


def op_tree(params):
    root = CURRENT_PROJECT
    if root is None:
        raise Exception("no open project")
    max_depth = int(params.get("max_depth", 3))
    out = []
    walk_tree(root, 0, max_depth, out)
    lines = []
    for depth, name, t in out:
        lines.append((u"  " * depth) + name + u"  [" + t + u"]")
    return {"tree": lines}


def op_find(params):
    name = params.get("name")
    if not name:
        raise Exception("name required")
    found = find_object(CURRENT_PROJECT, name)
    if found is None:
        return {"found": False}
    info = {
        "found": True,
        "path": obj_path(found),
        "type": type(found).__name__,
        "has_declaration": has(found, "textual_declaration"),
        "has_implementation": has(found, "textual_implementation"),
    }
    return info


def op_create_pou(params):
    if CURRENT_PROJECT is None:
        raise Exception("no open project")
    name = params.get("name")
    if not name:
        raise Exception("name required")
    pou_type_name = params.get("type", "Program")
    try:
        pou_type = getattr(PouType, pou_type_name)  # noqa: F821
    except Exception:
        raise Exception("invalid POU type: " + safe_str(pou_type_name) +
                        " (use Program/Function/FunctionBlock)")
    parent_name = params.get("parent", None)
    if parent_name:
        parent = _resolve(CURRENT_PROJECT, parent_name)
    else:
        try:
            parent = CURRENT_PROJECT.active_application
        except Exception:
            parent = _resolve(CURRENT_PROJECT, "Application")

    return_type = params.get("return_type")
    pou = None
    last_err = None
    attempts = [
        ("create_pou(name, pou_type)", lambda: parent.create_pou(name, pou_type)),
        ("create_pou(name, pou_type, None)",
         lambda: parent.create_pou(name, pou_type, None)),
        ("create_pou(name=name, type=pou_type)",
         lambda: parent.create_pou(name=name, type=pou_type)),
    ]
    if return_type:
        attempts.append(
            ("create_pou(name, pou_type, None, return_type)",
             lambda: parent.create_pou(name, pou_type, None, return_type))
        )
    for label, fn in attempts:
        try:
            pou = fn()
            break
        except Exception as e:
            last_err = e
    if pou is None:
        raise Exception("create_pou failed: " + safe_str(last_err))

    written = {}
    declaration = params.get("declaration")
    if declaration is not None:
        written["declaration"] = write_text_document(pou.textual_declaration,
                                                     normalize_newlines(declaration))
    implementation = params.get("implementation")
    if implementation is not None:
        if not has(pou, "textual_implementation"):
            raise Exception("POU has no textual_implementation")
        written["implementation"] = write_text_document(pou.textual_implementation,
                                                        normalize_newlines(implementation))
    return {"name": name, "type": pou_type_name, "written": written}


def _read_part(obj, part):
    if part == "declaration":
        if not has(obj, "textual_declaration"):
            raise Exception("object has no textual_declaration")
        return read_text_document(obj.textual_declaration)
    if part == "implementation":
        if not has(obj, "textual_implementation"):
            raise Exception("object has no textual_implementation")
        return read_text_document(obj.textual_implementation)
    raise Exception("part must be 'declaration' or 'implementation'")


def op_read_text(params):
    name = params.get("object")
    part = params.get("part", "implementation")
    obj = _resolve(CURRENT_PROJECT, name)
    text = _read_part(obj, part)
    return {"object": name, "part": part, "text": text}


def op_write_text(params):
    name = params.get("object")
    part = params.get("part", "implementation")
    mode = params.get("mode", "replace")
    text = params.get("text", u"")
    obj = _resolve(CURRENT_PROJECT, name)

    if mode == "replace":
        new_text = to_unicode(text)
    else:
        old = _read_part(obj, part)
        if mode == "append":
            new_text = old + (u"\r\n" if not old.endswith(u"\r\n") else u"") + to_unicode(text)
        elif mode == "prepend":
            new_text = to_unicode(text) + (u"\r\n" if not to_unicode(text).endswith(u"\r\n") else u"") + old
        elif mode == "replace_all":
            search = params.get("search")
            repl = params.get("replace", u"")
            if search is None:
                raise Exception("search required for replace_all")
            new_text = old.replace(to_unicode(search), to_unicode(repl))
        elif mode == "replace_first":
            search = params.get("search")
            repl = params.get("replace", u"")
            if search is None:
                raise Exception("search required for replace_first")
            new_text = old.replace(to_unicode(search), to_unicode(repl), 1)
        elif mode == "insert_before":
            anchor = params.get("anchor")
            if anchor is None:
                raise Exception("anchor required for insert_before")
            i = old.find(to_unicode(anchor))
            if i < 0:
                raise Exception("anchor not found")
            new_text = old[:i] + to_unicode(text) + old[i:]
        elif mode == "insert_after":
            anchor = params.get("anchor")
            if anchor is None:
                raise Exception("anchor required for insert_after")
            i = old.find(to_unicode(anchor))
            if i < 0:
                raise Exception("anchor not found")
            new_text = old[:i + len(to_unicode(anchor))] + to_unicode(text) + old[i + len(to_unicode(anchor)):]
        else:
            raise Exception("unknown mode: " + safe_str(mode))

    written = write_text_document(
        obj.textual_declaration if part == "declaration" else obj.textual_implementation,
        normalize_newlines(new_text),
    )
    return {"object": name, "part": part, "mode": mode, "written": written}


def op_delete_object(params):
    name = params.get("name")
    if not name:
        raise Exception("name required")
    obj = _resolve(CURRENT_PROJECT, name)
    try:
        parent = obj.parent
    except Exception:
        try:
            parent = obj.get_parent()
        except Exception:
            raise Exception("cannot resolve parent of " + safe_str(name))
    try:
        parent.remove(obj)
        return {"deleted": name, "method": "parent.remove"}
    except Exception:
        pass
    try:
        parent.delete_object(obj)
        return {"deleted": name, "method": "parent.delete_object"}
    except Exception as e:
        raise Exception("delete failed: " + safe_str(e))


def op_build(params):
    if CURRENT_PROJECT is None:
        raise Exception("no open project")
    try:
        app = CURRENT_PROJECT.active_application
    except Exception:
        app = _resolve(CURRENT_PROJECT, "Application")
    try:
        build_result = app.build()
        result = {"build_result": safe_str(build_result)}
    except Exception as e:
        result = {"build_exception": safe_str(e),
                  "build_traceback": traceback.format_exc()}
    msgs = collect_messages()
    result.update(msgs)
    result["success"] = (msgs.get("error_count", 0) == 0 and "build_exception" not in result)
    return result


def op_messages(params):
    return collect_messages()


def op_eval(params):
    code = params.get("code")
    if not code:
        raise Exception("code required")
    ns = dict(globals())
    ns["project"] = CURRENT_PROJECT
    try:
        ns["app"] = CURRENT_PROJECT.active_application
    except Exception:
        ns["app"] = None
    # capture prints
    try:
        import StringIO as _sio  # py2
    except ImportError:
        import io as _sio_mod
        _sio = _sio_mod
    buf = _sio.StringIO()
    old_stdout = sys.stdout
    sys.stdout = buf
    try:
        try:
            value = eval(code, ns, ns)  # expression?
        except SyntaxError:
            if PY2:
                exec("exec code in ns")
            else:
                exec(code, ns)
            value = None
    finally:
        sys.stdout = old_stdout
    printed = buf.getvalue()
    out = {"printed": safe_str(printed)}
    if value is not None:
        out["value"] = safe_str(value)
    elif "result" in ns and ns["result"] is not None:
        out["value"] = safe_str(ns["result"])
    return out


def op_shutdown(params):
    """Graceful release: save the project, then end the script normally.
    The IDE stays open and the UI becomes interactive again."""
    result = {"saved": None}
    if CURRENT_PROJECT is not None:
        result["saved"] = _save_current(CURRENT_PROJECT)
    log("shutdown requested (graceful release)")
    return result


def op_exit_ide(params):
    """Close the IDE completely (script engine system.exit())."""
    log("exit_ide requested")
    return {"exiting": True}


OPS = {
    "ping": op_ping,
    "shutdown": op_shutdown,
    "project_open": op_project_open,
    "project_create": op_project_create,
    "project_save": op_project_save,
    "project_close": op_project_close,
    "project_info": op_project_info,
    "tree": op_tree,
    "find": op_find,
    "create_pou": op_create_pou,
    "read_text": op_read_text,
    "write_text": op_write_text,
    "delete_object": op_delete_object,
    "build": op_build,
    "messages": op_messages,
    "eval": op_eval,
    "exit_ide": op_exit_ide,
}


def _save_current(project):
    try:
        project.save()
        return "save"
    except Exception as e1:
        try:
            project.save_as(CURRENT_PROJECT_PATH)
            return "save_as_same_path (%s)" % safe_str(e1)
        except Exception as e2:
            return "save failed: %s | %s" % (e1, e2)


# --------------------------------------------------------------------------
# main loop
# --------------------------------------------------------------------------
def process_request(path):
    global SHUTDOWN_FLAG
    req_id = os.path.splitext(os.path.basename(path))[0]
    processing_path = os.path.join(PROCESSING_DIR, os.path.basename(path))
    result_path = os.path.join(RESULT_DIR, req_id + ".json")
    try:
        shutil.move(path, processing_path)
    except Exception:
        processing_path = path
    response = {"id": req_id}
    heartbeat()
    try:
        request = read_json(processing_path)
        op = request.get("op")
        params = request.get("params", {}) or {}
        log("REQ " + req_id + " " + op + " " + safe_str(params)[:300])
        if op not in OPS:
            raise Exception("unknown op: " + safe_str(op))
        result = OPS[op](params)
        response["ok"] = True
        response["result"] = result
        if op == "shutdown":
            SHUTDOWN_FLAG = True
        if op == "exit_ide":
            # respond first, then let the IDE terminate itself
            try:
                write_json(result_path, response)
            except Exception:
                pass
            log("bridge exiting IDE via system.exit()")
            system.exit()  # noqa: F821  (closes the IDE in --runscript mode)
    except SystemExit:
        raise
    except Exception as e:
        response["ok"] = False
        response["error"] = safe_str(e)
        response["traceback"] = traceback.format_exc()
        log("ERR " + req_id + " " + safe_str(e))
    try:
        write_json(result_path, response)
    except Exception as e:
        log("write result failed: " + safe_str(e))
    finally:
        try:
            if os.path.exists(processing_path):
                os.remove(processing_path)
        except Exception:
            pass


def suppress_prompts():
    """Silently suppress modal prompts so automation never blocks on a dialog."""
    try:
        # PromptHandling.None is a .NET enum member; use getattr because
        # "None" is a Python keyword and X.None is a syntax error in CPython.
        system.prompt_handling = getattr(PromptHandling, "None")  # noqa: F821
        return "PromptHandling.None"
    except Exception:
        try:
            system.prompt_handling = 0  # noqa: F821
            return "0"
        except Exception as e:
            return "failed: " + safe_str(e)


def _pump_ui():
    """Pump the IDE message loop so the GUI stays interactive while the
    bridge script runs. Without this, InoProShop's tree/editor clicks stop
    responding during a long-running script."""
    try:
        system.process_messageloop()  # noqa: F821
        return True
    except Exception:
        try:
            system.delay(1)  # noqa: F821  (delay also processes messages)
            return True
        except Exception:
            return False


def main_loop():
    global SHUTDOWN_FLAG
    ensure_dirs()
    touch_ready()
    heartbeat()  # write heartbeat immediately: the MCP server treats a
                 # fresh ready+heartbeat as alive; avoid a liveness gap
    log("bridge started, python=" + safe_str(sys.version))
    log("prompt_handling -> " + safe_str(suppress_prompts()))
    log("idle_exit_ms=" + safe_str(IDLE_EXIT_MS))
    counter = 0
    last_activity = time.time()
    while True:
        counter += 1
        if counter % 25 == 0:
            heartbeat()
        if counter % 5 == 0:
            _pump_ui()
        try:
            reqs = [f for f in os.listdir(REQUEST_DIR) if f.endswith(".json")]
        except Exception:
            reqs = []
        if reqs:
            reqs.sort()
            for f in reqs:
                process_request(os.path.join(REQUEST_DIR, f))
            last_activity = time.time()
        else:
            # idle exit: save the project, then end the script normally.
            # A normally-ended script leaves the IDE open and interactive.
            if IDLE_EXIT_MS > 0 and (time.time() - last_activity) * 1000.0 > IDLE_EXIT_MS:
                log("idle timeout: saving project and releasing UI")
                if CURRENT_PROJECT is not None:
                    log("idle save -> " + safe_str(_save_current(CURRENT_PROJECT)))
                SHUTDOWN_FLAG = True
            try:
                system.delay(int(POLL_INTERVAL_SEC * 1000))  # noqa: F821
            except Exception:
                time.sleep(POLL_INTERVAL_SEC)
        if SHUTDOWN_FLAG:
            break
        if counter % 500 == 0:
            log("bridge alive, processed heartbeat")
    # clean exit: remove markers so the MCP server immediately sees the
    # bridge is gone, then end the script (IDE remains open, UI interactive)
    for marker in (READY_PATH, HEARTBEAT_PATH):
        try:
            if os.path.exists(marker):
                os.remove(marker)
        except Exception:
            pass
    log("bridge script ended normally (IDE stays open, UI released)")


if __name__ == "__main__":
    main_loop()
