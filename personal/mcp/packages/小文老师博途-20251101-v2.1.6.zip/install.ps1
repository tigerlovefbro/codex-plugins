﻿# ============================================================
# install.ps1 - TIA MCP 一键安装器
# 双击 install.bat 运行。自动完成:
#   1. 检查 Node.js (没有则打开下载页)
#   2. 启用 Openness 权限 (弹 UAC, 点 是)
#   3. 自动写入 Claude Desktop / Cursor 的 MCP 配置 (若已安装)
#   4. 生成"快速开始.txt"速查卡
#   5. 运行自检
# ============================================================
param(
    [switch]$SkipPermission,
    [switch]$SkipSelfCheck
)
$ErrorActionPreference = 'Continue'
try { cmd /c "chcp 65001" | Out-Null } catch {}
$dir = $PSScriptRoot

# 转录日志(排查闪退用)
$logPath = Join-Path $env:TEMP 'xiaowen-mcp-install.log'
try { Start-Transcript -Path $logPath -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
try {
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { $OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

Write-Host ''
Write-Host '===== TIA MCP 一键安装 =====' -ForegroundColor Cyan

# ---------- 1. Node.js ----------
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) {
    # 兜底: DeepSeek Harness 自带 Node (本机场景)
    $dshNode = Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'
    if (Test-Path $dshNode) {
        $node = $dshNode
        $env:PATH = (Split-Path $dshNode) + ';' + $env:PATH
    }
}
if (-not $node) {
    Write-Host '[1/4] Node.js 未安装，正在打开下载页...' -ForegroundColor Yellow
    Write-Host '请下载 LTS 版并安装，装完重新双击 install.bat。'
    Start-Process 'https://nodejs.org/zh-cn'
    Read-Host '按回车退出'
    exit 1
}
Write-Host "[1/4] Node.js 已就绪: $node" -ForegroundColor Green

# ---------- 2. Openness 权限 ----------
if (-not $SkipPermission) {
    Write-Host '[2/4] 正在启用 Openness 权限（弹出 UAC 窗口，请点“是”）...' -ForegroundColor Yellow
    $perm = Join-Path $dir 'enable-tia-openness.ps1'
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$perm`"") `
        -Verb RunAs -Wait
    # 用 Unicode 原生的 cmdlet 检查成员(避免 net 在中文环境下的编码误判)
    $inGroup = $false
    try {
        $members = @(Get-LocalGroupMember -Group 'Siemens TIA Openness' -ErrorAction SilentlyContinue)
        $mySid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        $inGroup = [bool]($members | Where-Object { $_.SID.Value -eq $mySid })
    } catch { $inGroup = $false }
    if ($inGroup) { Write-Host '[2/4] 权限已启用(组内成员确认)' -ForegroundColor Green }
    else {
        Write-Host '[2/4] 组内未找到当前用户（UAC 被取消? 稍后可手动重跑 enable-tia-openness.ps1）' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '[退出代码 4] Openness 权限未启用。修复: 右键 enable-tia-openness.ps1 以管理员运行(UAC 点 是), 然后注销重登。' -ForegroundColor Red
        Read-Host '按回车退出'
        exit 4
    }
}

# ---------- 3. 自动配置 AI 客户端 ----------
$serverJs = Join-Path $dir 'server.js'
$entry = @{ command = $node; args = @($serverJs) }

function Add-McpEntry([string]$file) {
    $obj = $null
    if (Test-Path $file) {
        try { $obj = Get-Content $file -Raw | ConvertFrom-Json } catch { $obj = $null }
    }
    if (-not $obj -or -not ($obj | Get-Member -Name 'mcpServers' -ErrorAction SilentlyContinue)) {
        $obj = [pscustomobject]@{ mcpServers = @{} }
    }
    $servers = $obj.mcpServers
    if (-not ($servers | Get-Member -Name 'tia-portal' -ErrorAction SilentlyContinue)) {
        $servers | Add-Member -NotePropertyName 'tia-portal' -NotePropertyValue $entry -Force
    }
    $json = $obj | ConvertTo-Json -Depth 6
    Set-Content -Path $file -Value $json -Encoding UTF8
}

$claudeDir = Join-Path $env:APPDATA 'Claude'
$claudeCfg = Join-Path $claudeDir 'claude_desktop_config.json'
if (Test-Path $claudeDir) {
    Add-McpEntry $claudeCfg
    Write-Host '[3/4] Claude Desktop 配置已写入' -ForegroundColor Green
}

$cursorCfg = Join-Path $env:USERPROFILE '.cursor\mcp.json'
if (Test-Path (Split-Path $cursorCfg)) {
    Add-McpEntry $cursorCfg
    Write-Host '[3/4] Cursor 配置已写入' -ForegroundColor Green
}

# DSH / 其他客户端: 打印配置片段
Write-Host '[3/4] 其他客户端（DSH 等）请手动添加 stdio 服务器:' -ForegroundColor Yellow
Write-Host ("    command: `"$node`"" )
Write-Host ("    args: `"$serverJs`"" )

# ---------- 4. 速查卡 ----------
$card = Join-Path $dir '快速开始.txt'
@"
【TIA AI 助手 - 三句话上手】
1. 注销 Windows 并重新登录（仅第一次需要）。
2. 打开你的 AI 客户端（Claude Desktop / Cursor / DSH）。
3. 直接对它说：
   "打开博途，新建一个叫 Test 的工程，加一台 CPU 1511-1 PN，
    建一个叫 星三角启动 的 FC，然后列出所有块给我看。"
第一次连接博途会弹"Openness 访问"确认框，点"是"即可。
常见问题: 卡住就关掉博途重新打开; 详见 README.md
"@ | Set-Content -Path $card -Encoding UTF8
Write-Host "[4/4] 速查卡已生成: $card" -ForegroundColor Green

# ---------- 5. 自检 ----------
if (-not $SkipSelfCheck) {
    Write-Host ''
    Write-Host '正在运行自检...' -ForegroundColor Cyan
    # 组权限在注销重登前不会进令牌, 此场景跳过连接测试, 避免必然失败误导
    $inToken = $false
    try {
        $grp = Get-LocalGroup -Name 'Siemens TIA Openness' -ErrorAction SilentlyContinue
        if ($grp) {
            $mySid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
            $inToken = [bool]([Security.Principal.WindowsIdentity]::GetCurrent().Groups | Where-Object { $_.Value -eq $grp.SID.Value })
        }
    } catch { $inToken = $false }
    if ($inToken) {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dir 'selfcheck.ps1')
    } else {
        Write-Host '刚加入的组尚未生效（需注销重登），自检第 3 步(连接博途)已跳过。' -ForegroundColor Yellow
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dir 'selfcheck.ps1') -SkipAttach
    }
    $scCode = $LASTEXITCODE
    if ($scCode -ne 0) {
        Write-Host ''
        Write-Host "[退出代码 $scCode] 自检未通过, 修复后重跑本安装即可。" -ForegroundColor Red
        Read-Host '按回车退出'
        exit $scCode
    }
}

Write-Host ''
Write-Host '===== 安装完成 =====' -ForegroundColor Green
Write-Host '现在: 注销并重新登录 Windows，然后打开 AI 客户端直接说需求。'
Write-Host '注销重登后建议再双击一次 一键安装.bat 确认全部通过。'
Write-Host ''
Write-Host '[退出代码 0] 全部通过。' -ForegroundColor Green
Read-Host '按回车退出'
exit 0
}
catch {
    Write-Host ''
    Write-Host '===== 安装异常退出(错误已记录) =====' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host ''
    Write-Host "请把日志文件发给小文老师排查: $logPath" -ForegroundColor Cyan
    Write-Host '常见原因: 1) 压缩包未完整解压(请先"全部解压"再运行) 2) 公司策略限制 PowerShell'
    Read-Host '按回车退出'
}
finally {
    try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch {}
}
