﻿# ============================================================
# demo-go.ps1 v2 - GO 演示脚本（断点续跑版）
# 流程: 连接博途 -> 建工程 -> 挂CPU -> 生成5个FC -> 建17标签 -> 导入LAD Main -> 保存
# 每个步骤幂等: 已完成的自动跳过, 中途失败可重跑本脚本续传。
# 唯一脆弱点(LAD导入)加了超时保护: 超时不杀进程(避免连累博途), 提示稍后重跑。
# ============================================================
$ErrorActionPreference = 'Stop'
# ---------- 自动探测 TIA Openness (V17~V21) ----------
function Find-TiaOpenness {
    $candidates = @()
    foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $root) { continue }
        foreach ($v in @(21, 20, 19, 18, 17)) {
            $portal = Join-Path $root "Siemens\Automation\Portal V$v"
            if (-not (Test-Path $portal)) { continue }
            $apiRoot = Join-Path $portal 'PublicAPI'
            if (Test-Path $apiRoot) {
                foreach ($sub in @(Get-ChildItem $apiRoot -Directory -ErrorAction SilentlyContinue)) {
                    $net48 = Join-Path $sub.FullName 'net48'
                    if (Test-Path (Join-Path $net48 'Siemens.Engineering.Base.dll')) {
                        $candidates += @{ dir = $net48; pub = (Join-Path $portal 'Bin\PublicAPI') }
                    }
                }
            }
        }
    }
    foreach ($c in $candidates) {
        if ((Test-Path (Join-Path $c.pub 'Siemens.Engineering.Contract.dll')) -and
            (Test-Path (Join-Path $c.dir 'Siemens.Engineering.Base.dll'))) { return $c }
    }
    return $null
}
$openInfo = Find-TiaOpenness
if (-not $openInfo) { throw '未找到 TIA Portal Openness API (V17~V21)。' }
$OPEN_DIR = $openInfo.dir
$OPEN_PUB = $openInfo.pub
[Environment]::CurrentDirectory = $OPEN_DIR
foreach ($dll in @(
    (Join-Path $OPEN_PUB 'Siemens.Engineering.Contract.dll'),
    (Join-Path $OPEN_PUB 'Siemens.Engineering.ClientAdapter.Interfaces.dll'),
    (Join-Path $OPEN_DIR 'Siemens.Engineering.Base.dll'),
    (Join-Path $OPEN_DIR 'Siemens.Engineering.Step7.dll'))) {
    [void][System.Reflection.Assembly]::LoadFrom($dll)
}

$PKG = 'C:\Users\QWH001\Documents\deepseek-harness\default-workspace\tia-mcp'
$PROJECT_NAME = 'Demo_AI_Show'
$PROJECT_DIR  = 'C:\Users\QWH001\Desktop'
$LOG = Join-Path $env:TEMP 'demo-go.log'

function Log([string]$msg) {
    $line = "[$(Get-Date -Format 'HH:mm:ss')] $msg"
    Write-Host $line
    Add-Content -Path $LOG -Value $line -Encoding UTF8
}

function Get-Plc($proj) {
    $dev = $proj.Devices | Select-Object -First 1
    $cpu = @($dev.DeviceItems) | Where-Object { $_.TypeIdentifier -match '511-1AL03' } | Select-Object -First 1
    if (-not $cpu) { return $null }
    $mi = $cpu.GetType().GetMethod('GetService')
    $sc = $mi.MakeGenericMethod([Siemens.Engineering.HW.Features.SoftwareContainer]).Invoke($cpu, @())
    return [Siemens.Engineering.SW.PlcSoftware]$sc.Software
}

try {
    # ---------- 1. 连接博途 ----------
    $procs = [Siemens.Engineering.TiaPortal]::GetProcesses()
    if ($procs.Count -eq 0) {
        Log '博途未运行, 正在通过 API 启动...'
        $tia = New-Object Siemens.Engineering.TiaPortal([Siemens.Engineering.TiaPortalMode]::WithUserInterface)
    } else {
        $p = $procs | Where-Object { $_.Mode -eq 'WithUserInterface' } | Select-Object -First 1
        if (-not $p) { $p = $procs | Select-Object -First 1 }
        $tia = $p.Attach()
    }
    Log '1/6 博途已连接'

    # ---------- 2. 工程 ----------
    $target = Join-Path $PROJECT_DIR $PROJECT_NAME
    $proj = $tia.Projects | Where-Object { $_.Path -match $PROJECT_NAME } | Select-Object -First 1
    if ($proj) {
        Log '2/6 工程已打开, 跳过创建'
    } else {
        if (Test-Path $target) { Remove-Item $target -Recurse -Force }
        $open = @($tia.Projects); foreach ($pp in $open) { $pp.Close() }
        $proj = $tia.Projects.Create([System.IO.DirectoryInfo]$PROJECT_DIR, $PROJECT_NAME)
        Log "2/6 工程已创建: $PROJECT_NAME"
    }

    # ---------- 3. 设备 ----------
    $dev = $proj.Devices | Select-Object -First 1
    if (-not $dev) {
        $dev = $proj.Devices.CreateWithItem('OrderNumber:6ES7 511-1AL03-0AB0/V4.1', 'PLC_1', 'PLC_1')
        Log '3/6 CPU 1511-1 PN 已挂载'
    } else {
        Log "3/6 设备已存在: $($dev.Name), 跳过"
    }

    $plc = Get-Plc $proj
    if (-not $plc) { throw '未找到 PLC 软件' }

    # ---------- 4. 五个教学 FC ----------
    $haveFcs = (@($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq '电机正反转' }).Count -gt 0
    if (-not $haveFcs) {
        $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile('Demo_Blocks_LAD', (Join-Path $PKG 'demo-blocks-lad.scl'))
        $src.GenerateBlocksFromSource()
        Start-Sleep -Seconds 2
        Log '4/6 5 个教学 FC 已生成'
    } else {
        Log '4/6 教学 FC 已存在, 跳过'
    }

    # ---------- 5. 17 个标签 ----------
    $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
    $tags = @(
        @{ N='Tag_1'; T='Bool'; A='%M0.0' }, @{ N='Tag_2'; T='Bool'; A='%M0.1' },
        @{ N='Tag_3'; T='Bool'; A='%M0.2' }, @{ N='Tag_4'; T='Bool'; A='%M0.3' },
        @{ N='Tag_5'; T='Bool'; A='%M0.4' }, @{ N='Tag_6'; T='Bool'; A='%M1.0' },
        @{ N='Tag_7'; T='Bool'; A='%M1.1' }, @{ N='Tag_8'; T='Bool'; A='%M1.2' },
        @{ N='Tag_9'; T='Bool'; A='%M1.3' }, @{ N='Tag_10'; T='Int'; A='%MW10' },
        @{ N='Tag_11'; T='Real'; A='%MD12' }, @{ N='Tag_12'; T='Bool'; A='%M2.0' },
        @{ N='Tag_13'; T='Byte'; A='%MB3' }, @{ N='Tag_14'; T='Bool'; A='%M4.0' },
        @{ N='Tag_15'; T='Bool'; A='%M4.1' }, @{ N='Tag_16'; T='Bool'; A='%M4.2' },
        @{ N='Tag_17'; T='Word'; A='%MW6' }
    )
    $created = 0
    foreach ($t in $tags) {
        $existing = @($table.Tags) | Where-Object { $_.Name -eq $t.N } | Select-Object -First 1
        if (-not $existing) { $null = $table.Tags.Create($t.N, $t.T, $t.A); $created++ }
    }
    Log "5/6 标签就绪 (本次新建 $created, 共 $(@($table.Tags).Count))"

    # ---------- 6. LAD Main 导入 ----------
    # 直接在当前已授权的连接上导入(不要开新客户端, 否则会再弹授权框挂起)
    $main = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq 'Main' } | Select-Object -First 1
    if ($main -and $main.IsConsistent) {
        Log '6/6 Main 已编译通过, 跳过导入'
    } else {
        $xmlPath = Join-Path $PKG 'lad-main-demo.xml'
        try {
            $null = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$xmlPath, [Siemens.Engineering.ImportOptions]::Override)
            Log '6/6 LAD Main 导入成功 (5 网络, 实参全挂)'
        } catch {
            Log "6/6 导入失败: $($_.Exception.Message) —— 若 Main 正在编辑器打开请先关闭, 然后重跑本脚本续传。"
        }
    }

    # ---------- 保存 + 验收 ----------
    $proj.Save()
    Log '工程已保存'
    ""
    "===== 验收单 ====="
    "工程: $($proj.Name)  ($($proj.Path))"
    "设备: $($dev.Name) / CPU 6ES7 511-1AL03-0AB0 V4.1"
    @($plc.BlockGroup.Blocks) | ForEach-Object { "  块: $($_.Name) [$($_.Number)] $($_.ProgrammingLanguage)" }
    "标签: $(@($table.Tags).Count) 个"
    "日志: $LOG"
} catch {
    $e = $_.Exception
    "ERR:"
    while ($e) {
        "  $($e.GetType().FullName): $($e.Message)"
        $e = $e.InnerException
    }
    Log "失败: $($_.Exception.Message)"
}
