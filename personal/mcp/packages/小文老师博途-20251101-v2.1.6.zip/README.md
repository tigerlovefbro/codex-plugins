﻿# 小文老师 MCP（博途 AI 助手）v2.0.1

让 AI 客户端（Claude Desktop、Cursor、DeepSeek Harness 等）通过 MCP 协议操作博途 V21 的插件包。**零 npm 依赖、零 Python 依赖**，Windows 自带 PowerShell + Node.js 即可运行。18 个工具覆盖：工程管理、设备挂载、程序块创建、标签管理、**LAD 版 Main 自动生成（形参实参自动挂接）**、块导出备份。

---

## 快速开始（就 3 步）

1. **双击 `一键安装.bat`**（弹 UAC 点“是”；没装 Node 会自动打开下载页，装完再双击一次）
2. **注销 Windows 重新登录**（第一次必须）
3. **打开 AI 客户端，直接说人话**（见下文）

Claude Desktop / Cursor 已由安装器自动配好；其他客户端手动加一条 stdio 服务器：`node "C:\路径\tia-mcp\server.js"`。第一次会弹“Openness 访问”框，点“是”。

---

## 日常使用：直接说人话

AI 会自动选择对应工具，你不需要记工具名。标准话术：

**查状态**
> 博途现在什么状态？列出当前工程的所有块。

**建工程 + 挂设备**
> 新建一个叫“测试”的工程放桌面，挂一台 CPU 1511-1 PN。

**查硬件订货号（AI 自己查目录）**
> 查一下 1214C DC/DC/DC 的最新固件订货号。

**建 FC 块**
> 建一个叫“电机正反转”的 FC，形参 start、stop、reverseReq 输入，running、fault 输出，用 SCL 写启保停逻辑。

**建 FB 块（带接口和静态变量）**
> 建一个 FB“电机控制”，输入 speed:Real，输出 running:Bool，静态变量 accTime:Time，里面写 speed 大于 0 就置位 running。

**整段 SCL 导入（一次多块）**
> 把这段 SCL 导入工程：FUNCTION "FC_A"…END_FUNCTION，FUNCTION_BLOCK "FB_B"…END_FUNCTION_BLOCK

**建标签**
> 建 4 个标签：启动按钮 Bool %M0.0、停止按钮 Bool %M0.1、速度给定 Int %MW10、温度 Real %MD12

**生成 LAD 版 Main + 自动挂实参（招牌功能）**
> 在 Main 里用 LAD 调“电机正反转”，start 接 M0.0，stop 接 M0.1，reverseReq 接 M0.2，running 接 M0.3，fault 接 M0.4，每个网络写好中文标题和注释。

**导出块做模板/备份**
> 把 Main 导出成 XML 存到 D:\备份\main.xml

**切换工程**
> 关闭当前工程，打开 D:\项目\xxx.ap21

---

## 30 个工具一览

| 工具 | 说明 |
|---|---|
| `tia_status` | 连接博途并返回状态（没开博途会自动拉起） |
| `tia_diagnose` | **一键体检**：组在不在/你在不在组里/令牌刷没刷新/博途开没开，自动给修复动作 |
| `project_list` / `project_open` / `project_close` | 工程列表 / 打开 / 关闭 |
| `project_create` / `project_save` | 新建 / 保存工程 |
| `device_add` / `device_list` | 挂 S7-1500 / 设备明细 |
| `catalog_search` | 硬件目录检索（订货号、版本） |
| `blocks_list` / `block_delete` / `block_export` | 块清单 / 删除 / 导出 XML |
| `fc_create` / `fb_create` | 建 FC / 建 FB（接口可定义） |
| `scl_import` | 整段 SCL 导入，一次生成多块 |
| `tags_list` / `tags_create` / `tags_import` | 标签列表 / 批量建标签 / 变量表导入(带注释) |
| `compile_status` / `block_rename` | 编译一致性轮询 / 批量改名 |
| `lad_main_import` | **LAD 版 Main 生成：每网络调一个 FC，形参自动挂实参，标题注释齐全** |
| `udt_create` | 创建 PLC 数据类型（UDT） |
| `db_fb_create` | **堆垛机数据库范式生成器**：CASE 步进机+四件套握手+错误码分段，生成框架版 FB |
| `password_scan` | 扫描工程明文密码/口令，输出命中清单 |
| `stacker_db_deploy` | 一键部署工业完整版堆垛机数据库（3 UDT + 五命令 FB + 备份区） |
| `stacker_db_homework` | 一键部署数据库**作业版**（删查改留白） |
| `homework_check` | 批改数据库作业（五项检查，只报错不给答案） |
| `xiaowen_templates` | 列出可一键部署的小文老师模板清单 |
| `xiaowen_deploy` | **招牌：说一句就部署**（见下） |

## 招牌话术：说一句，就部署

| 你说 | AI 做 |
|---|---|
| 部署小文老师的数据库 | 建 CPU + 3 UDT + 完整五命令数据库 FB + 备份区 |
| 部署数据库作业 / 作业版 | 留白版数据库（删查改空壳给学生练） |
| 部署水泥厂 | 8 FB 模块化接口教学工程（10 块） |
| 部署 RTU / Modbus 轮询 | 表格化 50 通道轮询引擎 |
| 部署 EPOS / 定位 | 定位封装 + 编码器校正 |

部署完成后你只需**编译一次**（右键 PLC_1 → 编译 → 软件全部编译 → Ctrl+S）。

---

## 两个永远的人工动作

1. **编译**：AI 干完后，右键 `PLC_1` → 编译 → 软件（全部编译）。V21 的 Openness 没有编译接口，这一步任何 AI 都替代不了。
2. **首次授权**：第一次连接博途弹“Openness 访问”框，点“是”（建议勾选“不再显示”）。

---

## 演示与彩排脚本

```powershell
# 一键演示（约40秒：AI开机→工程→CPU→5个教学块→17标签→LAD全挂参）
powershell -File D:\tia-mcp\demo-go.ps1

# 连续彩排N轮（每轮自动清场重来，结果写 %TEMP%\rehearsal-results.log）
powershell -File D:\tia-mcp\rehearse-loop.ps1 -Cycles 10
```

**演示前清场**（关博途 + 删工程，才有“AI 自己开机”的效果）：
```powershell
Get-Process -Name Siemens.Automation.Portal | ForEach-Object { $_.CloseMainWindow() }
Remove-Item "$env:USERPROFILE\Desktop\Demo_AI_Show" -Recurse -Force
```

`demo-go.ps1` 支持**断点续跑**：中途失败重跑即可，已完成的步骤自动跳过。

---

## 常见问题速查

| 现象 | 解决 |
|---|---|
| 卡住/超时 | 博途崩过重启导致 Openness 失联 → 关掉博途重开再试 |
| 块导入/导出挂起 | 那个块正开在编辑器里 → 先关掉块编辑器 |
| 报“不是成员” | 权限脚本没跑或没注销重登 |
| `device_add` 报 Unknown TypeIdentifier | 订货号拼错 → 用 `catalog_search` 查 |
| 中文乱码 | 用包内最新版（已固定 UTF-8） |
| 自检第 1 项红 | 装 Node.js LTS（https://nodejs.org） |

---

## 架构（想懂原理的看）

```
MCP 客户端 (Claude Desktop / Cursor / DSH)
   │  MCP 协议 (JSON-RPC over stdio)
   ▼
server.js          Node 进程：实现 MCP 协议、注册工具
   │  JSON-RPC over stdio
   ▼
tia-service.ps1    PowerShell 5.1 常驻进程：加载 Siemens Openness API
   │  Openness (.NET Framework 4.8)
   ▼
TIA Portal V21
```

两层分工：Openness 的 DLL 是 .NET Framework 4.8 的，Node 加载不了，所以 PowerShell 做“常驻工人”，Node 做“协议翻译”。工人常驻只挂载一次，授权弹窗只需确认一次。

---

## 文件清单

| 文件 | 作用 |
|---|---|
| `一键安装.bat` / `install.ps1` | 一键安装器：权限 + 客户端配置 + 自检 + 速查卡 |
| `server.js` / `tia-service.ps1` | MCP 运行时（18 工具） |
| `一键安装.bat` / `selfcheck.ps1` | 一键自检 |
| `demo-go.ps1` | 一键演示（断点续跑） |
| `rehearse-loop.ps1` | 连续彩排脚本 |
| `lad-main-generator.ps1` / `build-demo-main.ps1` / `lad-main-demo.xml` | LAD Main 生成器与成品 |
| `enable-tia-openness.ps1` / `test-tia-openness.ps1` | 权限启用 / 验证 |
| `快速开始.txt` | 三句话速查卡 |

---

## 给同事的微信一句话版

> 发你个 AI 博途插件：解压双击 一键安装.bat（点“是”）→ 注销重登 → 对 AI 说“打开博途，建工程挂 CPU，建个块，在 Main 里用 LAD 调它，引脚挂 M 区”。第一次弹 Openness 访问框点“是”，最后右键编译一下。
