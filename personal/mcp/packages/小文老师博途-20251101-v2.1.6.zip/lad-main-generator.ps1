﻿# ============================================================
# lad-main-generator.ps1
# 生成 TIA Portal LAD 版 Main (OB1) 的导入 XML。
# 格式基于博途 V21 真实导出的 FlgNet v5 结构。
#
# 用法:
#   . .\lad-main-generator.ps1
#   $spec = @(
#     @{ Title='电机正反转'; Comment='...'; Block='电机正反转'; Params=@(
#         @{ Name='start'; Section='Input';  Type='Bool'; Operand=@{ Kind='Tag'; Name='Tag_1' } },
#         @{ Name='stop';  Section='Input';  Type='Bool'; Operand=@{ Kind='Tag'; Name='Tag_2' } },
#         @{ Name='running'; Section='Output'; Type='Bool'; Operand=@{ Kind='Tag'; Name='Tag_4' } }
#       ) }
#   )
#   New-LadMainXml -Networks $spec -OutFile "main.xml"
#
# Operand Kind: Tag (Symbol/Component) | IntLiteral (ConstantType+Value) | TimeLiteral (t#5s)
# ============================================================

function New-LadMainXml {
    param(
        [Parameter(Mandatory)]$Networks,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$ObjNumber = 1
    )

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<?xml version="1.0" encoding="utf-8"?>')
    [void]$sb.AppendLine('<Document>')
    [void]$sb.AppendLine('  <Engineering version="V21" />')
    [void]$sb.AppendLine('  <DocumentInfo>')
    [void]$sb.AppendLine('    <Created>2026-10-20T00:00:00Z</Created>')
    [void]$sb.AppendLine('    <ExportSetting>WithDefaults</ExportSetting>')
    [void]$sb.AppendLine('  </DocumentInfo>')
    [void]$sb.AppendLine('  <SW.Blocks.OB ID="0">')
    [void]$sb.AppendLine('    <AttributeList>')
    [void]$sb.AppendLine('      <AutoNumber>true</AutoNumber>')
    [void]$sb.AppendLine('      <HeaderAuthor />')
    [void]$sb.AppendLine('      <HeaderFamily />')
    [void]$sb.AppendLine('      <HeaderName />')
    [void]$sb.AppendLine('      <HeaderVersion>0.1</HeaderVersion>')
    [void]$sb.AppendLine('      <Interface>')
    [void]$sb.AppendLine('        <Sections xmlns="http://www.siemens.com/automation/Openness/SW/Interface/v5">')
    [void]$sb.AppendLine('          <Section Name="Temp" />')
    [void]$sb.AppendLine('          <Section Name="Constant" />')
    [void]$sb.AppendLine('        </Sections>')
    [void]$sb.AppendLine('      </Interface>')
    [void]$sb.AppendLine('      <IsIECCheckEnabled>false</IsIECCheckEnabled>')
    [void]$sb.AppendLine('      <MemoryLayout>Optimized</MemoryLayout>')
    [void]$sb.AppendLine('      <Name>Main</Name>')
    [void]$sb.AppendLine('      <Namespace />')
    [void]$sb.AppendLine("      <Number>$ObjNumber</Number>")
    [void]$sb.AppendLine('      <ProgrammingLanguage>LAD</ProgrammingLanguage>')
    [void]$sb.AppendLine('      <SecondaryType>ProgramCycle</SecondaryType>')
    [void]$sb.AppendLine('      <SetENOAutomatically>false</SetENOAutomatically>')
    [void]$sb.AppendLine('    </AttributeList>')
    [void]$sb.AppendLine('    <ObjectList>')

    $uid = 100   # 全局 UId 计数器
    $netIdx = 0
    foreach ($net in $Networks) {
        $netIdx++
        $callUid = $uid; $uid++
        $accessUids = @{}
        $parts = New-Object System.Text.StringBuilder
        $wires = New-Object System.Text.StringBuilder
        $paramDecl = New-Object System.Text.StringBuilder

        # 操作数 (Access) 与参数声明
        foreach ($p in $net.Params) {
            $aUid = $uid; $uid++
            $accessUids[$p.Name] = $aUid
            switch ($p.Operand.Kind) {
                'Tag' {
                    [void]$parts.AppendLine("                <Access Scope=`"GlobalVariable`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Symbol>')
                    [void]$parts.AppendLine("                    <Component Name=`"$($p.Operand.Name)`" />")
                    [void]$parts.AppendLine('                  </Symbol>')
                    [void]$parts.AppendLine('                </Access>')
                }
                'IntLiteral' {
                    [void]$parts.AppendLine("                <Access Scope=`"LiteralConstant`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Constant>')
                    [void]$parts.AppendLine("                    <ConstantType>$($p.Operand.Type)</ConstantType>")
                    [void]$parts.AppendLine("                    <ConstantValue>$($p.Operand.Value)</ConstantValue>")
                    [void]$parts.AppendLine('                  </Constant>')
                    [void]$parts.AppendLine('                </Access>')
                }
                'TimeLiteral' {
                    [void]$parts.AppendLine("                <Access Scope=`"TypedConstant`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Constant>')
                    [void]$parts.AppendLine("                    <ConstantValue>$($p.Operand.Value)</ConstantValue>")
                    [void]$parts.AppendLine('                  </Constant>')
                    [void]$parts.AppendLine('                </Access>')
                }
            }
            [void]$paramDecl.AppendLine("                    <Parameter Name=`"$($p.Name)`" Section=`"$($p.Section)`" Type=`"$($p.Type)`" />")
        }

        # Call
        [void]$parts.AppendLine("                <Call UId=`"$callUid`">")
        [void]$parts.AppendLine("                  <CallInfo Name=`"$($net.Block)`" BlockType=`"FC`">")
        [void]$parts.Append($paramDecl.ToString())
        [void]$parts.AppendLine('                  </CallInfo>')
        [void]$parts.AppendLine('                </Call>')

        # 供电线 (Powerrail -> EN)
        $wUid = $uid; $uid++
        [void]$wires.AppendLine("                <Wire UId=`"$wUid`">")
        [void]$wires.AppendLine('                  <Powerrail />')
        [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"en`" />")
        [void]$wires.AppendLine('                </Wire>')

        # 参数连线
        foreach ($p in $net.Params) {
            $wUid = $uid; $uid++
            $aUid = $accessUids[$p.Name]
            [void]$wires.AppendLine("                <Wire UId=`"$wUid`">")
            if ($p.Section -eq 'Input') {
                [void]$wires.AppendLine("                  <IdentCon UId=`"$aUid`" />")
                [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"$($p.Name)`" />")
            } else {
                [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"$($p.Name)`" />")
                [void]$wires.AppendLine("                  <IdentCon UId=`"$aUid`" />")
            }
            [void]$wires.AppendLine('                </Wire>')
        }

        $cuId = $uid; $uid++
        $cmtId = $uid; $uid++
        $cmtItemId = $uid; $uid++
        $ttlId = $uid; $uid++
        $ttlItemId = $uid; $uid++

        [void]$sb.AppendLine("      <SW.Blocks.CompileUnit ID=`"$cuId`" CompositionName=`"CompileUnits`">")
        [void]$sb.AppendLine('        <AttributeList>')
        [void]$sb.AppendLine('          <NetworkSource>')
        [void]$sb.AppendLine('            <FlgNet xmlns="http://www.siemens.com/automation/Openness/SW/NetworkSource/FlgNet/v5">')
        [void]$sb.AppendLine('              <Parts>')
        [void]$sb.Append($parts.ToString())
        [void]$sb.AppendLine('              </Parts>')
        [void]$sb.AppendLine('              <Wires>')
        [void]$sb.Append($wires.ToString())
        [void]$sb.AppendLine('              </Wires>')
        [void]$sb.AppendLine('            </FlgNet>')
        [void]$sb.AppendLine('          </NetworkSource>')
        [void]$sb.AppendLine('          <ProgrammingLanguage>LAD</ProgrammingLanguage>')
        [void]$sb.AppendLine('        </AttributeList>')
        [void]$sb.AppendLine('        <ObjectList>')
        [void]$sb.AppendLine("          <MultilingualText ID=`"$cmtId`" CompositionName=`"Comment`">")
        [void]$sb.AppendLine('            <ObjectList>')
        [void]$sb.AppendLine("              <MultilingualTextItem ID=`"$cmtItemId`" CompositionName=`"Items`">")
        [void]$sb.AppendLine('                <AttributeList>')
        [void]$sb.AppendLine('                  <Culture>zh-CN</Culture>')
        [void]$sb.AppendLine("                  <Text>$($net.Comment)</Text>")
        [void]$sb.AppendLine('                </AttributeList>')
        [void]$sb.AppendLine('              </MultilingualTextItem>')
        [void]$sb.AppendLine('            </ObjectList>')
        [void]$sb.AppendLine('          </MultilingualText>')
        [void]$sb.AppendLine("          <MultilingualText ID=`"$ttlId`" CompositionName=`"Title`">")
        [void]$sb.AppendLine('            <ObjectList>')
        [void]$sb.AppendLine("              <MultilingualTextItem ID=`"$ttlItemId`" CompositionName=`"Items`">")
        [void]$sb.AppendLine('                <AttributeList>')
        [void]$sb.AppendLine('                  <Culture>zh-CN</Culture>')
        [void]$sb.AppendLine("                  <Text>$($net.Title)</Text>")
        [void]$sb.AppendLine('                </AttributeList>')
        [void]$sb.AppendLine('              </MultilingualTextItem>')
        [void]$sb.AppendLine('            </ObjectList>')
        [void]$sb.AppendLine('          </MultilingualText>')
        [void]$sb.AppendLine('        </ObjectList>')
        [void]$sb.AppendLine('      </SW.Blocks.CompileUnit>')
    }

    [void]$sb.AppendLine('    </ObjectList>')
    [void]$sb.AppendLine('  </SW.Blocks.OB>')
    [void]$sb.AppendLine('</Document>')

    [System.IO.File]::WriteAllText($OutFile, $sb.ToString(), (New-Object System.Text.UTF8Encoding($true)))
    Write-Host "LAD Main XML 已生成: $OutFile"
}
