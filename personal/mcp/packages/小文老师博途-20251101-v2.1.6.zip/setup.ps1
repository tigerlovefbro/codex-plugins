﻿# ============================================================
# setup.ps1 - 一键安装主控(全中文界面)
# 由 一键安装.bat 调用; 负责: 标题/版本 -> 跑安装 -> 退出代码表
# -> 宣传 -> 下一步引导 -> 生成安装回执 -> 暂停
# ============================================================
$ErrorActionPreference = 'Continue'
try { cmd /c "chcp 65001" | Out-Null } catch {}
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { [Console]::Title = '小文老师博途MCP 一键安装' } catch {}
$dir = $PSScriptRoot

$ver = '未知版本'
try { if (Test-Path (Join-Path $dir 'version.txt')) { $ver = (Get-Content (Join-Path $dir 'version.txt') -Raw -Encoding UTF8).Trim() } } catch {}

Write-Host ''
Write-Host '================================================'
Write-Host '          小文老师博途MCP 一键安装'
Write-Host '    自动完成: 权限安装 + 客户端配置 + 全量自检'
Write-Host '    十天学会PLC 工作室出品'
Write-Host "    当前版本: $ver"
Write-Host '    反馈问题请同时报: 版本号 + 退出代码'
Write-Host '================================================'
Write-Host ''
Write-Host '[开始] 正在运行安装与自检, 请稍候...'
Write-Host ''

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dir 'install.ps1')
$code = $LASTEXITCODE

Write-Host ''
Write-Host '================================================'
$msg = switch ($code) {
    0  { '[成功] 退出代码 0 : 安装与自检全部通过, 可以正常使用了。' }
    1  { '[失败] 退出代码 1 : Node.js 未安装。到 https://nodejs.org 下载 LTS 版安装后重跑本文件。' }
    2  { '[失败] 退出代码 2 : 环境检查不通过(系统版本/TIA版本/Openness组件)。按上方提示修复。' }
    3  { '[失败] 退出代码 3 : 连接博途失败。检查权限是否已注销重登、博途是否能正常打开。' }
    4  { '[失败] 退出代码 4 : Openness 权限未启用。UAC 弹窗时要点"是"; 若已点, 请注销重登后重跑。' }
    5  { '[失败] 退出代码 5 : 包文件不完整。请把压缩包"全部解压"到文件夹后再运行。' }
    6  { '[失败] 退出代码 6 : TIA Portal 版本不是 V21。请升级到 V21 后重跑。' }
    9  { '[失败] 退出代码 9 : 未知异常。请把日志 %TEMP%\xiaowen-mcp-selfcheck.log 发给小文老师。' }
    10 { '[失败] 退出代码 10 : 未找到 Windows PowerShell, 系统可能被精简。' }
    default { "[完成] 退出代码 $code" }
}
if ($code -eq 0) { Write-Host $msg -ForegroundColor Green } else { Write-Host $msg -ForegroundColor Red }
Write-Host '================================================'
Write-Host ''
Write-Host '+---------------------------------------------+'
Write-Host '   十天学会PLC - 小文老师工作室'
Write-Host '   课程 / 项目合作 / 技术支持: 15929878510'
Write-Host '   官方主页: https://space.bilibili.com/455446576'
Write-Host '+---------------------------------------------+'
Write-Host ''
Write-Host '【下一步】 装好了! 打开你的 AI 客户端, 对它说:'
Write-Host '     "部署小文老师的数据库"'
Write-Host '   第一次就能体验 30 秒生成完整工程。'
Write-Host '   视频教程: https://space.bilibili.com/455446576'
Write-Host ''

# 生成安装回执
try {
    $osCaption = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption
    $receipt = @(
        '=========================================='
        '小文老师博途MCP 安装回执'
        '=========================================='
        "安装日期: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        "电脑名称: $env:COMPUTERNAME"
        "系统版本: $osCaption"
        "工具版本: $ver"
        "退出代码: $code"
        '=========================================='
        '问题反馈: 把本文件发给小文老师即可'
        '联系方式: 15929878510'
        '=========================================='
    )
    [System.IO.File]::WriteAllLines((Join-Path $dir '安装回执.txt'), $receipt, (New-Object System.Text.UTF8Encoding($true)))
    Write-Host '已生成: 安装回执.txt (有问题把这个文件发给小文老师)' -ForegroundColor Cyan
} catch { }
Write-Host ''
Read-Host '按回车退出'
exit $code
