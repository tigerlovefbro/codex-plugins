﻿# ============================================================
# tia-service.ps1
# Persistent JSON-RPC worker for TIA Portal Openness (V21).
# Spoken protocol: one JSON request per stdin line, one JSON
# response per stdout line. Keeps the TIA connection open so the
# Openness access dialog only needs to be confirmed once.
#
# Methods: status, attach, project_open, project_create,
#          project_save, device_add, blocks_list, block_delete,
#          fc_create
# ============================================================
$ErrorActionPreference = 'Stop'
# Fixed UTF-8 stdio so Chinese names survive the pipe from server.js
[Console]::InputEncoding  = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# ---------- Load Openness assemblies (V21 auto-detect) ----------
function Find-TiaOpenness {
    # 自动探测本机 TIA Portal 版本: V21/V20/V19/V18/V17, 也扫描其它盘符安装
    $candidates = @()
    foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $root) { continue }
        foreach ($v in @(21, 20, 19, 18, 17)) {
            $portal = Join-Path $root "Siemens\Automation\Portal V$v"
            if (-not (Test-Path $portal)) { continue }
            # PublicAPI 下可能有大写或小写版本目录, 直接枚举
            $apiRoot = Join-Path $portal 'PublicAPI'
            if (Test-Path $apiRoot) {
                foreach ($sub in @(Get-ChildItem $apiRoot -Directory -ErrorAction SilentlyContinue)) {
                    $net48 = Join-Path $sub.FullName 'net48'
                    if (Test-Path (Join-Path $net48 'Siemens.Engineering.Base.dll')) {
                        $pub = Join-Path $portal 'Bin\PublicAPI'
                        $candidates += @{ dir = $net48; pub = $pub; version = "V$v" }
                    }
                }
            }
        }
    }
    foreach ($c in $candidates) {
        if ((Test-Path (Join-Path $c.pub 'Siemens.Engineering.Contract.dll')) -and
            (Test-Path (Join-Path $c.dir 'Siemens.Engineering.Base.dll'))) {
            return $c
        }
    }
    return $null
}

$openInfo = Find-TiaOpenness

# ---------- 环境门禁: 不合格弹窗提示并终止 ----------
function Show-Popup([string]$title, [string]$text, [int]$seconds = 0) {
    try {
        $ws = New-Object -ComObject WScript.Shell
        [void]$ws.Popup($text, $seconds, $title, 48)
    } catch {
        try {
            Add-Type -AssemblyName System.Windows.Forms
            [void][System.Windows.Forms.MessageBox]::Show($text, $title, 'OK', 'Warning')
        } catch {
            Write-Host "PopupFail: $title : $text"
        }
    }
}

function Invoke-EnvironmentGate {
    $fails = @()
    # 1. 操作系统: Windows 10/11
    try {
        $osv = [System.Environment]::OSVersion.Version
        if ($osv.Major -lt 10) {
            $fails += '操作系统过旧: 需要 Windows 10 或 Windows 11。'
        }
    } catch { }

    # 2. TIA Portal V21 + Openness
    $info = Find-TiaOpenness
    if (-not $info) {
        $portalDirs = @(Get-ChildItem (Join-Path $env:ProgramFiles 'Siemens\Automation') -Directory -Filter 'Portal V*' -ErrorAction SilentlyContinue)
        if ($portalDirs.Count -gt 0) {
            $fails += 'TIA Portal 已安装但缺少 Openness 组件: 需要 V21 (含 Openness)。'
        } else {
            $fails += '未检测到 TIA Portal: 需要安装 TIA Portal V21 (含 Openness 组件)。'
        }
    } elseif ($info.version -ne 'V21') {
        $fails += "检测到 TIA Portal $($info.version), 本工具仅支持 V21。请升级到 TIA Portal V21 后重试。"
    }

    # 3. Openness 权限组
    $grp = Get-LocalGroup -Name 'Siemens TIA Openness' -ErrorAction SilentlyContinue
    $inGroup = $false
    if ($grp) {
        try {
            $id = [Security.Principal.WindowsIdentity]::GetCurrent()
            $inGroup = [bool](@(Get-LocalGroupMember -Group 'Siemens TIA Openness' -ErrorAction SilentlyContinue) | Where-Object { $_.SID.Value -eq $id.User.Value })
        } catch { }
    }
    if (-not $grp -or -not $inGroup) {
        $fails += 'Openness 权限未启用: 右键 enable-tia-openness.ps1 以管理员运行(UAC 点 是), 然后注销重新登录 Windows。'
    }

    if ($fails.Count -gt 0) {
        $msg = "小文老师博途MCP 环境检查不通过:`n`n" + (($fails | ForEach-Object { "· $_" }) -join "`n") + "`n`n修复后重新操作即可。"
        Show-Popup '小文老师博途MCP - 环境检查' $msg
        throw ('ENV_CHECK_FAIL: ' + ($fails -join ' | '))
    }
}

Invoke-EnvironmentGate

if (-not $openInfo) {
    throw '未找到 TIA Portal Openness API。请确认已安装 TIA Portal V21 (含 Openness 组件)。'
}
$OPEN_DIR  = $openInfo.dir
$OPEN_PUB  = $openInfo.pub
$OPEN_VER  = $openInfo.version
[Environment]::CurrentDirectory = $OPEN_DIR
foreach ($dll in @(
    (Join-Path $OPEN_PUB 'Siemens.Engineering.Contract.dll'),
    (Join-Path $OPEN_PUB 'Siemens.Engineering.ClientAdapter.Interfaces.dll'),
    (Join-Path $OPEN_DIR 'Siemens.Engineering.Base.dll'),
    (Join-Path $OPEN_DIR 'Siemens.Engineering.Step7.dll'))) {
    if (Test-Path $dll) { [void][System.Reflection.Assembly]::LoadFrom($dll) }
}

$script:tia  = $null
$script:proj = $null

function Get-PlcObject {
    $dev = $script:proj.Devices | Select-Object -First 1
    if (-not $dev) { throw 'Current project has no device.' }
    $cpu = @($dev.DeviceItems) | Where-Object { $_.TypeIdentifier -match '511-1AL03' } | Select-Object -First 1
    if (-not $cpu) { $cpu = @($dev.DeviceItems) | Select-Object -Last 1 }
    $mi = $cpu.GetType().GetMethod('GetService')
    $sc = $mi.MakeGenericMethod([Siemens.Engineering.HW.Features.SoftwareContainer]).Invoke($cpu, @())
    return [Siemens.Engineering.SW.PlcSoftware]$sc.Software
}

function Close-OpenProjects {
    $open = @($script:tia.Projects)
    foreach ($p in $open) {
        try { $p.Close() } catch {}
    }
    Start-Sleep -Milliseconds 1500
}

function Ensure-Tia {
    if ($script:tia) { return }
    # GetProcesses can return 0 after a TIA crash/auto-restart. In that case a
    # constructor launch would hang forever (another instance is running), so
    # retry a few times and then fail fast with a clear message.
    for ($attempt = 1; $attempt -le 8; $attempt++) {
        $procs = [Siemens.Engineering.TiaPortal]::GetProcesses()
        if ($procs.Count -gt 0) {
            $p = $procs | Where-Object { $_.Mode -eq 'WithUserInterface' } | Select-Object -First 1
            if (-not $p) { $p = $procs | Select-Object -First 1 }
            $script:tia = $p.Attach()
            return
        }
        $portalRunning = [bool](Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue)
        if ($portalRunning) { Start-Sleep -Seconds 5 }
        else { break }
    }
    if (Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue) {
        throw 'TIA Portal is running but Openness cannot see it (probably after a crash restart). Please close and reopen TIA Portal, then retry.'
    }
    $script:tia = New-Object Siemens.Engineering.TiaPortal([Siemens.Engineering.TiaPortalMode]::WithUserInterface)
}

function Resolve-ProjectPath([string]$path) {
    if ($path -match '\.ap21$') { return $path }
    $leaf = Split-Path $path -Leaf
    $candidate = Join-Path $path ($leaf + '.ap21')
    if (Test-Path $candidate) { return $candidate }
    return $path
}

function Build-DbFbScl {
    # Generates a complete stacker-style local task database FB (增删查改四件套).
    # Style follows Winsynth_Database: CASE step machines, Cmd/Done/Err handshake, 16# error codes.
    param([string]$Name = 'Winsynth_Database', [int]$Slots = 255)
    $flds = @"
            Step : Int;
            num : Int;
            num1 : Int;
            Locking : Int;
            Temp : Int;
            Err : Bool;
            ErrID : Word;
            Done : Bool;
            Busy : Bool;
            Number : Int;
"@
@"
FUNCTION_BLOCK "$Name"
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
VAR_INPUT
    FB_Enable : Bool;      // 功能块启用
    AddCmd : Bool;         // 增加命令
    DelCmd : Bool;         // 删除命令
    ReadCmd : Bool;        // 查询命令
    UpdataCmd : Bool;      // 修改命令
    AddData : String;      // 增加的字符信息
    DelData : String;      // 删除的字符信息
    ReadData : String;     // 查询的字符信息
    UpdataData : String;   // 修改的字符信息
    ElementCount : Int;    // 元素数量
    AutoCheck : Bool;      // 自动配对检查
    SystemReady : Bool;    // 系统就绪(建议接时钟脉冲)
END_VAR
VAR_OUTPUT
    FB_Active : Bool;      // 功能块就绪
    Success : Bool;        // 业务成功
    Success_ID : Int;      // 业务ID(10增/20删/30查/40改)
    Error : Bool;          // 业务失败
    Error_ID : Word;       // 错误码 0x10数据 0x20权限 0x30无匹配 0x40转换 0x50日志
    MatchResult1 : Int;    // 匹配结果1(库位号)
    MatchResult2 : Int;    // 匹配结果2
    CheckStatus : Int;     // 0空闲 1成功 2失败 3忙碌
END_VAR
VAR_IN_OUT
    DataBackUp : Variant;  // 数据备份区(载存), 外部接入备份DB
    Jurisd_ID : Word;      // 权限ID
    Jurisd_PS : Word;      // 权限密码
END_VAR
VAR
    Pubilc : Struct
        产品信息Run : Array[1..$Slots] of Struct
            Conv : Array[0..29] of Char;
        END_STRUCT;
        库位状态Run : Array[1..$Slots] of Bool;
        业务信息ID : Word;   // 当前执行的业务代号
    END_STRUCT;
    Internal : Struct
        FirstDone : Bool;
        FirstClear : Bool;
        PrivateID : Word := 16#4;      // 厂内权限ID, 按需修改
        PrivatePS : Word := 10#8884;   // 厂内权限密码, 按需修改(注意: 代码内明文)
        Jurisd : Struct
            Cmd : Bool;
            ID_OK : Bool;
            ID_Err : Bool;
        END_STRUCT;
        DataCheck : Struct
            Cmd : Bool;
            Done : Bool;
            Err : Bool;
        END_STRUCT;
        DatareFresh : Struct
            Cmd : Bool;
            Done : Bool;
            Err : Bool;
            num : Int;
        END_STRUCT;
        Conv_S_C : Struct
            Cmd : Bool;
            InDatapipe : String;
            OutDatapipe : Array[0..29] of Char;
            Done : Bool;
            Err : Bool;
            num1 : Int;
            num2 : Int;
            DtatL : Int;
        END_STRUCT;
        DataBackUp : Struct
            CmdWrit : Bool;
            WritDone : Bool;
        END_STRUCT;
        Message : Struct
            Cmd : Bool;
            MsDone : Bool;
            MsErr : Bool;
        END_STRUCT;
        AddMain : Struct
$flds
        END_STRUCT;
        DelMain : Struct
$flds
        END_STRUCT;
        ReadMain : Struct
$flds
        END_STRUCT;
        UpDataMain : Struct
$flds
        END_STRUCT;
    END_STRUCT;
END_VAR
BEGIN

    //================ 初始化 ================
    IF #FB_Enable THEN
        IF NOT #Internal.FirstClear THEN
            #Jurisd_ID := 0;
            #Jurisd_PS := 0;
            #Internal.FirstClear := 1;
        END_IF;
        #Internal.FirstDone := 1;
        #FB_Active := 1;
    ELSE
        #FB_Active := 0;
        #Internal.FirstClear := 0;
        #Internal.FirstDone := 0;
        #Jurisd_ID := 0;
        #Jurisd_PS := 0;
    END_IF;

    //================ 公共子功能(单扫描执行) ================
    //权限判断: 比对ID与密码
    IF #Internal.Jurisd.Cmd THEN
        #Internal.Jurisd.ID_OK := 0;
        #Internal.Jurisd.ID_Err := 0;
        IF #Jurisd_ID = #Internal.PrivateID AND #Jurisd_PS = #Internal.PrivatePS THEN
            #Internal.Jurisd.ID_OK := 1;
        ELSE
            #Internal.Jurisd.ID_Err := 1;
        END_IF;
    END_IF;

    //数据合理性检查: 数据非空
    IF #Internal.DataCheck.Cmd THEN
        #Internal.DataCheck.Done := 0;
        #Internal.DataCheck.Err := 0;
        IF #Internal.Conv_S_C.InDatapipe <> '' THEN
            #Internal.DataCheck.Done := 1;
        ELSE
            #Internal.DataCheck.Err := 1;
        END_IF;
    END_IF;

    //库位刷新: 统计占用情况(业务信息ID写当前命令代号)
    IF #Internal.DatareFresh.Cmd THEN
        #Internal.DatareFresh.Done := 1;
        #Internal.DatareFresh.Err := 0;
    END_IF;

    //数据转换 String->Char
    IF #Internal.Conv_S_C.Cmd THEN
        #Internal.Conv_S_C.Done := 0;
        #Internal.Conv_S_C.Err := 0;
        FOR #Internal.Conv_S_C.num1 := 0 TO 29 DO
            #Internal.Conv_S_C.OutDatapipe[#Internal.Conv_S_C.num1] := ' ';
        END_FOR;
        #Internal.Conv_S_C.DtatL := LEN(#Internal.Conv_S_C.InDatapipe);
        IF #Internal.Conv_S_C.DtatL > 0 AND #Internal.Conv_S_C.DtatL <= 30 THEN
            FOR #Internal.Conv_S_C.num2 := 1 TO #Internal.Conv_S_C.DtatL DO
                #Internal.Conv_S_C.OutDatapipe[#Internal.Conv_S_C.num2 - 1] := #Internal.Conv_S_C.InDatapipe[#Internal.Conv_S_C.num2];
            END_FOR;
            #Internal.Conv_S_C.Done := 1;
        ELSE
            #Internal.Conv_S_C.Err := 1;
        END_IF;
    END_IF;

    //数据备份(载存): 接入点, 在此调用备份块或搬运指令
    IF #Internal.DataBackUp.CmdWrit THEN
        #Internal.DataBackUp.WritDone := 1;
    END_IF;

    //日志打印: 接入点, 在此调用日志FB或写生产日志
    IF #Internal.Message.Cmd THEN
        #Internal.Message.MsDone := 1;
        #Internal.Message.MsErr := 0;
    END_IF;

    //================ 业务仲裁 ================
    IF #Internal.AddMain.Busy THEN
        #Success := #Internal.AddMain.Done;
        #Error := #Internal.AddMain.Err;
        #Error_ID := #Internal.AddMain.ErrID;
        #Success_ID := #Internal.AddMain.Number;
    ELSIF #Internal.DelMain.Busy THEN
        #Success := #Internal.DelMain.Done;
        #Error := #Internal.DelMain.Err;
        #Error_ID := #Internal.DelMain.ErrID;
        #Success_ID := #Internal.DelMain.Number;
    ELSIF #Internal.ReadMain.Busy THEN
        #Success := #Internal.ReadMain.Done;
        #Error := #Internal.ReadMain.Err;
        #Error_ID := #Internal.ReadMain.ErrID;
        #Success_ID := #Internal.ReadMain.Number;
    ELSIF #Internal.UpDataMain.Busy THEN
        #Success := #Internal.UpDataMain.Done;
        #Error := #Internal.UpDataMain.Err;
        #Error_ID := #Internal.UpDataMain.ErrID;
        #Success_ID := #Internal.UpDataMain.Number;
    ELSE
        #Success := 0;
        #Error := 0;
        #Error_ID := 0;
        #Success_ID := 0;
    END_IF;

    //================ 核心业务 ================
    REGION AddData
    IF #AddCmd = 1 THEN
        //业务代码：16#10
        CASE #Internal.AddMain.Step OF
            0://初始化清理
                #Internal.AddMain.Done := 0;
                #Internal.AddMain.Busy := 0;
                #Internal.AddMain.Temp := 0;
                #Internal.AddMain.Locking := 0;
                #Internal.DataCheck.Cmd := 0;
                #Internal.DatareFresh.Cmd := 0;
                #Internal.DataBackUp.CmdWrit := 0;
                #Internal.Message.Cmd := 0;
                #Internal.Jurisd.Cmd := 0;
                #Internal.AddMain.Step := 10;
            10://判断系统就绪
                #Internal.AddMain.Busy := 1;
                IF #SystemReady THEN
                    #Internal.AddMain.Step := 20;
                END_IF;
            20://命令到达
                IF #AddCmd THEN
                    #Internal.AddMain.Step := 30;
                END_IF;
            30://数据转换
                #Internal.Conv_S_C.InDatapipe := #AddData;
                #Internal.Conv_S_C.Cmd := 1;
                IF #Internal.Conv_S_C.Done THEN
                    #Internal.AddMain.Step := 35;
                END_IF;
                IF #Internal.Conv_S_C.Err THEN
                    #Internal.AddMain.Err := 1;
                    #Internal.AddMain.ErrID := 16#40;
                    #Internal.AddMain.Step := 999;
                END_IF;
            35://检查数据合理性
                #Internal.Conv_S_C.Cmd := 0;
                #Internal.DataCheck.Cmd := 1;
                IF #Internal.DataCheck.Done THEN
                    #Internal.AddMain.Step := 40;
                END_IF;
                IF #Internal.DataCheck.Err THEN
                    #Internal.AddMain.Err := 1;
                    #Internal.AddMain.ErrID := 16#10;
                    #Internal.AddMain.Step := 999;
                END_IF;
            40://执行权限检查
                #Internal.DataCheck.Cmd := 0;
                #Internal.Jurisd.Cmd := 1;
                IF #Internal.Jurisd.ID_OK THEN
                    #Internal.AddMain.Step := 50;
                END_IF;
                IF #Internal.Jurisd.ID_Err THEN
                    #Internal.AddMain.Err := 1;
                    #Internal.AddMain.ErrID := 16#20;
                    #Internal.AddMain.Step := 999;
                END_IF;
            50://库位刷新
                #Internal.Jurisd.Cmd := 0;
                #Internal.DatareFresh.Cmd := 1;
                IF #Internal.DatareFresh.Done THEN
                    #Internal.AddMain.Step := 55;
                END_IF;
            55://库位锁定(找空库位)
                #Internal.DatareFresh.Cmd := 0;
                FOR #Internal.AddMain.num := 1 TO $Slots DO
                    IF #Pubilc.库位状态Run[#Internal.AddMain.num] = 0 THEN
                        #Internal.AddMain.Locking := #Internal.AddMain.num;
                        #Internal.AddMain.Step := 70;
                        EXIT;
                    END_IF;
                    IF #Internal.AddMain.num >= $Slots THEN
                        #Internal.AddMain.Err := 1;
                        #Internal.AddMain.ErrID := 16#30;
                        #Internal.AddMain.Step := 999;
                    END_IF;
                END_FOR;
            70://写入数据
                FOR #Internal.AddMain.num1 := 0 TO 29 DO
                    #Pubilc.产品信息Run[#Internal.AddMain.Locking].Conv[#Internal.AddMain.num1] := #Internal.Conv_S_C.OutDatapipe[#Internal.AddMain.num1];
                END_FOR;
                #Pubilc.库位状态Run[#Internal.AddMain.Locking] := 1;
                #Internal.AddMain.Step := 80;
            80://数据进入载存(备份)
                #Internal.DataBackUp.CmdWrit := 1;
                IF #Internal.DataBackUp.WritDone THEN
                    #Internal.AddMain.Step := 90;
                END_IF;
            90://打印日志
                #Internal.Message.Cmd := 1;
                IF #Internal.Message.MsDone THEN
                    #Internal.AddMain.Step := 100;
                END_IF;
                IF #Internal.Message.MsErr THEN
                    #Internal.AddMain.Err := 1;
                    #Internal.AddMain.ErrID := 16#50;
                    #Internal.AddMain.Step := 999;
                END_IF;
            100://输出标志位
                #Internal.AddMain.Done := 1;
                #Internal.AddMain.Number := 10;
                #Internal.AddMain.Step := 200;
            200://函数返回
                IF #AddCmd = 0 THEN
                    #Internal.AddMain.Step := 0;
                END_IF;
            999://错误退出
                IF #AddCmd = 0 THEN
                    #Internal.AddMain.Step := 0;
                END_IF;
        END_CASE;
    ELSE
        #Internal.AddMain.Done := 0;
        #Internal.AddMain.Busy := 0;
        #Internal.AddMain.Temp := 0;
        #Internal.AddMain.Locking := 0;
        #Internal.DataCheck.Cmd := 0;
        #Internal.DatareFresh.Cmd := 0;
        #Internal.DataBackUp.CmdWrit := 0;
        #Internal.Message.Cmd := 0;
        #Internal.Jurisd.Cmd := 0;
        #Internal.AddMain.Step := 0;
    END_IF;
    END_REGION

    REGION DelData
    IF #DelCmd = 1 THEN
        //业务代码：16#20
        CASE #Internal.DelMain.Step OF
            0://初始化清理
                #Internal.DelMain.Done := 0;
                #Internal.DelMain.Busy := 0;
                #Internal.DelMain.Temp := 0;
                #Internal.DelMain.Locking := 0;
                #Internal.DatareFresh.Cmd := 0;
                #Internal.DataBackUp.CmdWrit := 0;
                #Internal.Message.Cmd := 0;
                #Internal.Jurisd.Cmd := 0;
                #Internal.DelMain.Step := 10;
            10://判断系统就绪
                #Internal.DelMain.Busy := 1;
                IF #SystemReady THEN
                    #Internal.DelMain.Step := 20;
                END_IF;
            20://命令到达
                IF #DelCmd THEN
                    #Internal.DelMain.Step := 30;
                END_IF;
            30://执行权限检查
                #Internal.Jurisd.Cmd := 1;
                IF #Internal.Jurisd.ID_OK THEN
                    #Internal.DelMain.Step := 40;
                END_IF;
                IF #Internal.Jurisd.ID_Err THEN
                    #Internal.DelMain.Err := 1;
                    #Internal.DelMain.ErrID := 16#20;
                    #Internal.DelMain.Step := 999;
                END_IF;
            40://执行数据转换
                #Internal.Jurisd.Cmd := 0;
                #Internal.Conv_S_C.InDatapipe := #DelData;
                #Internal.Conv_S_C.Cmd := 1;
                IF #Internal.Conv_S_C.Done THEN
                    #Internal.DelMain.Step := 55;
                END_IF;
                IF #Internal.Conv_S_C.Err THEN
                    #Internal.DelMain.Err := 1;
                    #Internal.DelMain.ErrID := 16#40;
                    #Internal.DelMain.Step := 999;
                END_IF;
            55://初始化扫描游标
                #Internal.Conv_S_C.Cmd := 0;
                #Internal.DelMain.num := 1;
                #Internal.DelMain.Temp := 0;
                #Internal.DelMain.Step := 60;
            60://全库扫描匹配目标数据
                #Internal.DelMain.Temp := 0;
                FOR #Internal.DelMain.num1 := 0 TO 29 DO
                    IF #Pubilc.产品信息Run[#Internal.DelMain.num].Conv[#Internal.DelMain.num1] <> #Internal.Conv_S_C.OutDatapipe[#Internal.DelMain.num1] THEN
                        #Internal.DelMain.Temp := 1;
                    END_IF;
                END_FOR;
                IF #Internal.DelMain.Temp = 0 THEN
                    #Internal.DelMain.Locking := #Internal.DelMain.num;
                    #Internal.DelMain.Step := 70;
                ELSE
                    IF #Internal.DelMain.num < $Slots THEN
                        #Internal.DelMain.num := #Internal.DelMain.num + 1;
                    ELSE
                        #Internal.DelMain.Err := 1;
                        #Internal.DelMain.ErrID := 16#30;
                        #Internal.DelMain.Step := 999;
                    END_IF;
                END_IF;
            70://清除数据
                FOR #Internal.DelMain.num1 := 0 TO 29 DO
                    #Pubilc.产品信息Run[#Internal.DelMain.Locking].Conv[#Internal.DelMain.num1] := ' ';
                END_FOR;
                #Pubilc.库位状态Run[#Internal.DelMain.Locking] := 0;
                #Internal.DelMain.Step := 80;
            80://数据进入载存(备份同步)
                #Internal.DataBackUp.CmdWrit := 1;
                IF #Internal.DataBackUp.WritDone THEN
                    #Internal.DelMain.Step := 90;
                END_IF;
            90://打印日志
                #Internal.Message.Cmd := 1;
                IF #Internal.Message.MsDone THEN
                    #Internal.DelMain.Step := 100;
                END_IF;
                IF #Internal.Message.MsErr THEN
                    #Internal.DelMain.Err := 1;
                    #Internal.DelMain.ErrID := 16#50;
                    #Internal.DelMain.Step := 999;
                END_IF;
            100://输出标志位
                #Internal.DelMain.Done := 1;
                #Internal.DelMain.Number := 20;
                #Internal.DelMain.Step := 200;
            200://函数返回
                IF #DelCmd = 0 THEN
                    #Internal.DelMain.Step := 0;
                END_IF;
            999://错误退出
                IF #DelCmd = 0 THEN
                    #Internal.DelMain.Step := 0;
                END_IF;
        END_CASE;
    ELSE
        #Internal.DelMain.Done := 0;
        #Internal.DelMain.Busy := 0;
        #Internal.DelMain.Temp := 0;
        #Internal.DelMain.Locking := 0;
        #Internal.DatareFresh.Cmd := 0;
        #Internal.DataBackUp.CmdWrit := 0;
        #Internal.Message.Cmd := 0;
        #Internal.Jurisd.Cmd := 0;
        #Internal.DelMain.Step := 0;
    END_IF;
    END_REGION

    REGION ReadData
    IF #ReadCmd = 1 THEN
        //业务代码：16#30
        CASE #Internal.ReadMain.Step OF
            0://初始化清理
                #Internal.ReadMain.Done := 0;
                #Internal.ReadMain.Busy := 0;
                #Internal.ReadMain.Temp := 0;
                #Internal.ReadMain.Locking := 0;
                #Internal.Jurisd.Cmd := 0;
                #Internal.ReadMain.Step := 10;
            10://判断系统就绪
                #Internal.ReadMain.Busy := 1;
                IF #SystemReady THEN
                    #Internal.ReadMain.Step := 20;
                END_IF;
            20://命令到达
                IF #ReadCmd THEN
                    #Internal.ReadMain.Step := 30;
                END_IF;
            30://执行权限检查
                #Internal.Jurisd.Cmd := 1;
                IF #Internal.Jurisd.ID_OK THEN
                    #Internal.ReadMain.Step := 40;
                END_IF;
                IF #Internal.Jurisd.ID_Err THEN
                    #Internal.ReadMain.Err := 1;
                    #Internal.ReadMain.ErrID := 16#20;
                    #Internal.ReadMain.Step := 999;
                END_IF;
            40://执行数据转换
                #Internal.Jurisd.Cmd := 0;
                #Internal.Conv_S_C.InDatapipe := #ReadData;
                #Internal.Conv_S_C.Cmd := 1;
                IF #Internal.Conv_S_C.Done THEN
                    #Internal.ReadMain.Step := 50;
                END_IF;
                IF #Internal.Conv_S_C.Err THEN
                    #Internal.ReadMain.Err := 1;
                    #Internal.ReadMain.ErrID := 16#40;
                    #Internal.ReadMain.Step := 999;
                END_IF;
            50://初始化扫描游标
                #Internal.Conv_S_C.Cmd := 0;
                #Internal.ReadMain.num := 1;
                #Internal.ReadMain.Temp := 0;
                #Internal.ReadMain.Step := 60;
            60://全库扫描匹配目标数据
                #Internal.ReadMain.Temp := 0;
                FOR #Internal.ReadMain.num1 := 0 TO 29 DO
                    IF #Pubilc.产品信息Run[#Internal.ReadMain.num].Conv[#Internal.ReadMain.num1] <> #Internal.Conv_S_C.OutDatapipe[#Internal.ReadMain.num1] THEN
                        #Internal.ReadMain.Temp := 1;
                    END_IF;
                END_FOR;
                IF #Internal.ReadMain.Temp = 0 THEN
                    #Internal.ReadMain.Locking := #Internal.ReadMain.num;
                    #MatchResult1 := #Internal.ReadMain.Locking;
                    #MatchResult2 := 0;
                    #Internal.ReadMain.Step := 100;
                ELSE
                    IF #Internal.ReadMain.num < $Slots THEN
                        #Internal.ReadMain.num := #Internal.ReadMain.num + 1;
                    ELSE
                        #MatchResult1 := 10#99;
                        #MatchResult2 := 10#99;
                        #Internal.ReadMain.Step := 100;
                    END_IF;
                END_IF;
            100://输出标志位
                #Internal.ReadMain.Done := 1;
                #Internal.ReadMain.Number := 30;
                #Internal.ReadMain.Step := 200;
            200://函数返回
                IF #ReadCmd = 0 THEN
                    #Internal.ReadMain.Step := 0;
                END_IF;
            999://错误退出
                IF #ReadCmd = 0 THEN
                    #Internal.ReadMain.Step := 0;
                END_IF;
        END_CASE;
    ELSE
        #Internal.ReadMain.Done := 0;
        #Internal.ReadMain.Busy := 0;
        #Internal.ReadMain.Temp := 0;
        #Internal.ReadMain.Locking := 0;
        #Internal.Jurisd.Cmd := 0;
        #Internal.ReadMain.Step := 0;
    END_IF;
    END_REGION

    REGION UpData
    IF #UpdataCmd = 1 THEN
        //业务代码：16#40
        CASE #Internal.UpDataMain.Step OF
            0://初始化清理
                #Internal.UpDataMain.Done := 0;
                #Internal.UpDataMain.Busy := 0;
                #Internal.UpDataMain.Temp := 0;
                #Internal.UpDataMain.Locking := 0;
                #Internal.DataCheck.Cmd := 0;
                #Internal.DataBackUp.CmdWrit := 0;
                #Internal.Message.Cmd := 0;
                #Internal.Jurisd.Cmd := 0;
                #Internal.UpDataMain.Step := 10;
            10://判断系统就绪
                #Internal.UpDataMain.Busy := 1;
                IF #SystemReady THEN
                    #Internal.UpDataMain.Step := 20;
                END_IF;
            20://命令到达
                IF #UpdataCmd THEN
                    #Internal.UpDataMain.Step := 30;
                END_IF;
            30://检查新数据合理性
                #Internal.Conv_S_C.InDatapipe := #UpdataData;
                #Internal.Conv_S_C.Cmd := 1;
                IF #Internal.Conv_S_C.Done THEN
                    #Internal.UpDataMain.Step := 40;
                END_IF;
                IF #Internal.Conv_S_C.Err THEN
                    #Internal.UpDataMain.Err := 1;
                    #Internal.UpDataMain.ErrID := 16#40;
                    #Internal.UpDataMain.Step := 999;
                END_IF;
            40://执行权限检查
                #Internal.Conv_S_C.Cmd := 0;
                #Internal.Jurisd.Cmd := 1;
                IF #Internal.Jurisd.ID_OK THEN
                    #Internal.UpDataMain.Step := 55;
                END_IF;
                IF #Internal.Jurisd.ID_Err THEN
                    #Internal.UpDataMain.Err := 1;
                    #Internal.UpDataMain.ErrID := 16#20;
                    #Internal.UpDataMain.Step := 999;
                END_IF;
            55://初始化扫描游标
                #Internal.Jurisd.Cmd := 0;
                #Internal.UpDataMain.num := 1;
                #Internal.UpDataMain.Temp := 0;
                #Internal.UpDataMain.Step := 60;
            60://全库扫描定位目标库位(按前2位匹配)
                #Internal.UpDataMain.Temp := 0;
                FOR #Internal.UpDataMain.num1 := 0 TO 1 DO
                    IF #Pubilc.产品信息Run[#Internal.UpDataMain.num].Conv[#Internal.UpDataMain.num1] <> #Internal.Conv_S_C.OutDatapipe[#Internal.UpDataMain.num1] THEN
                        #Internal.UpDataMain.Temp := 1;
                    END_IF;
                END_FOR;
                IF #Internal.UpDataMain.Temp = 0 THEN
                    #Internal.UpDataMain.Locking := #Internal.UpDataMain.num;
                    #Internal.UpDataMain.Step := 70;
                ELSE
                    IF #Internal.UpDataMain.num < $Slots THEN
                        #Internal.UpDataMain.num := #Internal.UpDataMain.num + 1;
                    ELSE
                        #Internal.UpDataMain.Err := 1;
                        #Internal.UpDataMain.ErrID := 16#30;
                        #Internal.UpDataMain.Step := 999;
                    END_IF;
                END_IF;
            70://覆写数据
                FOR #Internal.UpDataMain.num1 := 0 TO 29 DO
                    #Pubilc.产品信息Run[#Internal.UpDataMain.Locking].Conv[#Internal.UpDataMain.num1] := #Internal.Conv_S_C.OutDatapipe[#Internal.UpDataMain.num1];
                END_FOR;
                #Internal.UpDataMain.Step := 80;
            80://数据进入载存(备份同步)
                #Internal.DataBackUp.CmdWrit := 1;
                IF #Internal.DataBackUp.WritDone THEN
                    #Internal.UpDataMain.Step := 90;
                END_IF;
            90://打印日志
                #Internal.Message.Cmd := 1;
                IF #Internal.Message.MsDone THEN
                    #Internal.UpDataMain.Step := 100;
                END_IF;
                IF #Internal.Message.MsErr THEN
                    #Internal.UpDataMain.Err := 1;
                    #Internal.UpDataMain.ErrID := 16#50;
                    #Internal.UpDataMain.Step := 999;
                END_IF;
            100://输出标志位
                #Internal.UpDataMain.Done := 1;
                #Internal.UpDataMain.Number := 40;
                #Internal.UpDataMain.Step := 200;
            200://函数返回
                IF #UpdataCmd = 0 THEN
                    #Internal.UpDataMain.Step := 0;
                END_IF;
            999://错误退出
                IF #UpdataCmd = 0 THEN
                    #Internal.UpDataMain.Step := 0;
                END_IF;
        END_CASE;
    ELSE
        #Internal.UpDataMain.Done := 0;
        #Internal.UpDataMain.Busy := 0;
        #Internal.UpDataMain.Temp := 0;
        #Internal.UpDataMain.Locking := 0;
        #Internal.DataCheck.Cmd := 0;
        #Internal.DataBackUp.CmdWrit := 0;
        #Internal.Message.Cmd := 0;
        #Internal.Jurisd.Cmd := 0;
        #Internal.UpDataMain.Step := 0;
    END_IF;
    END_REGION

END_FUNCTION_BLOCK
"@
}

function Build-LadMainXml {
    # Generates the import XML for a LAD Main (OB) with wired call networks.
    # Format follows TIA V21 real export (FlgNet v5).
    param([Parameter(Mandatory)]$Networks, [string]$Name = 'Main', [int]$Number = 1)

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<?xml version="1.0" encoding="utf-8"?>')
    [void]$sb.AppendLine('<Document>')
    [void]$sb.AppendLine('  <Engineering version="V21" />')
    [void]$sb.AppendLine('  <DocumentInfo>')
    [void]$sb.AppendLine('    <Created>2026-10-20T00:00:00Z</Created>')
    [void]$sb.AppendLine('    <ExportSetting>WithDefaults</ExportSetting>')
    [void]$sb.AppendLine('  </DocumentInfo>')
    [void]$sb.AppendLine('  <SW.Blocks.OB ID="0">')
    [void]$sb.AppendLine('    <AttributeList>')
    [void]$sb.AppendLine('      <AutoNumber>true</AutoNumber>')
    [void]$sb.AppendLine('      <HeaderAuthor />')
    [void]$sb.AppendLine('      <HeaderFamily />')
    [void]$sb.AppendLine('      <HeaderName />')
    [void]$sb.AppendLine('      <HeaderVersion>0.1</HeaderVersion>')
    [void]$sb.AppendLine('      <Interface>')
    [void]$sb.AppendLine('        <Sections xmlns="http://www.siemens.com/automation/Openness/SW/Interface/v5">')
    [void]$sb.AppendLine('          <Section Name="Temp" />')
    [void]$sb.AppendLine('          <Section Name="Constant" />')
    [void]$sb.AppendLine('        </Sections>')
    [void]$sb.AppendLine('      </Interface>')
    [void]$sb.AppendLine('      <IsIECCheckEnabled>false</IsIECCheckEnabled>')
    [void]$sb.AppendLine('      <MemoryLayout>Optimized</MemoryLayout>')
    [void]$sb.AppendLine("      <Name>$Name</Name>")
    [void]$sb.AppendLine('      <Namespace />')
    [void]$sb.AppendLine("      <Number>$Number</Number>")
    [void]$sb.AppendLine('      <ProgrammingLanguage>LAD</ProgrammingLanguage>')
    [void]$sb.AppendLine('      <SecondaryType>ProgramCycle</SecondaryType>')
    [void]$sb.AppendLine('      <SetENOAutomatically>false</SetENOAutomatically>')
    [void]$sb.AppendLine('    </AttributeList>')
    [void]$sb.AppendLine('    <ObjectList>')

    $uid = 100
    foreach ($net in $Networks) {
        $callUid = $uid; $uid++
        $accessUids = @{}
        $parts = New-Object System.Text.StringBuilder
        $wires = New-Object System.Text.StringBuilder
        $paramDecl = New-Object System.Text.StringBuilder

        foreach ($p in $net.params) {
            $aUid = $uid; $uid++
            $accessUids[$p.name] = $aUid
            switch ($p.operand.kind) {
                'Tag' {
                    [void]$parts.AppendLine("                <Access Scope=`"GlobalVariable`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Symbol>')
                    [void]$parts.AppendLine("                    <Component Name=`"$($p.operand.name)`" />")
                    [void]$parts.AppendLine('                  </Symbol>')
                    [void]$parts.AppendLine('                </Access>')
                }
                'IntLiteral' {
                    [void]$parts.AppendLine("                <Access Scope=`"LiteralConstant`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Constant>')
                    [void]$parts.AppendLine("                    <ConstantType>$($p.operand.constantType)</ConstantType>")
                    [void]$parts.AppendLine("                    <ConstantValue>$($p.operand.value)</ConstantValue>")
                    [void]$parts.AppendLine('                  </Constant>')
                    [void]$parts.AppendLine('                </Access>')
                }
                'TimeLiteral' {
                    [void]$parts.AppendLine("                <Access Scope=`"TypedConstant`" UId=`"$aUid`">")
                    [void]$parts.AppendLine('                  <Constant>')
                    [void]$parts.AppendLine("                    <ConstantValue>$($p.operand.value)</ConstantValue>")
                    [void]$parts.AppendLine('                  </Constant>')
                    [void]$parts.AppendLine('                </Access>')
                }
            }
            [void]$paramDecl.AppendLine("                    <Parameter Name=`"$($p.name)`" Section=`"$($p.section)`" Type=`"$($p.type)`" />")
        }

        [void]$parts.AppendLine("                <Call UId=`"$callUid`">")
        [void]$parts.AppendLine("                  <CallInfo Name=`"$($net.block)`" BlockType=`"FC`">")
        [void]$parts.Append($paramDecl.ToString())
        [void]$parts.AppendLine('                  </CallInfo>')
        [void]$parts.AppendLine('                </Call>')

        $wUid = $uid; $uid++
        [void]$wires.AppendLine("                <Wire UId=`"$wUid`">")
        [void]$wires.AppendLine('                  <Powerrail />')
        [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"en`" />")
        [void]$wires.AppendLine('                </Wire>')

        foreach ($p in $net.params) {
            $wUid = $uid; $uid++
            $aUid = $accessUids[$p.name]
            [void]$wires.AppendLine("                <Wire UId=`"$wUid`">")
            if ($p.section -eq 'Input') {
                [void]$wires.AppendLine("                  <IdentCon UId=`"$aUid`" />")
                [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"$($p.name)`" />")
            } else {
                [void]$wires.AppendLine("                  <NameCon UId=`"$callUid`" Name=`"$($p.name)`" />")
                [void]$wires.AppendLine("                  <IdentCon UId=`"$aUid`" />")
            }
            [void]$wires.AppendLine('                </Wire>')
        }

        $cuId = $uid; $uid++
        $cmtId = $uid; $uid++
        $cmtItemId = $uid; $uid++
        $ttlId = $uid; $uid++
        $ttlItemId = $uid; $uid++

        [void]$sb.AppendLine("      <SW.Blocks.CompileUnit ID=`"$cuId`" CompositionName=`"CompileUnits`">")
        [void]$sb.AppendLine('        <AttributeList>')
        [void]$sb.AppendLine('          <NetworkSource>')
        [void]$sb.AppendLine('            <FlgNet xmlns="http://www.siemens.com/automation/Openness/SW/NetworkSource/FlgNet/v5">')
        [void]$sb.AppendLine('              <Parts>')
        [void]$sb.Append($parts.ToString())
        [void]$sb.AppendLine('              </Parts>')
        [void]$sb.AppendLine('              <Wires>')
        [void]$sb.Append($wires.ToString())
        [void]$sb.AppendLine('              </Wires>')
        [void]$sb.AppendLine('            </FlgNet>')
        [void]$sb.AppendLine('          </NetworkSource>')
        [void]$sb.AppendLine('          <ProgrammingLanguage>LAD</ProgrammingLanguage>')
        [void]$sb.AppendLine('        </AttributeList>')
        [void]$sb.AppendLine('        <ObjectList>')
        [void]$sb.AppendLine("          <MultilingualText ID=`"$cmtId`" CompositionName=`"Comment`">")
        [void]$sb.AppendLine('            <ObjectList>')
        [void]$sb.AppendLine("              <MultilingualTextItem ID=`"$cmtItemId`" CompositionName=`"Items`">")
        [void]$sb.AppendLine('                <AttributeList>')
        [void]$sb.AppendLine('                  <Culture>zh-CN</Culture>')
        [void]$sb.AppendLine("                  <Text>$($net.comment)</Text>")
        [void]$sb.AppendLine('                </AttributeList>')
        [void]$sb.AppendLine('              </MultilingualTextItem>')
        [void]$sb.AppendLine('            </ObjectList>')
        [void]$sb.AppendLine('          </MultilingualText>')
        [void]$sb.AppendLine("          <MultilingualText ID=`"$ttlId`" CompositionName=`"Title`">")
        [void]$sb.AppendLine('            <ObjectList>')
        [void]$sb.AppendLine("              <MultilingualTextItem ID=`"$ttlItemId`" CompositionName=`"Items`">")
        [void]$sb.AppendLine('                <AttributeList>')
        [void]$sb.AppendLine('                  <Culture>zh-CN</Culture>')
        [void]$sb.AppendLine("                  <Text>$($net.title)</Text>")
        [void]$sb.AppendLine('                </AttributeList>')
        [void]$sb.AppendLine('              </MultilingualTextItem>')
        [void]$sb.AppendLine('            </ObjectList>')
        [void]$sb.AppendLine('          </MultilingualText>')
        [void]$sb.AppendLine('        </ObjectList>')
        [void]$sb.AppendLine('      </SW.Blocks.CompileUnit>')
    }

    [void]$sb.AppendLine('    </ObjectList>')
    [void]$sb.AppendLine('  </SW.Blocks.OB>')
    [void]$sb.AppendLine('</Document>')
    return $sb.ToString()
}

function Invoke-Method([string]$method, $params) {
    switch ($method) {
        'diagnose' {
            # Pure local checks, no TIA attach needed.
            $r = [ordered]@{}
            $grp = Get-LocalGroup -Name 'Siemens TIA Openness' -ErrorAction SilentlyContinue
            $r.groupExists = [bool]$grp
            $r.members = @()
            if ($grp) { $r.members = @(@(Get-LocalGroupMember -Group 'Siemens TIA Openness' -ErrorAction SilentlyContinue) | ForEach-Object { $_.Name }) }
            $id = [Security.Principal.WindowsIdentity]::GetCurrent()
            $r.currentUser = $id.Name
            $r.inGroup = $false
            if ($grp) {
                $r.inGroup = [bool](@(Get-LocalGroupMember -Group 'Siemens TIA Openness' -ErrorAction SilentlyContinue) | Where-Object { $_.SID.Value -eq $id.User.Value })
            }
            $r.inToken = $false
            if ($grp) { $r.inToken = [bool]($id.Groups | Where-Object { $_.Value -eq $grp.SID.Value }) }
            $r.tiaRunning = [bool](Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue)
            # 系统与 TIA 版本信息
            try { $r.osVersion = [System.Environment]::OSVersion.VersionString } catch { $r.osVersion = '' }
            $r.tiaVersion = ''
            $tiaInfo = Find-TiaOpenness
            if ($tiaInfo) { $r.tiaVersion = $tiaInfo.version }
            if (-not $tiaInfo) {
                $r.suggestions += '未找到 TIA Portal V21 的 Openness 组件: 需要安装 TIA Portal V21'
            }
            # 博途会写 C:\ProgramData\Siemens (授权/日志), 无写权限会弹"对该文件夹中应用程序数据的访问受限"
            $pdDir = Join-Path $env:ProgramData 'Siemens\Automation'
            $r.programDataDirExists = (Test-Path $pdDir)
            $r.programDataWritable = $false
            if ($r.programDataDirExists) {
                $probe = Join-Path $pdDir ('dsh-probe-' + [guid]::NewGuid().ToString('N') + '.tmp')
                try { [System.IO.File]::WriteAllText($probe, 'x'); Remove-Item $probe -Force -ErrorAction SilentlyContinue; $r.programDataWritable = $true } catch { $r.programDataWritable = $false }
            }
            $r.suggestions = @()
            if (-not $r.groupExists) {
                $r.suggestions += '组不存在: 运行 enable-tia-openness.ps1 (右键->使用 PowerShell 运行, UAC 点 是)'
            } elseif (-not $r.inGroup) {
                $r.suggestions += '组存在但当前用户不在组内: 运行 enable-tia-openness.ps1 并确认 UAC 点 是'
            } elseif (-not $r.inToken) {
                $r.suggestions += '已在组内但登录令牌未刷新: 注销并重新登录 Windows'
            }
            if (-not $r.programDataWritable) {
                $r.suggestions += 'C:\ProgramData\Siemens 无写权限: 博途会弹"对该文件夹中应用程序数据的访问受限"。应急: 弹窗点 重试 或右键博途以管理员身份运行; 持久: 给 C:\ProgramData\Siemens 加 Users 组的 修改 权限'
            }
            if (-not $r.tiaRunning) { $r.suggestions += '博途未运行 (连接工具会自动拉起, 无需处理)' }
            if ($r.groupExists -and $r.inGroup -and $r.inToken) { $r.suggestions += '权限正常, 可直接使用' }
            $r.ok = ($r.groupExists -and $r.inGroup -and $r.inToken)
            return $r
        }
        'status' {
            Ensure-Tia
            $projName = $null
            if ($script:proj) { $projName = $script:proj.Name }
            return @{ ok = $true; project = $projName }
        }
        'attach' {
            Ensure-Tia
            return @{ ok = $true; projects = @(@($script:tia.Projects) | ForEach-Object { $_.Name }) }
        }
        'project_open' {
            Ensure-Tia
            $target = Resolve-ProjectPath ([string]$params.path)
            $existing = @($script:tia.Projects) | Where-Object { $_.Path -eq $target } | Select-Object -First 1
            if ($existing) { $script:proj = $existing }
            else {
                Close-OpenProjects
                $script:proj = $script:tia.Projects.Open([System.IO.FileInfo]$target)
            }
            return @{ ok = $true; project = $script:proj.Name; path = $script:proj.Path.FullName }
        }
        'project_create' {
            Ensure-Tia
            $parent = [string]$params.path
            $name   = [string]$params.name
            if (-not $parent) { $parent = [Environment]::GetFolderPath('Desktop') }
            if (Test-Path (Join-Path $parent $name)) { throw "Folder already exists: $(Join-Path $parent $name)" }
            Close-OpenProjects
            $script:proj = $script:tia.Projects.Create([System.IO.DirectoryInfo]$parent, $name)
            return @{ ok = $true; project = $script:proj.Name; ap21 = $script:proj.Path.FullName }
        }
        'project_save' {
            if (-not $script:proj) { throw 'No project is open.' }
            $script:proj.Save()
            return @{ ok = $true; project = $script:proj.Name }
        }
        'device_add' {
            if (-not $script:proj) { throw 'No project is open.' }
            $order = [string]$params.orderNumber
            $ver   = [string]$params.version
            $name  = [string]$params.name
            $typeId = "OrderNumber:${order}/${ver}"
            $dev = $script:proj.Devices.CreateWithItem($typeId, $name, $name)
            $cpu = @($dev.DeviceItems) | Where-Object { $_.TypeIdentifier -match [regex]::Escape($order) } | Select-Object -First 1
            return @{ ok = $true; device = $dev.Name; cpu = if ($cpu) { $cpu.Name } else { $null } }
        }
        'blocks_list' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $items = @(@($plc.BlockGroup.Blocks) | ForEach-Object {
                @{ name = $_.Name; number = $_.Number; language = "$($_.ProgrammingLanguage)"; type = $_.GetType().Name; consistent = $_.IsConsistent }
            })
            return @{ ok = $true; project = $script:proj.Name; plc = $plc.Name; blocks = $items }
        }
        'block_delete' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $b = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq [string]$params.name } | Select-Object -First 1
            if (-not $b) { throw "Block not found: $($params.name)" }
            $b.Delete()
            return @{ ok = $true; deleted = [string]$params.name }
        }
        'tags_list' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
            $items = @(@($table.Tags) | ForEach-Object {
                $comment = ''
                $citems = @($_.Comment.Items)
                if ($citems.Count -gt 0) { $comment = [string]$citems[0].Text }
                @{ name = $_.Name; dataType = $_.DataTypeName; address = $_.LogicalAddress; comment = $comment }
            })
            return @{ ok = $true; table = $table.Name; count = $items.Count; tags = $items }
        }
        'tags_import' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
            $created = 0; $skipped = 0
            foreach ($t in @($params.tags)) {
                $name = [string]$t.name; $type = [string]$t.type; $addr = [string]$t.address
                $existing = @($table.Tags) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
                if ($existing) { $skipped++; continue }
                $tag = $table.Tags.Create($name, $type, $addr)
                $created++
                if ($t.comment) {
                    $citems = @($tag.Comment.Items)
                    if ($citems.Count -gt 0) { $citems[0].Text = [string]$t.comment }
                }
            }
            return @{ ok = $true; created = $created; skipped = $skipped; total = @($table.Tags).Count }
        }
        'compile_status' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $wait = if ($params.waitSeconds) { [int]$params.waitSeconds } else { 0 }
            $deadline = (Get-Date).AddSeconds($wait)
            $bad = @()
            $items = @()
            do {
                $items = @(@($plc.BlockGroup.Blocks) | ForEach-Object {
                    @{ name = $_.Name; number = $_.Number; language = "$($_.ProgrammingLanguage)"; consistent = $_.IsConsistent }
                })
                $bad = @($items | Where-Object { -not $_.consistent } | ForEach-Object { $_.name })
                if ($bad.Count -eq 0) { break }
                if ((Get-Date) -lt $deadline) { Start-Sleep -Seconds 5 }
            } while ((Get-Date) -lt $deadline)
            return @{
                ok = $true
                allConsistent = ($bad.Count -eq 0)
                inconsistent = $bad
                blocks = $items
                note = '编译需在 TIA 中人工执行: 右键 PLC_1 -> 编译 -> 软件(全部编译)。本工具只轮询状态。'
            }
        }
        'block_rename' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $results = @()
            foreach ($r in @($params.renames)) {
                $from = [string]$r.from; $to = [string]$r.to
                $b = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $from } | Select-Object -First 1
                if (-not $b) { $results += @{ from = $from; to = $to; ok = $false; error = 'source not found' }; continue }
                $dup = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $to } | Select-Object -First 1
                if ($dup) { $results += @{ from = $from; to = $to; ok = $false; error = 'target name exists' }; continue }
                $b.Name = $to
                $results += @{ from = $from; to = $to; ok = $true }
            }
            return @{ ok = $true; results = $results }
        }
        'db_fb_create' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = [string]$params.name
            $slots = if ($params.slotCount) { [int]$params.slotCount } else { 255 }
            $scl = Build-DbFbScl -Name $name -Slots $slots
            $tmp = Join-Path $env:TEMP ('tia-dbfb-' + [guid]::NewGuid().ToString('N') + '.scl')
            [System.IO.File]::WriteAllText($tmp, $scl, (New-Object System.Text.UTF8Encoding($true)))
            $srcName = 'Src_' + $name
            $oldSrc = @($plc.ExternalSourceGroup.ExternalSources) | Where-Object { $_.Name -eq $srcName } | Select-Object -First 1
            if ($oldSrc) { $oldSrc.Delete() }
            $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($srcName, $tmp)
            $src.GenerateBlocksFromSource()
            Start-Sleep -Seconds 2
            $b = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            return @{ ok = $true; created = [bool]$b; name = $name; slots = $slots; number = if ($b) { $b.Number } else { $null } }
        }
        'password_scan' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $rx = [regex]'(?i)(pass(word)?|pwd|密码|口令)\s*[:：=]\s*([A-Za-z0-9@#\.!_-]{4,32})'
            $hits = @(); $skipped = @()
            $tmpDir = Join-Path $env:TEMP ('pwdscan-' + [guid]::NewGuid().ToString('N'))
            [void][System.IO.Directory]::CreateDirectory($tmpDir)
            try {
                $allBlocks = @($plc.BlockGroup.Blocks)
                foreach ($grp in @($plc.BlockGroup.Groups)) { $allBlocks += @($grp.Blocks) }
                foreach ($b in $allBlocks) {
                    if (-not $b.IsConsistent) { $skipped += $b.Name; continue }
                    $f = Join-Path $tmpDir (($b.Name -replace '[^\w\u4e00-\u9fa5]', '_') + '_' + $b.Number + '.xml')
                    try {
                        $b.Export([System.IO.FileInfo]$f, [Siemens.Engineering.ExportOptions]::WithDefaults)
                        $content = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
                        foreach ($m in $rx.Matches($content)) {
                            $start = [Math]::Max(0, $m.Index - 30)
                            $len = [Math]::Min(90, $content.Length - $start)
                            $ctx = ($content.Substring($start, $len) -replace '\s+', ' ')
                            $hits += @{ block = $b.Name; match = $m.Value; context = $ctx }
                        }
                    } catch { $skipped += ($b.Name + '(导出失败)') }
                }
            } finally {
                Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
            }
            return @{ ok = $true; hits = $hits; skipped = $skipped; note = '建议: 生产项目不要在标题/注释里明文存密码, 改用加密校验或 HMI 输入。' }
        }
        'tags_create' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
            $created = 0
            foreach ($t in @($params.tags)) {
                $name = [string]$t.name; $type = [string]$t.type; $addr = [string]$t.address
                $existing = @($table.Tags) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
                if (-not $existing) { [void]$table.Tags.Create($name, $type, $addr); $created++ }
            }
            return @{ ok = $true; created = $created; total = @($table.Tags).Count }
        }
        'stacker_db_homework' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $pkgRoot = Join-Path $PSScriptRoot 'templates\db-homework'
            $name = if ($params.name) { [string]$params.name } else { 'Winsynth_Database' }
            $results = @{ fb = ''; udts = @(); backupDb = '' }

            # 1. UDT 三件套
            $existingTypes = @($plc.TypeGroup.Types) | ForEach-Object { $_.Name }
            $needUdts = @()
            foreach ($n in @('DataBaseConv','Record','Jurssd')) {
                if ($existingTypes -notcontains $n) { $needUdts += $n }
            }
            if ($needUdts.Count -gt 0) {
                foreach ($n in $needUdts) {
                    $udtFile = Join-Path $pkgRoot "winsynth-udt-$n.xml"
                    if (-not (Test-Path $udtFile)) { throw "缺少部署素材: $udtFile" }
                    $tmpUdt = Join-Path $env:TEMP ('tia-hw-udt-' + [guid]::NewGuid().ToString('N') + '.xml')
                    Copy-Item $udtFile $tmpUdt -Force
                    $null = $plc.TypeGroup.Types.Import([System.IO.FileInfo]$tmpUdt, [Siemens.Engineering.ImportOptions]::Override)
                }
                Start-Sleep -Seconds 2
            }
            $results.udts = @($plc.TypeGroup.Types) | ForEach-Object { $_.Name }

            # 2. 留白版 FB(增已实现, 删查改空壳=作业)
            $hwXmlPath = Join-Path $pkgRoot 'stacker-db-homework.xml'
            if (-not (Test-Path $hwXmlPath)) { throw "缺少作业素材: $hwXmlPath" }
            $hwXml = [System.IO.File]::ReadAllText($hwXmlPath, [System.Text.Encoding]::UTF8)
            $hwXml = $hwXml.Replace('Winsynth_Database', $name)
            $tmpFb = Join-Path $env:TEMP ('tia-hw-fb-' + [guid]::NewGuid().ToString('N') + '.xml')
            [System.IO.File]::WriteAllText($tmpFb, $hwXml, (New-Object System.Text.UTF8Encoding($true)))
            $null = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmpFb, [Siemens.Engineering.ImportOptions]::Override)
            $results.fb = $name

            # 3. 备份区 DB
            $bakXmlPath = Join-Path $pkgRoot 'winsynth-db-backup.xml'
            if (Test-Path $bakXmlPath) {
                $tmpBak = Join-Path $env:TEMP ('tia-hw-bak-' + [guid]::NewGuid().ToString('N') + '.xml')
                Copy-Item $bakXmlPath $tmpBak -Force
                $null = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmpBak, [Siemens.Engineering.ImportOptions]::Override)
                $results.backupDb = '备份区'
            }
            $proj.Save()
            $results.ok = $true
            $results.homework = @(
                '作业(参考 AddData 的步进机写法):',
                '1) 给 DelMain/ReadMain/UpDataMain 三个结构体各补 5 个字段: Step/num/num1/Locking/Temp : Int',
                '2) 补全 DelData/ReadData/UpData 三个 REGION 的业务逻辑',
                '3) 补仲裁链: 在业务仲裁的 ELSIF 链里给三个业务各加输出分支',
                '4) 编译并保存, 然后用 homework_check 检查'
            ) -join "`r`n"
            return $results
        }
        'homework_check' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = if ($params.name) { [string]$params.name } else { 'Winsynth_Database' }
            $fb = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            if (-not $fb) {
                foreach ($grp in @($plc.BlockGroup.Groups)) {
                    $x = @($grp.Blocks) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
                    if ($x) { $fb = $x; break }
                }
            }
            if (-not $fb) { throw "Block not found: $name" }
            if (-not $fb.IsConsistent) {
                return @{ ok = $true; compiled = $false; note = '块未编译一致。先: 右键PLC->编译->软件(全部编译) 再保存, 然后重新检查。' }
            }
            $tmp = Join-Path $env:TEMP ('hw-' + [guid]::NewGuid().ToString('N') + '.xml')
            $fb.Export([System.IO.FileInfo]$tmp, [Siemens.Engineering.ExportOptions]::WithDefaults)
            $raw = [System.IO.File]::ReadAllText($tmp, [System.Text.Encoding]::UTF8)
            Remove-Item $tmp -Force

            $checks = [ordered]@{}
            $checks.删DelData = if ($raw.Contains('业务代码：16#20')) { '✅ 已实现' } else { '❌ 空壳' }
            $checks.查ReadData = if ($raw.Contains('业务代码：16#30')) { '✅ 已实现' } else { '❌ 空壳' }
            $checks.改UpData = if ($raw.Contains('业务代码：16#40')) { '✅ 已实现' } else { '❌ 空壳' }

            $fieldInfo = @()
            foreach ($s in @('DelMain','ReadMain','UpDataMain')) {
                $pos = $raw.IndexOf("<Member Name=`"$s`"")
                if ($pos -lt 0) { $fieldInfo += "${s}: 结构体缺失"; continue }
                $nextName = switch ($s) { 'DelMain' { 'ReadMain' } 'ReadMain' { 'UpDataMain' } 'UpDataMain' { 'DataCheck' } }
                $end = $raw.IndexOf("<Member Name=`"$nextName`"", $pos + 10)
                if ($end -lt 0) { $end = $pos + 8000 }
                $seg = $raw.Substring($pos, $end - $pos)
                $missing = @()
                foreach ($f in @('Step','num','num1','Locking','Temp')) {
                    if ($seg -notmatch "Name=`"$f`"") { $missing += $f }
                }
                $fieldInfo += if ($missing.Count -eq 0) { "${s}: 5字段齐" } else { "${s}: 缺[$($missing -join ',')]" }
            }
            $checks.接口字段 = $fieldInfo -join ' | '

            # 仲裁链: 四个业务名首次出现位置应等距(在代码开头, 间距<8000字符)
            $stPos = $raw.IndexOf('<StructuredText')
            $posAdd = $raw.IndexOf('<Component Name="AddMain"', $stPos)
            $posDel = $raw.IndexOf('<Component Name="DelMain"', $stPos)
            $posRead = $raw.IndexOf('<Component Name="ReadMain"', $stPos)
            $posUp = $raw.IndexOf('<Component Name="UpDataMain"', $stPos)
            $arbOk = ($posAdd -ge 0) -and ($posDel - $posAdd -gt 0) -and ($posDel - $posAdd -lt 8000) -and ($posRead - $posDel -gt 0) -and ($posRead - $posDel -lt 8000) -and ($posUp - $posRead -gt 0) -and ($posUp - $posRead -lt 8000)
            $checks.仲裁链 = if ($arbOk) { '✅ 四业务等距挂载' } else { '❌ 仲裁链不完整(检查 ELSIF 分支)' }

            $steps = @('判断系统就绪','执行权限检查','执行数据转换','全库扫描匹配目标数据','数据进入载存','打印日志','输出标志位','函数返回','错误退出')
            $missingSteps = @()
            foreach ($c in $steps) { if (-not $raw.Contains($c)) { $missingSteps += $c } }
            $checks.步骤注释 = if ($missingSteps.Count -eq 0) { '✅ 齐全' } else { "缺: $($missingSteps -join ', ')" }

            $codeInfo = @()
            foreach ($c in @('16#10','16#20','16#30','16#40','16#50')) {
                $n = ([regex]::Matches($raw, [regex]::Escape($c))).Count
                $codeInfo += "$c=$n"
            }
            $checks.错误码 = $codeInfo -join ' '

            $passCount = @($checks.Values | Where-Object { $_ -match '^✅|齐$' }).Count
            return @{ ok = $true; compiled = $true; checks = $checks; note = '批语: 对照检查项逐条修改, 别直接抄标准答案。拿不准的找小文老师确认。' }
        }
        'xiaowen_templates' {
            return @{
                ok = $true
                templates = @(
                    @{ id = '数据库'; name = '小文老师的数据库(完整版)'; desc = '堆垛机任务数据库: 增删查改清五命令+30位产品协议+双棒配对+三级权限+审计日志+载存备份. 触发语: 部署小文老师的数据库 / 部署数据库' },
                    @{ id = '数据库作业版'; name = '数据库作业版(留白教学)'; desc = '增已实现, 删查改空壳留给学员. 配 homework_check 批改. 触发语: 部署数据库作业 / 作业版' },
                    @{ id = '水泥厂'; name = '水泥厂(接口教学工程)'; desc = '8个FB模块化架构(模式选择/报警/标准化/手动/诊断/G120/状态/自动). 教接口概念用. 触发语: 部署水泥厂' },
                    @{ id = 'RTU'; name = '表格化Modbus轮询引擎(WinSynthRtu)'; desc = '50通道填表轮询, 防呆自检. 触发语: 部署RTU / 部署Modbus轮询' },
                    @{ id = 'EPOS'; name = 'EPOS定位封装(WinSynthEpos)'; desc = '填机械参数(mm/LU换算), 含编码器校正. 触发语: 部署EPOS / 部署定位' }
                )
            }
        }
        'xiaowen_deploy' {
            if (-not $script:proj) { throw 'No project is open.' }
            $tpl = [string]$params.template
            $map = @{
                '数据库'    = @{ dir = 'db'; device = '6ES7 215-1AG40-0XB0/V4.2'; order = @('*.xml') }
                '数据库作业版' = @{ dir = 'db-homework'; device = '6ES7 215-1AG40-0XB0/V4.2' }
                '水泥厂'    = @{ dir = 'cement'; device = '6ES7 212-1AE40-0XB0/V4.5' }
                'RTU'      = @{ dir = 'rtu'; device = '6ES7 212-1AE40-0XB0/V4.5' }
                'EPOS'     = @{ dir = 'epos'; device = '6ES7 212-1AE40-0XB0/V4.5' }
            }
            # 模糊匹配
            $key = $null
            foreach ($k in $map.Keys) { if ($tpl -match [regex]::Escape($k)) { $key = $k; break } }
            if (-not $key -and $tpl -match '作业') { $key = '数据库作业版' }
            if (-not $key) { throw "未知模板: $tpl. 可用: $($map.Keys -join ' / ')" }
            $spec = $map[$key]
            $pkgDir = Join-Path $PSScriptRoot ('templates\' + $spec.dir)
            if (-not (Test-Path $pkgDir)) { throw "缺少模板素材: $pkgDir" }

            # 0. 确保有 S7 设备
            $dev = $proj.Devices | Where-Object { $_.TypeIdentifier -match 'S71200|S71500' } | Select-Object -First 1
            if (-not $dev) {
                $dev = $proj.Devices.CreateWithItem(('OrderNumber:' + $spec.device), 'PLC_1', 'PLC_1')
                Start-Sleep -Seconds 2
            }
            $plc = Get-PlcObject
            if (-not $plc) { throw '未找到 PLC 软件(设备创建失败?)' }

            # 1. UDT XML 优先导入(文件名含 udt 的均为 UDT)
            $udtImported = @()
            foreach ($f in @(Get-ChildItem $pkgDir -Filter '*.xml' | Where-Object { $_.Name -match '(?i)udt' })) {
                $tmp = Join-Path $env:TEMP ('tpl-udt-' + [guid]::NewGuid().ToString('N') + '.xml')
                Copy-Item $f.FullName $tmp -Force
                $null = $plc.TypeGroup.Types.Import([System.IO.FileInfo]$tmp, [Siemens.Engineering.ImportOptions]::Override)
                $udtImported += $f.BaseName
            }
            Start-Sleep -Seconds 1

            # 2. 块 XML 导入(全部 Override)
            $blockImported = @()
            foreach ($f in @(Get-ChildItem $pkgDir -Filter '*.xml' | Where-Object { $_.Name -notmatch '(?i)udt' })) {
                $tmp = Join-Path $env:TEMP ('tpl-blk-' + [guid]::NewGuid().ToString('N') + '.xml')
                Copy-Item $f.FullName $tmp -Force
                try {
                    $null = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmp, [Siemens.Engineering.ImportOptions]::Override)
                    $blockImported += $f.BaseName -replace '_\d+$', ''
                } catch {
                    $blockImported += ($f.BaseName + '(失败:' + $_.Exception.Message.Substring(0, [Math]::Min(60, $_.Exception.Message.Length)) + ')')
                }
            }
            Start-Sleep -Seconds 2

            # 3. 配套数据块(companion.scl: 实例DB+全局DB)
            $companionCreated = $false
            $companionPath = Join-Path $pkgDir 'companion.scl'
            if (Test-Path $companionPath) {
                $srcName = 'Src_' + $key + '_Companion'
                $oldSrc = @($plc.ExternalSourceGroup.ExternalSources) | Where-Object { $_.Name -eq $srcName } | Select-Object -First 1
                if ($oldSrc) { $oldSrc.Delete() }
                $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($srcName, $companionPath)
                $src.GenerateBlocksFromSource()
                $companionCreated = $true
                Start-Sleep -Seconds 2
            }

            # 4. 配套 PLC 标签(tags.json)
            $tagsCreated = 0
            $tagsPath = Join-Path $pkgDir 'tags.json'
            if (Test-Path $tagsPath) {
                $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
                $tagList = Get-Content $tagsPath -Raw -Encoding UTF8 | ConvertFrom-Json
                foreach ($t in @($tagList)) {
                    $tn = [string]$t.name
                    $existing = @($table.Tags) | Where-Object { $_.Name -eq $tn } | Select-Object -First 1
                    if (-not $existing) {
                        try {
                            [void]$table.Tags.Create($tn, [string]$t.type, [string]$t.address)
                            $tagsCreated++
                        } catch {}
                    }
                }
            }
            $proj.Save()
            return @{
                ok = $true
                template = $key
                device = $spec.device
                udts = $udtImported
                blocks = $blockImported
                companion = $companionCreated
                tags = $tagsCreated
                note = '部署完成。下一步(人工): 右键 PLC_1 -> 编译 -> 软件(全部编译), 然后 Ctrl+S 保存。水泥厂/RTU/EPOS 模板如需原机硬件(模块/变频器), 编译报错时按现场硬件配置调整。'
            }
        }
        'udt_create' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = [string]$params.name
            $members = @($params.members)
            if ($members.Count -eq 0) { throw 'members is empty (至少一个 {name,type} 成员)' }
            $existing = @($plc.TypeGroup.Types) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            if ($existing) { return @{ ok = $true; created = $false; name = $name; note = '已存在, 跳过' } }
            $b = New-Object System.Text.StringBuilder
            [void]$b.AppendLine("TYPE `"$name`"")
            [void]$b.AppendLine('VERSION : 0.1')
            [void]$b.AppendLine('STRUCT')
            foreach ($m in $members) {
                [void]$b.AppendLine("    $($m.name) : $($m.type);")
            }
            [void]$b.AppendLine('END_STRUCT;')
            [void]$b.AppendLine('')
            [void]$b.AppendLine('END_TYPE')
            $tmp = Join-Path $env:TEMP ('tia-udt-' + [guid]::NewGuid().ToString('N') + '.scl')
            [System.IO.File]::WriteAllText($tmp, $b.ToString(), (New-Object System.Text.UTF8Encoding($true)))
            $srcName = 'Src_UDT_' + $name
            $oldSrc = @($plc.ExternalSourceGroup.ExternalSources) | Where-Object { $_.Name -eq $srcName } | Select-Object -First 1
            if ($oldSrc) { $oldSrc.Delete() }
            $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($srcName, $tmp)
            $src.GenerateBlocksFromSource()
            Start-Sleep -Seconds 1
            $t = @($plc.TypeGroup.Types) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            return @{ ok = $true; created = [bool]$t; name = $name }
        }
        'stacker_db_deploy' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = if ($params.name) { [string]$params.name } else { 'Winsynth_Database' }
            $pkgRoot = Join-Path $PSScriptRoot 'templates\db'
            $results = @{ fb = ''; udts = @(); backupDb = '' }

            # 1. UDT 三件套(从打包的 XML 导入, 避免 SCL 保留字问题如 Record.Type)
            $existingTypes = @($plc.TypeGroup.Types) | ForEach-Object { $_.Name }
            $needUdts = @()
            foreach ($n in @('DataBaseConv','Record','Jurssd')) {
                if ($existingTypes -notcontains $n) { $needUdts += $n }
            }
            if ($needUdts.Count -gt 0) {
                foreach ($n in $needUdts) {
                    $udtFile = Join-Path $pkgRoot "winsynth-udt-$n.xml"
                    if (-not (Test-Path $udtFile)) { throw "缺少部署素材: $udtFile" }
                    $tmpUdt = Join-Path $env:TEMP ('tia-deploy-udt-' + [guid]::NewGuid().ToString('N') + '.xml')
                    Copy-Item $udtFile $tmpUdt -Force
                    $null = $plc.TypeGroup.Types.Import([System.IO.FileInfo]$tmpUdt, [Siemens.Engineering.ImportOptions]::Override)
                }
                Start-Sleep -Seconds 2
            }
            $results.udts = @($plc.TypeGroup.Types) | ForEach-Object { $_.Name }

            # 2. FB 部署(从打包的 XML 导入, 支持改名)
            $fbXmlPath = Join-Path $pkgRoot 'winsynth-db-fb.xml'
            if (-not (Test-Path $fbXmlPath)) { throw "缺少部署素材: $fbXmlPath" }
            $fbXml = [System.IO.File]::ReadAllText($fbXmlPath, [System.Text.Encoding]::UTF8)
            $fbXml = $fbXml.Replace('Winsynth_Database', $name)
            $tmpFb = Join-Path $env:TEMP ('tia-deploy-fb-' + [guid]::NewGuid().ToString('N') + '.xml')
            [System.IO.File]::WriteAllText($tmpFb, $fbXml, (New-Object System.Text.UTF8Encoding($true)))
            $imported = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmpFb, [Siemens.Engineering.ImportOptions]::Override)
            $results.fb = $name

            # 3. 备份区 DB 部署
            $bakXmlPath = Join-Path $pkgRoot 'winsynth-db-backup.xml'
            if (Test-Path $bakXmlPath) {
                $tmpBak = Join-Path $env:TEMP ('tia-deploy-bak-' + [guid]::NewGuid().ToString('N') + '.xml')
                Copy-Item $bakXmlPath $tmpBak -Force
                $null = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmpBak, [Siemens.Engineering.ImportOptions]::Override)
                $results.backupDb = '备份区'
            }
            $proj.Save()
            $results.ok = $true
            $results.note = '部署完成。剩余人工步骤: 1) 右键PLC->编译->软件(全部编译) 2) 在Main中调用FB(可用 lad_main_import 生成调用网络, DataBackUp 接 备份区.产品信息)'
            return $results
        }
        'lad_main_import' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = if ($params.name) { [string]$params.name } else { 'Main' }
            $number = if ($params.number) { [int]$params.number } else { 1 }
            $nets = @($params.networks)
            if ($nets.Count -eq 0) { throw 'networks is empty' }

            # Ensure tags exist for Tag operands
            $table = @($plc.TagTableGroup.TagTables) | Where-Object { $_.IsDefault } | Select-Object -First 1
            foreach ($net in $nets) {
                foreach ($p in @($net.params)) {
                    if ($p.operand.kind -eq 'Tag') {
                        $tn = [string]$p.operand.name
                        $existing = @($table.Tags) | Where-Object { $_.Name -eq $tn } | Select-Object -First 1
                        if (-not $existing) {
                            $tt = if ($p.operand.dataType) { [string]$p.operand.dataType } else { [string]$p.type }
                            [void]$table.Tags.Create($tn, $tt, [string]$p.operand.address)
                        }
                    }
                }
            }

            $xml = Build-LadMainXml -Networks $nets -Name $name -Number $number
            $tmp = Join-Path $env:TEMP ('tia-lad-' + [guid]::NewGuid().ToString('N') + '.xml')
            [System.IO.File]::WriteAllText($tmp, $xml, (New-Object System.Text.UTF8Encoding($true)))
            $imported = $plc.BlockGroup.Blocks.Import([System.IO.FileInfo]$tmp, [Siemens.Engineering.ImportOptions]::Override)
            $names = @($imported | ForEach-Object { $_.Name })
            return @{ ok = $true; imported = $names; networks = $nets.Count }
        }
        'project_list' {
            Ensure-Tia
            $items = @(@($script:tia.Projects) | ForEach-Object { @{ name = $_.Name; path = $_.Path.FullName } })
            return @{ ok = $true; projects = $items }
        }
        'project_close' {
            Ensure-Tia
            $p = @($script:tia.Projects) | Where-Object { $_.Name -eq [string]$params.name } | Select-Object -First 1
            if (-not $p) { throw "Project not open: $($params.name)" }
            $p.Close()
            if ($script:proj -and $script:proj.Name -eq $p.Name) { $script:proj = $null }
            return @{ ok = $true; closed = [string]$params.name }
        }
        'device_list' {
            if (-not $script:proj) { throw 'No project is open.' }
            $items = @(@($script:proj.Devices) | ForEach-Object {
                $d = $_
                @{
                    name = $d.Name
                    typeIdentifier = $d.TypeIdentifier
                    items = @(@($d.DeviceItems) | ForEach-Object { @{ name = $_.Name; typeIdentifier = $_.TypeIdentifier } })
                }
            })
            return @{ ok = $true; devices = $items }
        }
        'catalog_search' {
            Ensure-Tia
            $q = [string]$params.query
            $hits = @($script:tia.HardwareCatalog.Find($q) | Select-Object -First 20 | ForEach-Object {
                @{ typeIdentifier = $_.TypeIdentifier; name = $_.TypeName; version = "$($_.Version)" }
            })
            return @{ ok = $true; query = $q; results = $hits }
        }
        'fb_create' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = [string]$params.name
            $b = New-Object System.Text.StringBuilder
            [void]$b.AppendLine("FUNCTION_BLOCK `"$name`"")
            [void]$b.AppendLine("{ S7_Optimized_Access := 'TRUE' }")
            [void]$b.AppendLine('VERSION : 0.1')
            if ($params.inputs) {
                [void]$b.AppendLine('VAR_INPUT')
                foreach ($i in @($params.inputs)) { [void]$b.AppendLine("    $($i.name) : $($i.type);") }
                [void]$b.AppendLine('END_VAR')
            }
            if ($params.outputs) {
                [void]$b.AppendLine('VAR_OUTPUT')
                foreach ($o in @($params.outputs)) { [void]$b.AppendLine("    $($o.name) : $($o.type);") }
                [void]$b.AppendLine('END_VAR')
            }
            if ($params.statics) {
                [void]$b.AppendLine('VAR')
                foreach ($s in @($params.statics)) { [void]$b.AppendLine("    $($s.name) : $($s.type);") }
                [void]$b.AppendLine('END_VAR')
            }
            [void]$b.AppendLine('BEGIN')
            $body = if ($params.body) { [string]$params.body } else { '    // FB body' + "`r`n" + '    ;' }
            [void]$b.AppendLine($body)
            [void]$b.AppendLine("END_FUNCTION_BLOCK")
            $tmp = Join-Path $env:TEMP ('tia-fb-' + [guid]::NewGuid().ToString('N') + '.scl')
            [System.IO.File]::WriteAllText($tmp, $b.ToString(), (New-Object System.Text.UTF8Encoding($true)))
            $srcName = 'Src_' + $name
            $oldSrc = @($plc.ExternalSourceGroup.ExternalSources) | Where-Object { $_.Name -eq $srcName } | Select-Object -First 1
            if ($oldSrc) { $oldSrc.Delete() }
            $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($srcName, $tmp)
            $src.GenerateBlocksFromSource()
            Start-Sleep -Seconds 2
            $fb = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            return @{ ok = $true; created = [bool]$fb; name = $name; number = if ($fb) { $fb.Number } else { $null }; language = if ($fb) { "$($fb.ProgrammingLanguage)" } else { $null } }
        }
        'scl_import' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = [string]$params.name
            $scl = [string]$params.scl
            $tmp = Join-Path $env:TEMP ('tia-scl-' + [guid]::NewGuid().ToString('N') + '.scl')
            [System.IO.File]::WriteAllText($tmp, $scl, (New-Object System.Text.UTF8Encoding($true)))
            $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($name, $tmp)
            $src.GenerateBlocksFromSource()
            Start-Sleep -Seconds 2
            $blocks = @(@($plc.BlockGroup.Blocks) | ForEach-Object { $_.Name })
            return @{ ok = $true; source = $name; blocks = $blocks }
        }
        'block_export' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $b = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq [string]$params.name } | Select-Object -First 1
            if (-not $b) { throw "Block not found: $($params.name)" }
            if (-not $b.IsConsistent) { throw "Block '$($params.name)' is not consistent. Compile it in TIA first, then retry." }
            $outPath = [string]$params.path
            $b.Export([System.IO.FileInfo]$outPath, [Siemens.Engineering.ExportOptions]::WithDefaults)
            return @{ ok = $true; exported = $outPath; bytes = (Get-Item $outPath).Length }
        }
        'fc_create' {
            if (-not $script:proj) { throw 'No project is open.' }
            $plc = Get-PlcObject
            $name = [string]$params.name
            $body = [string]$params.body
            if (-not $body) { $body = '    // empty block' + "`r`n" + '    ;' }
            $srcText = "FUNCTION `"$name`" : Void`r`n{ S7_Optimized_Access := 'TRUE' }`r`nVERSION : 0.1`r`nBEGIN`r`n" + $body + "`r`nEND_FUNCTION`r`n"
            $tmp = Join-Path $env:TEMP ('tia-fc-' + [guid]::NewGuid().ToString('N') + '.scl')
            [System.IO.File]::WriteAllText($tmp, $srcText, (New-Object System.Text.UTF8Encoding($true)))
            $srcName = 'Src_' + $name
            $oldSrc = @($plc.ExternalSourceGroup.ExternalSources) | Where-Object { $_.Name -eq $srcName } | Select-Object -First 1
            if ($oldSrc) { $oldSrc.Delete() }
            $src = $plc.ExternalSourceGroup.ExternalSources.CreateFromFile($srcName, $tmp)
            $src.GenerateBlocksFromSource()
            Start-Sleep -Seconds 2
            $b = @($plc.BlockGroup.Blocks) | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            return @{ ok = $true; created = [bool]$b; name = $name; number = if ($b) { $b.Number } else { $null }; language = if ($b) { "$($b.ProgrammingLanguage)" } else { $null } }
        }
        default { throw "Unknown method: $method" }
    }
}

# ---------- JSON-RPC loop ----------
while ($true) {
    $line = [Console]::In.ReadLine()
    if ($null -eq $line) { break }
    $req = $null
    try { $req = $line | ConvertFrom-Json } catch { continue }
    $respId = if ($req.id) { $req.id } else { 0 }
    try {
        $p = if ($req.params) { $req.params } else { @{} }
        $result = Invoke-Method ([string]$req.method) $p
        $json = @{ jsonrpc = '2.0'; id = $respId; result = $result } | ConvertTo-Json -Depth 12 -Compress
    } catch {
        $msg = $_.Exception.Message
        $json = @{ jsonrpc = '2.0'; id = $respId; error = @{ code = -32000; message = $msg } } | ConvertTo-Json -Depth 6 -Compress
    }
    [Console]::Out.WriteLine($json)
    [Console]::Out.Flush()
}
