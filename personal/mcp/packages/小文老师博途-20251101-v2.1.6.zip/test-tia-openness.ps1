﻿<#
.SYNOPSIS
    验证 TIA Portal Openness 权限是否已生效。
.DESCRIPTION
    1. 检查当前登录令牌里是否已包含 "Siemens TIA Openness" 组。
    2. 自动定位已安装的 TIA Portal 版本和 Openness API 程序集。
    3. 连接正在运行的 TIA Portal，执行一次只读访问（列出已打开工程）。

    需要先运行 enable-tia-openness.ps1 并注销重新登录。
.NOTES
    只读验证，不会修改任何工程。
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$GroupName = 'Siemens TIA Openness'

Write-Host '=== 检查 1：当前令牌中的组 ===' -ForegroundColor Cyan
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
Write-Host "当前用户：$($identity.Name)"

$group = Get-LocalGroup -Name $GroupName -ErrorAction SilentlyContinue
if (-not $group) {
    Write-Host "找不到本地组 '$GroupName'，请先运行 enable-tia-openness.ps1。" -ForegroundColor Red
    Read-Host '按回车键退出'
    return
}

$inToken = $identity.Groups | Where-Object { $_.Value -eq $group.SID.Value }
if (-not $inToken) {
    Write-Host "组已存在，但当前登录令牌里还没有它 —— 需要注销并重新登录。" -ForegroundColor Yellow
    Read-Host '按回车键退出'
    return
}
Write-Host '令牌中已包含该组，权限已生效。' -ForegroundColor Green

Write-Host ''
Write-Host '=== 检查 2：定位 TIA Portal Openness API ===' -ForegroundColor Cyan
$portal = Get-ChildItem 'C:\Program Files\Siemens\Automation' -Directory -Filter 'Portal V*' -ErrorAction SilentlyContinue |
    Sort-Object { [int]($_.Name -replace '\D', '') } -Descending | Select-Object -First 1
if (-not $portal) {
    Write-Host '未找到 TIA Portal 安装目录。' -ForegroundColor Red
    Read-Host '按回车键退出'
    return
}
$version = $portal.Name -replace 'Portal V', ''
Write-Host "找到：$($portal.FullName)（V$version）"

# 枚举 PublicAPI 下的实际版本目录(大小写/小版本号都可能不同), 找含 net48 的
$net48 = $null
$pub = Join-Path $portal.FullName 'Bin\PublicAPI'
$apiRoot = Join-Path $portal.FullName 'PublicAPI'
if (Test-Path $apiRoot) {
    foreach ($sub in @(Get-ChildItem $apiRoot -Directory -ErrorAction SilentlyContinue)) {
        $candidate = Join-Path $sub.FullName 'net48'
        if (Test-Path (Join-Path $candidate 'Siemens.Engineering.Base.dll')) { $net48 = $candidate; break }
    }
}
$baseDll = if ($net48) { Join-Path $net48 'Siemens.Engineering.Base.dll' } else { '' }
if (-not (Test-Path $baseDll)) {
    Write-Host "找不到 Openness 程序集：$baseDll" -ForegroundColor Red
    Read-Host '按回车键退出'
    return
}

[Environment]::CurrentDirectory = $net48
foreach ($d in @(
        (Join-Path $pub 'Siemens.Engineering.Contract.dll'),
        (Join-Path $pub 'Siemens.Engineering.ClientAdapter.Interfaces.dll'),
        $baseDll)) {
    try { [void][System.Reflection.Assembly]::LoadFrom($d) }
    catch { Write-Host "加载失败：$d`n$($_.Exception.Message)" -ForegroundColor Red; Read-Host '按回车键退出'; return }
}
Write-Host '程序集加载完成。' -ForegroundColor Green

Write-Host ''
Write-Host '=== 检查 3：连接 TIA Portal ===' -ForegroundColor Cyan
$procs = [Siemens.Engineering.TiaPortal]::GetProcesses()
if ($procs.Count -eq 0) {
    Write-Host '没有检测到正在运行的 TIA Portal，请先启动它再运行本脚本。' -ForegroundColor Yellow
    Read-Host '按回车键退出'
    return
}

foreach ($p in $procs) {
    Write-Host "发现实例：PID $($p.Id)，模式 $($p.Mode)"
    try {
        $tia = $p.Attach()
        Write-Host '  -> Attach 成功，Openness 权限正常。' -ForegroundColor Green
        Write-Host "  -> 当前已打开工程数：$($tia.Projects.Count)"
        foreach ($proj in $tia.Projects) {
            Write-Host ("     [{0}] {1}" -f $proj.Name, $proj.Path)
        }
    }
    catch {
        Write-Host '  -> Attach 失败：' -ForegroundColor Red
        Write-Host "     $($_.Exception.Message)" -ForegroundColor Red
        if ($_.Exception.Message -match 'Siemens TIA Openness') {
            Write-Host '     说明：权限仍未生效，请确认已注销并重新登录。' -ForegroundColor Yellow
        }
    }
}

Write-Host ''
Read-Host '按回车键退出'
