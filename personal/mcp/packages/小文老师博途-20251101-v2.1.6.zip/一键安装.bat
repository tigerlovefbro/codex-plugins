@echo off
title XiaowenBotuMCP Setup
if not exist "%~dp0setup.ps1" goto missing
where powershell >nul 2>nul
if errorlevel 1 goto nops
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
set "XWCODE=%ERRORLEVEL%"
pause
exit /b %XWCODE%
:missing
echo [FAIL] Package incomplete - please EXTRACT ALL files first. (Exit code 5)
pause
exit /b 5
:nops
echo [FAIL] PowerShell not found. (Exit code 10)
pause
exit /b 10
