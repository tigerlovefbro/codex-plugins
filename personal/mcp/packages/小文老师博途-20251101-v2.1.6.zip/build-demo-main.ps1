﻿# 演示用 Main 的 5 个网络规格 -> 生成 XML
. "C:\Users\QWH001\Documents\deepseek-harness\default-workspace\tia-mcp\lad-main-generator.ps1"

$spec = @(
    @{
        Title = '电机正反转'
        Comment = '教学示例1：电机正反转控制。M0.0启动/M0.1停止/M0.2反转请求；运行状态输出到M0.3，互锁故障输出到M0.4。'
        Block = '电机正反转'
        Params = @(
            @{ Name='start'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_1'} },
            @{ Name='stop'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_2'} },
            @{ Name='reverseReq'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_3'} },
            @{ Name='running'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_4'} },
            @{ Name='fault'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_5'} }
        )
    },
    @{
        Title = '星三角降压启动'
        Comment = '教学示例2：星三角降压启动。M1.0启动/M1.1停止，星形切换延时5秒；星形/三角形接触器输出到M1.2/M1.3。'
        Block = '星三角降压启动'
        Params = @(
            @{ Name='start'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_6'} },
            @{ Name='stop'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_7'} },
            @{ Name='timeDelay'; Section='Input'; Type='Time'; Operand=@{Kind='TimeLiteral'; Value='t#5s'} },
            @{ Name='star'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_8'} },
            @{ Name='delta'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_9'} }
        )
    },
    @{
        Title = '模拟量滤波'
        Comment = '教学示例3：模拟量滤波。原始模拟量MW10(0..27648)经一阶低通换算为工程值，输出到MD12。'
        Block = '模拟量滤波'
        Params = @(
            @{ Name='raw'; Section='Input'; Type='Int'; Operand=@{Kind='Tag'; Name='Tag_10'} },
            @{ Name='filtered'; Section='Output'; Type='Real'; Operand=@{Kind='Tag'; Name='Tag_11'} }
        )
    },
    @{
        Title = '流水灯'
        Comment = '教学示例4：流水灯控制。M2.0使能，移位周期1秒；8位灯状态输出到MB3。'
        Block = '流水灯'
        Params = @(
            @{ Name='enable'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_12'} },
            @{ Name='period'; Section='Input'; Type='Time'; Operand=@{Kind='TimeLiteral'; Value='t#1s'} },
            @{ Name='pattern'; Section='Output'; Type='Byte'; Operand=@{Kind='Tag'; Name='Tag_13'} }
        )
    },
    @{
        Title = 'Modbus轮询'
        Comment = '教学示例5：Modbus轮询。M4.0触发，从站数3；轮询中/错误输出到M4.1/M4.2，错误码输出到MW6。'
        Block = 'Modbus轮询'
        Params = @(
            @{ Name='trigger'; Section='Input'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_14'} },
            @{ Name='slaveCount'; Section='Input'; Type='Int'; Operand=@{Kind='IntLiteral'; Type='Int'; Value='3'} },
            @{ Name='busy'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_15'} },
            @{ Name='error'; Section='Output'; Type='Bool'; Operand=@{Kind='Tag'; Name='Tag_16'} },
            @{ Name='errorCode'; Section='Output'; Type='Word'; Operand=@{Kind='Tag'; Name='Tag_17'} }
        )
    }
)

New-LadMainXml -Networks $spec -OutFile "C:\Users\QWH001\Documents\deepseek-harness\default-workspace\tia-mcp\lad-main-demo.xml"
