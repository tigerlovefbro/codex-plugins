﻿<#
.SYNOPSIS
    把当前用户加入 "Siemens TIA Openness" 本地组，启用 TIA Portal Openness API。
.DESCRIPTION
    1. 自动请求管理员权限（UAC 弹窗请点“是”）。
    2. 检查 / 创建 "Siemens TIA Openness" 本地组。
    3. 把当前登录用户加入该组（已在组内则跳过）。
    4. 提示注销重新登录 —— 这一步必须做，否则权限不生效。

    加入后，外部程序（PowerShell / C# / Python 等）才能通过 Openness API
    读取和修改 TIA Portal 工程。
.NOTES
    适用于 TIA Portal V13 及以上版本，本机为 V21。
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$GroupName = 'Siemens TIA Openness'

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ---------- 1. 提权 ----------
if (-not (Test-Admin)) {
    Write-Host '需要管理员权限，正在请求提权……（会弹出 UAC 窗口，请点“是”）' -ForegroundColor Yellow
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    return
}

Write-Host '=== 启用 TIA Portal Openness ===' -ForegroundColor Cyan
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$account = $identity.Name
Write-Host "当前用户：$account"

# ---------- 2. 检查组 ----------
$group = Get-LocalGroup -Name $GroupName -ErrorAction SilentlyContinue
if (-not $group) {
    Write-Host "本地组不存在，正在创建：$GroupName"
    New-LocalGroup -Name $GroupName -Description '允许通过 TIA Portal Openness API 访问 TIA Portal 的用户' | Out-Null
    Write-Host '组创建完成。'
}
else {
    Write-Host "本地组已存在：$GroupName"
}

# ---------- 3. 加成员 ----------
$members = @(Get-LocalGroupMember -Group $GroupName -ErrorAction SilentlyContinue)
$already = $members | Where-Object { $_.SID.Value -eq $identity.User.Value }

if ($already) {
    Write-Host "当前用户已在组中，无需重复添加。" -ForegroundColor Green
}
else {
    Write-Host "正在把 $account 加入组 $GroupName ……"
    Add-LocalGroupMember -Group $GroupName -Member $account
    Write-Host '添加完成。' -ForegroundColor Green
}

# ---------- 4. 结果 ----------
$after = @(Get-LocalGroupMember -Group $GroupName -ErrorAction SilentlyContinue)
Write-Host ''
Write-Host "组内成员（$($after.Count) 个）：" -ForegroundColor Cyan
$after | ForEach-Object { Write-Host ("  - {0}" -f $_.Name) }

Write-Host ''
Write-Host '=== 重要：必须注销并重新登录 ===' -ForegroundColor Yellow
Write-Host 'Windows 的用户令牌在登录时构建，改完组不会立刻生效。'
Write-Host '请注销当前 Windows 会话（或重启电脑），重新登录后再打开 TIA Portal。'
Write-Host ''
Write-Host '重新登录后，运行同目录下的 test-tia-openness.ps1 验证是否成功。'
Write-Host ''
Read-Host '按回车键退出'
