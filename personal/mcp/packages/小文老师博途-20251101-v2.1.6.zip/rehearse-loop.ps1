﻿# ============================================================
# rehearse-loop.ps1 - 连续彩排 N 轮
# 每轮: 关博途 -> 删工程 -> 跑 demo-go.ps1 -> 核对6个步骤 -> 记录结果
# 结果写: %TEMP%\rehearsal-results.log
# ============================================================
param([int]$Cycles = 10)
$PKG = 'C:\Users\QWH001\Documents\deepseek-harness\default-workspace\tia-mcp'
$RESULT = Join-Path $env:TEMP 'rehearsal-results.log'
$ErrorActionPreference = 'Continue'

"===== 连续彩排 $Cycles 轮, 开始 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') =====" | Tee-Object -FilePath $RESULT

for ($i = 1; $i -le $Cycles; $i++) {
    $cycleStart = Get-Date

    # ---------- 1. 清场: 干净退出博途 + 删工程 ----------
    $tiaProcs = Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue
    foreach ($tp in $tiaProcs) { [void]$tp.CloseMainWindow() }
    $waited = 0
    while ((Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue) -and $waited -lt 30) {
        Start-Sleep -Seconds 3; $waited += 3
    }
    $leftover = Get-Process -Name 'Siemens.Automation.Portal' -ErrorAction SilentlyContinue
    if ($leftover) { foreach ($tp in $leftover) { Stop-Process -Id $tp.Id -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 3 }
    if (Test-Path 'C:\Users\QWH001\Desktop\Demo_AI_Show') {
        Remove-Item 'C:\Users\QWH001\Desktop\Demo_AI_Show' -Recurse -Force -ErrorAction SilentlyContinue
    }

    # ---------- 2. 跑演示 ----------
    $demoLog = Join-Path $env:TEMP ("demo-go-cycle{0}.log" -f $i)
    $demoErr = Join-Path $env:TEMP ("demo-go-cycle{0}.err" -f $i)
    $proc = Start-Process -FilePath 'powershell.exe' `
        -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PKG 'demo-go.ps1')) `
        -PassThru -WindowStyle Hidden `
        -RedirectStandardOutput $demoLog -RedirectStandardError $demoErr

    $done = $proc.WaitForExit(300000)   # 单轮最多 5 分钟
    if (-not $done) {
        Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
        $summary = "第 $i 轮: 超时(>300s), 已强杀"
    } else {
        $logContent = Get-Content $demoLog -Raw -ErrorAction SilentlyContinue
        $steps = @('1/6 博途已连接','2/6 工程已创建','3/6 CPU','4/6 5 个教学 FC','5/6 标签就绪','6/6 LAD Main 导入成功')
        $missing = @()
        foreach ($s in $steps) {
            if ($logContent -notmatch [regex]::Escape($s)) { $missing += $s }
        }
        $summary = if ($missing.Count -eq 0) { "第 $i 轮: 全部通过" } else { "第 $i 轮: 缺步骤 -> $($missing -join ' | ')" }
    }
    $elapsed = [Math]::Round(((Get-Date) - $cycleStart).TotalSeconds, 0)
    "$summary | 用时 ${elapsed}s" | Tee-Object -FilePath $RESULT -Append
}

"===== 彩排结束 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') =====" | Tee-Object -FilePath $RESULT -Append
