﻿# ============================================================
# selfcheck.ps1 - 小文老师博途MCP 一键自检 (防闪退加固版)
# Checks: 1) Node.js  2) MCP handshake & tool list  3) TIA attach
# Run by double-clicking selfcheck.cmd
# -SkipAttach: 跳过第3步(用于刚加完组、尚未注销重登的场景)
# 防闪退: 全程 try/catch + 转录日志, 出错也不闪退
# ============================================================
param([switch]$SkipAttach)
$ErrorActionPreference = 'Stop'
try { cmd /c "chcp 65001" | Out-Null } catch {}

# 转录日志(排查闪退用): %TEMP%\xiaowen-mcp-selfcheck.log
$logPath = Join-Path $env:TEMP 'xiaowen-mcp-selfcheck.log'
try { Start-Transcript -Path $logPath -Force -ErrorAction SilentlyContinue | Out-Null } catch {}

try {
    # 固定 UTF-8 输出, 避免中文乱码(受限环境失败也不致命)
    try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
    try { $OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

    Write-Host ''
    Write-Host '===== 小文老师博途MCP 插件自检 =====' -ForegroundColor Cyan

    $node = (Get-Command node -ErrorAction SilentlyContinue).Source
    if (-not $node) {
        $dshNode = Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'
        if (Test-Path $dshNode) { $node = $dshNode }
    }
    if (-not $node) {
        Write-Host '[1/3] Node.js: 未安装!' -ForegroundColor Red
        Write-Host '请先到 https://nodejs.org 安装 LTS 版本，装完重新双击本脚本。'
        Read-Host '按回车退出'
        exit 1
    }
    Write-Host "[1/3] Node.js: 找到 ($node)" -ForegroundColor Green

    # ---------- 环境门禁: 系统/TIA版本/权限 检查 ----------
    function Show-Popup2([string]$title, [string]$text) {
        try {
            $ws = New-Object -ComObject WScript.Shell
            [void]$ws.Popup($text, 0, $title, 48)
        } catch {
            try {
                Add-Type -AssemblyName System.Windows.Forms
                [void][System.Windows.Forms.MessageBox]::Show($text, $title, 'OK', 'Warning')
            } catch { }
        }
    }
    function Find-Tia2 {
        foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
            if (-not $root) { continue }
            foreach ($v in @(21, 20, 19, 18, 17)) {
                $portal = Join-Path $root "Siemens\Automation\Portal V$v"
                if (-not (Test-Path $portal)) { continue }
                $apiRoot = Join-Path $portal 'PublicAPI'
                if (Test-Path $apiRoot) {
                    foreach ($sub in @(Get-ChildItem $apiRoot -Directory -ErrorAction SilentlyContinue)) {
                        $net48 = Join-Path $sub.FullName 'net48'
                        if (Test-Path (Join-Path $net48 'Siemens.Engineering.Base.dll')) {
                            $pub = Join-Path $portal 'Bin\PublicAPI'
                            if ((Test-Path (Join-Path $pub 'Siemens.Engineering.Contract.dll'))) { return @{ dir = $net48; pub = $pub; version = "V$v" } }
                        }
                    }
                }
            }
        }
        return $null
    }
    $gateFails = @()
    $gateCode = 2
    try { if ([System.Environment]::OSVersion.Version.Major -lt 10) { $gateFails += '操作系统过旧: 需要 Windows 10/11' } } catch {}
    $tia2 = Find-Tia2
    if (-not $tia2) {
        $gateFails += '未找到 TIA Portal V21 的 Openness 组件'
    } elseif ($tia2.version -ne 'V21') {
        $gateFails += "检测到 TIA Portal $($tia2.version), 本工具仅支持 V21。请升级到 TIA Portal V21 后重跑。"
        $gateCode = 6
    } else {
        Write-Host "      TIA 检测: $($tia2.version) Openness OK" -ForegroundColor Green
    }
    $grp2 = Get-LocalGroup -Name 'Siemens TIA Openness' -ErrorAction SilentlyContinue
    if (-not $grp2) { $gateFails += 'Openness 权限组不存在: 运行 enable-tia-openness.ps1' }
    if ($gateFails.Count -gt 0) {
        Write-Host ''
        Write-Host '[环境检查] 不通过:' -ForegroundColor Red
        foreach ($g in $gateFails) { Write-Host "  - $g" -ForegroundColor Yellow }
        Show-Popup2 '小文老师博途MCP - 环境检查' ("环境检查不通过:`n`n" + (($gateFails | ForEach-Object { "· $_" }) -join "`n") + "`n`n修复后重新运行自检。")
        Write-Host ''
        Write-Host "[退出代码 $gateCode] 环境检查不通过。" -ForegroundColor Red
        Read-Host '按回车退出'
        exit $gateCode
    }

    $server = Join-Path $PSScriptRoot 'server.js'
    if (-not (Test-Path $server)) {
        Write-Host '[2/3] server.js: 找不到, 请把压缩包"全部解压"到文件夹后再运行(不要在压缩包内双击)。' -ForegroundColor Red
        Write-Host '[退出代码 5] 包文件不完整(请先全部解压)。' -ForegroundColor Red
        Read-Host '按回车退出'
        exit 5
    }

    $msgs = @(
        '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"selfcheck","version":"1.0"}}}',
        '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'
    )
    if (-not $SkipAttach) {
        $msgs += '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"tia_status","arguments":{}}}'
    }

    Write-Host '[2/3] MCP 协议层...'
    if ($SkipAttach) {
        Write-Host '[3/3] 已跳过(权限需注销重登后生效, 稍后重跑本自检即可)' -ForegroundColor Yellow
    } else {
        Write-Host '[3/3] 连接博途（若弹出 Openness 访问 对话框，请点 是）...'
    }
    $out = $msgs -join "`n" | & $node $server 2>$null

    foreach ($line in $out) {
        if ($line -notmatch '^\{') { continue }
        try {
            $o = $line | ConvertFrom-Json
            if ($o.id -eq 1 -and $o.result.serverInfo) {
                Write-Host ("[2/3] 服务器握手 OK: {0} v{1}" -f $o.result.serverInfo.name, $o.result.serverInfo.version) -ForegroundColor Green
            }
            elseif ($o.id -eq 2) {
                $names = ($o.result.tools | ForEach-Object { $_.name }) -join ', '
                Write-Host "[2/3] 工具注册 OK ($($o.result.tools.Count) 个): $names" -ForegroundColor Green
            }
            elseif ($o.id -eq 3) {
                $txt = $o.result.content[0].text
                if ($o.result.isError) {
                    Write-Host "[3/3] 连接博途失败: $txt" -ForegroundColor Red
                    $script:attachFailed = $true
                    $script:attachError = $txt
                } else {
                    Write-Host "[3/3] 连接博途 OK" -ForegroundColor Green
                }
            }
        } catch {}
    }

    # 第3步失败时自动出诊断报告
    if ($script:attachFailed) {
        Write-Host ''
        Write-Host '----- 自动诊断 -----' -ForegroundColor Cyan
        $grp = Get-LocalGroup -Name 'Siemens TIA Openness' -ErrorAction SilentlyContinue
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        if (-not $grp) {
            Write-Host '[诊断] 本地组不存在!' -ForegroundColor Red
            Write-Host '  -> 修复: 右键 enable-tia-openness.ps1 -> 使用 PowerShell 运行, UAC 点 是。'
        } else {
            Write-Host '[诊断] 组存在。' -ForegroundColor Green
            $members = @(Get-LocalGroupMember -Group 'Siemens TIA Openness' -ErrorAction SilentlyContinue)
            Write-Host ("[诊断] 组内成员 {0} 个: {1}" -f $members.Count, (($members | ForEach-Object { $_.Name }) -join ', '))
            $inGroup = [bool]($members | Where-Object { $_.SID.Value -eq $id.User.Value })
            $inToken = [bool]($id.Groups | Where-Object { $_.Value -eq $grp.SID.Value })
            if (-not $inGroup) {
                Write-Host '[诊断] 当前用户不在组内!' -ForegroundColor Red
                Write-Host '  -> 修复: 右键 enable-tia-openness.ps1 -> 使用 PowerShell 运行, UAC 点 是 (上次大概率没点)。'
            } elseif (-not $inToken) {
                Write-Host '[诊断] 已在组内, 但登录令牌未刷新。' -ForegroundColor Yellow
                Write-Host '  -> 修复: 注销并重新登录 Windows, 然后重跑本自检。'
            } else {
                Write-Host '[诊断] 组权限正常, 失败另有原因(见上面错误原文)。' -ForegroundColor Yellow
                Write-Host '  -> 常见: 博途崩溃重启后 Openness 失联, 关掉博途重新打开再试。'
            }
        }
    }

    Write-Host ''
    Write-Host '----- 自检结果说明 -----'
    if ($SkipAttach) {
        Write-Host '第 3 步已跳过: 请注销并重新登录 Windows, 然后重新双击 一键安装.bat 完整自检。'
        Write-Host '[退出代码 0] 基础项通过(连接测试已跳过)。' -ForegroundColor Green
    } elseif ($script:attachFailed) {
        Write-Host '第 3 步(连接博途)失败: 检查 1) 博途已安装且已授权 2) 已运行 enable-tia-openness.ps1 并注销重登 3) 弹窗时点了 是。'
        Write-Host '[退出代码 3] 连接博途失败。' -ForegroundColor Red
        Read-Host '按回车退出'
        exit 3
    } else {
        Write-Host '全部 OK: 可以去配置 AI 客户端了（见 README.md）。'
        Write-Host '[退出代码 0] 全部通过。' -ForegroundColor Green
    }
    Write-Host ''
    Write-Host "诊断日志: $logPath" -ForegroundColor DarkGray
    Read-Host '按回车退出'
    exit 0
}
catch {
    Write-Host ''
    Write-Host "===== 自检异常退出(错误已记录) =====" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host ''
    Write-Host "请把日志文件发给小文老师排查: $logPath" -ForegroundColor Cyan
    Write-Host '常见原因: 1) 压缩包未完整解压(请先"全部解压"再运行) 2) 公司策略限制 PowerShell'
    Write-Host '[退出代码 9] 未知异常。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 9
}
finally {
    try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch {}
}
