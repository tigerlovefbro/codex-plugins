#!/usr/bin/env node
// ============================================================
// server.js - Minimal MCP (Model Context Protocol) server for
// TIA Portal Openness. Zero npm dependencies.
//
// Architecture:
//   MCP client  <--stdio JSON-RPC-->  server.js  <--stdio-->  tia-service.ps1  -->  TIA Portal
//
// Supported tools: tia_status, project_open, project_create,
//                  project_save, device_add, blocks_list,
//                  block_delete, fc_create
// ============================================================
'use strict';

const { spawn } = require('child_process');
const readline = require('readline');
const path = require('path');

const SERVER_NAME = '小文老师博途MCP';
const SERVER_VERSION = '2.1.6';
const WORKER_SCRIPT = path.join(__dirname, 'tia-service.ps1');

// ---------------- worker (persistent PowerShell process) ----------------
function startWorker() {
  const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', WORKER_SCRIPT], {
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
  });

  let seq = 0;
  const pending = new Map();
  const rl = readline.createInterface({ input: p.stdout });
  rl.on('line', (line) => {
    let msg;
    try { msg = JSON.parse(line); } catch (e) { return; }
    const cb = pending.get(msg.id);
    if (cb) { pending.delete(msg.id); cb(msg); }
  });
  p.stderr.on('data', (d) => process.stderr.write('[tia-worker] ' + d.toString()));
  p.on('exit', (code) => {
    process.stderr.write(`[tia-worker] exited with code ${code}\n`);
    for (const cb of pending.values()) {
      cb({ jsonrpc: '2.0', id: null, error: { code: -32000, message: 'TIA worker process exited' } });
    }
    pending.clear();
  });

  return {
    call(method, params) {
      return new Promise((resolve, reject) => {
        const id = ++seq;
        pending.set(id, (msg) => {
          if (msg.error) reject(new Error(msg.error.message || JSON.stringify(msg.error)));
          else resolve(msg.result);
        });
        p.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params: params || {} }) + '\n');
      });
    },
    kill() { try { p.kill(); } catch (e) {} },
  };
}

let worker = null;
function getWorker() {
  if (!worker) worker = startWorker();
  return worker;
}

// ---------------- tool definitions ----------------
const tools = [
  {
    name: 'tia_status',
    description: '检查 TIA Portal 连接状态。若博途未运行会自动拉起；首次连接可能弹出 Openness 访问确认框，请点“是”。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'project_open',
    description: '打开一个 TIA Portal 工程。参数 path 为 .ap21 文件路径或工程文件夹路径。注意：一个博途界面实例同时只能打开一个工程。',
    inputSchema: {
      type: 'object',
      properties: { path: { type: 'string', description: '.ap21 文件路径或工程文件夹路径' } },
      required: ['path'],
    },
  },
  {
    name: 'project_create',
    description: '新建 TIA Portal 工程。参数 name 为工程名，path 为存放目录（默认桌面）。创建后自动在博途中打开。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '工程名' },
        path: { type: 'string', description: '存放目录，例如 C:\\Users\\xx\\Desktop' },
      },
      required: ['name'],
    },
  },
  {
    name: 'project_save',
    description: '保存当前打开的工程。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'device_add',
    description: '向当前工程添加 S7-1500 设备（站+CPU）。参数：name 设备名、orderNumber 订货号、version 固件版本（如 V4.1）。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '设备名，例如 PLC_1' },
        orderNumber: { type: 'string', description: 'CPU 订货号，例如 6ES7 511-1AL03-0AB0' },
        version: { type: 'string', description: '固件版本，例如 V4.1' },
      },
      required: ['name', 'orderNumber', 'version'],
    },
  },
  {
    name: 'blocks_list',
    description: '列出当前工程 PLC_1 下所有程序块（名称、编号、语言、一致性）。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'block_delete',
    description: '删除指定名称的程序块。',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: '块名称' } },
      required: ['name'],
    },
  },
  {
    name: 'fc_create',
    description: '在 PLC_1 下新建一个 SCL 语言的功能块（FC）。参数 name 为块名，body 为 SCL 语句体（不含 FUNCTION 声明头）。内部通过“外部源文件生成”实现（V21 Openness 无 CreateFC）。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'FC 名称，例如 电机正反转' },
        body: { type: 'string', description: 'SCL 语句体，例如 "    // 注释\\n    ;"' },
      },
      required: ['name'],
    },
  },
  {
    name: 'tags_list',
    description: '列出默认变量表中的全部 PLC 标签（名称、数据类型、地址）。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'tags_create',
    description: '批量创建 PLC 标签。参数 tags 为数组，每项 {name, type, address}，例如 {name:"Tag_1", type:"Bool", address:"%M0.0"}。已存在的同名标签自动跳过。',
    inputSchema: {
      type: 'object',
      properties: {
        tags: {
          type: 'array',
          description: '标签列表',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              type: { type: 'string', description: '数据类型，如 Bool/Int/Real/Byte/Word' },
              address: { type: 'string', description: '地址，如 %M0.0 / %MW10 / %MD12' },
            },
            required: ['name', 'type', 'address'],
          },
        },
      },
      required: ['tags'],
    },
  },
  {
    name: 'lad_main_import',
    description: '生成 LAD 版 Main(OB1) 并导入：每个网络调用一个 FC，全部形参自动挂上实参（标签/常量），网络标题和注释一并写入。参数 networks 为数组，每项 {title, comment, block, params:[{name, section:"Input|Output", type, operand}]}。operand 支持三种: {kind:"Tag", name, dataType, address}（标签不存在会自动创建）、{kind:"IntLiteral", constantType, value}、{kind:"TimeLiteral", value:"t#5s"}。注意：导入时 Main 若正在编辑器里打开会挂起，请先关闭块编辑器；导入后需人工编译一次。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'OB 名称，默认 Main' },
        number: { type: 'integer', description: 'OB 编号，默认 1' },
        networks: {
          type: 'array',
          description: '网络规格列表',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              comment: { type: 'string' },
              block: { type: 'string', description: '被调用的 FC 名称' },
              params: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    name: { type: 'string', description: '形参名' },
                    section: { type: 'string', enum: ['Input', 'Output'] },
                    type: { type: 'string', description: '数据类型' },
                    operand: { type: 'object', description: '实参规格' },
                  },
                  required: ['name', 'section', 'type', 'operand'],
                },
              },
            },
            required: ['title', 'comment', 'block', 'params'],
          },
        },
      },
      required: ['networks'],
    },
  },
  {
    name: 'tia_diagnose',
    description: '一键体检：检查 Openness 组是否存在、当前用户是否在组内、登录令牌是否已刷新（注销重登过）、博途是否在运行，并给出对应的修复动作建议。纯本地检查，不需要连接博途。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'block_export',
    description: '导出指定块到 XML 文件（导出前块必须已编译一致）。path 为输出文件路径。可用来备份块或提取 LAD 格式模板。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '块名称' },
        path: { type: 'string', description: '输出 .xml 文件路径' },
      },
      required: ['name', 'path'],
    },
  },
  {
    name: 'project_list',
    description: '列出博途中当前打开的全部工程。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'project_close',
    description: '关闭指定工程（按名称）。注意：一个博途界面实例同时只能打开一个工程，切换工程前先关闭。',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: '工程名' } },
      required: ['name'],
    },
  },
  {
    name: 'device_list',
    description: '列出当前工程的所有设备及子项（订货号、版本）。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'catalog_search',
    description: '搜索博途硬件目录。参数 query 为关键字（如订货号 6ES7 511-1AL03-0AB0 或名称 1214C）。返回前 20 条匹配的 TypeIdentifier/名称/版本，便于确认 device_add 的参数。',
    inputSchema: {
      type: 'object',
      properties: { query: { type: 'string' } },
      required: ['query'],
    },
  },
  {
    name: 'fb_create',
    description: '新建一个 SCL 语言的功能块（FB），支持接口定义。参数：name 块名；inputs/outputs/statics 为 {name,type} 数组；body 为 SCL 语句体（不含 FUNCTION_BLOCK 声明头）。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        inputs: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, type: { type: 'string' } }, required: ['name', 'type'] } },
        outputs: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, type: { type: 'string' } }, required: ['name', 'type'] } },
        statics: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, type: { type: 'string' } }, required: ['name', 'type'] } },
        body: { type: 'string', description: 'SCL 语句体' },
      },
      required: ['name'],
    },
  },
  {
    name: 'scl_import',
    description: '导入任意完整 SCL 源文件内容并生成其中声明的所有块（可一次声明多个 FUNCTION/FUNCTION_BLOCK/ORGANIZATION_BLOCK）。参数 name 为源文件名，scl 为完整源码文本。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '外部源名称' },
        scl: { type: 'string', description: '完整 SCL 源码文本' },
      },
      required: ['name', 'scl'],
    },
  },
  {
    name: 'compile_status',
    description: '查看/轮询编译一致性状态：列出每个块的 consistent 状态，返回未编译一致的块清单。参数 waitSeconds 可指定轮询秒数（每 5 秒查一次，直到全部一致或超时）。注意：编译动作本身必须在博途中人工执行（右键 PLC_1 → 编译 → 软件(全部编译)），本工具只负责查看/等待状态。',
    inputSchema: {
      type: 'object',
      properties: { waitSeconds: { type: 'integer', description: '轮询等待秒数，默认 0（只查一次）' } },
      required: [],
    },
  },
  {
    name: 'block_rename',
    description: '批量重命名程序块。参数 renames 为数组 [{from, to}]。源块不存在或目标名已被占用时逐项返回错误。',
    inputSchema: {
      type: 'object',
      properties: {
        renames: {
          type: 'array',
          items: {
            type: 'object',
            properties: { from: { type: 'string' }, to: { type: 'string' } },
            required: ['from', 'to'],
          },
        },
      },
      required: ['renames'],
    },
  },
  {
    name: 'tags_import',
    description: '批量导入 PLC 标签（变量表），支持注释。参数 tags 为数组 [{name, type, address, comment?}]。同名标签自动跳过；comment 写入标签注释。',
    inputSchema: {
      type: 'object',
      properties: {
        tags: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              type: { type: 'string', description: '如 Bool/Int/Real/Byte/Word' },
              address: { type: 'string', description: '如 %M0.0/%MW10/%MD12' },
              comment: { type: 'string', description: '标签注释（可选）' },
            },
            required: ['name', 'type', 'address'],
          },
        },
      },
      required: ['tags'],
    },
  },
  {
    name: 'db_fb_create',
    description: '按堆垛机本地任务数据库范式(增删查改四件套)生成完整 FB：CASE 步进状态机、Cmd/Done/Err 握手、16# 错误码分段、255 库位产品信息数组、权限校验、备份/日志接入点。生成后需在博途中人工编译一次。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'FB 名称，默认 Winsynth_Database' },
        slotCount: { type: 'integer', description: '库位数量，默认 255' },
      },
      required: [],
    },
  },
  {
    name: 'password_scan',
    description: '扫描工程中明文存储的密码/口令：检查所有块的标题、注释里是否出现 password/pwd/密码 等字样后跟明文值。返回命中清单，供安全整改。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'udt_create',
    description: '创建 PLC 数据类型（UDT）。参数 name 为类型名，members 为 [{name,type}] 成员数组。同名类型自动跳过。',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'UDT 名称' },
        members: {
          type: 'array',
          items: {
            type: 'object',
            properties: { name: { type: 'string' }, type: { type: 'string', description: '如 Bool/Int/Real/Array[0..29] of Char' } },
            required: ['name', 'type'],
          },
        },
      },
      required: ['name', 'members'],
    },
  },
  {
    name: 'stacker_db_deploy',
    description: '一键部署堆垛机本地任务数据库（工业完整版）：自动创建 3 个 UDT（DataBaseConv/Record/Jurssd）+ 完整 Winsynth_Database FB（增删查改清五命令 + 30位产品信息协议 + 双棒配对 + 三级权限 + 审计日志 + 载存备份）+ 备份区 DB。参数 name 可自定义 FB 名。部署后需人工编译一次，Main 调用可用 lad_main_import 生成。',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: 'FB 名称，默认 Winsynth_Database' } },
      required: [],
    },
  },
  {
    name: 'stacker_db_homework',
    description: '部署堆垛机数据库【作业版】：3 个 UDT + 留白版 FB（非核心业务和 AddData 已完整实现，DelData/ReadData/UpData 是空壳留给学员补全）+ 备份区 DB。返回作业要求清单。学员完成后用 homework_check 检查。',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: 'FB 名称，默认 Winsynth_Database' } },
      required: [],
    },
  },
  {
    name: 'homework_check',
    description: '批改堆垛机数据库作业：检查 DelData/ReadData/UpData 是否实现、三个结构体是否补齐 Step/num/num1/Locking/Temp 五字段、仲裁链是否挂全、步骤注释是否齐全、错误码是否分段使用。只报错不给标准答案。',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: 'FB 名称，默认 Winsynth_Database' } },
      required: [],
    },
  },
  {
    name: 'xiaowen_templates',
    description: '列出小文老师可一键部署的模板清单（数据库/数据库作业版/水泥厂/RTU/EPOS）。用户问"能部署什么/有哪些模板"时调用。',
    inputSchema: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'xiaowen_deploy',
    description: '【核心工具】一键部署小文老师的工程模板。当用户说"部署小文老师的数据库/部署数据库"→ template=数据库；"部署数据库作业/作业版"→ template=数据库作业版；"部署水泥厂"→ template=水泥厂；"部署RTU/Modbus轮询"→ template=RTU；"部署EPOS/定位"→ template=EPOS。自动建CPU+导入UDT+导入全部程序块+保存。部署后提醒用户人工编译一次。',
    inputSchema: {
      type: 'object',
      properties: { template: { type: 'string', description: '模板名: 数据库 / 数据库作业版 / 水泥厂 / RTU / EPOS' } },
      required: ['template'],
    },
  },
];

const METHOD_MAP = {
  tia_status: 'status',
  project_open: 'project_open',
  project_create: 'project_create',
  project_save: 'project_save',
  device_add: 'device_add',
  blocks_list: 'blocks_list',
  block_delete: 'block_delete',
  fc_create: 'fc_create',
  tags_list: 'tags_list',
  tags_create: 'tags_create',
  lad_main_import: 'lad_main_import',
  block_export: 'block_export',
  project_list: 'project_list',
  project_close: 'project_close',
  device_list: 'device_list',
  catalog_search: 'catalog_search',
  fb_create: 'fb_create',
  scl_import: 'scl_import',
  tia_diagnose: 'diagnose',
  compile_status: 'compile_status',
  block_rename: 'block_rename',
  tags_import: 'tags_import',
  db_fb_create: 'db_fb_create',
  password_scan: 'password_scan',
  udt_create: 'udt_create',
  stacker_db_deploy: 'stacker_db_deploy',
  stacker_db_homework: 'stacker_db_homework',
  homework_check: 'homework_check',
  xiaowen_templates: 'xiaowen_templates',
  xiaowen_deploy: 'xiaowen_deploy',
};

// ---------------- MCP stdio loop ----------------
function send(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

async function handleToolCall(id, params) {
  const name = params && params.name;
  const args = (params && params.arguments) || {};
  if (!name || !METHOD_MAP[name]) {
    send({ jsonrpc: '2.0', id, error: { code: -32602, message: `unknown tool: ${name}` } });
    return;
  }
  pendingCalls++;
  try {
    const result = await getWorker().call(METHOD_MAP[name], args);
    send({
      jsonrpc: '2.0',
      id,
      result: { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] },
    });
  } catch (e) {
    send({
      jsonrpc: '2.0',
      id,
      result: { content: [{ type: 'text', text: '错误: ' + e.message }], isError: true },
    });
  } finally {
    pendingCalls--;
    maybeExit();
  }
}

const stdin = readline.createInterface({ input: process.stdin, terminal: false });
stdin.on('line', (line) => {
  let msg;
  try { msg = JSON.parse(line); } catch (e) { return; }
  const { id, method, params } = msg;

  if (method === 'initialize') {
    send({
      jsonrpc: '2.0',
      id,
      result: {
        protocolVersion: (params && params.protocolVersion) || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
      },
    });
  } else if (method === 'notifications/initialized') {
    // no response
  } else if (method === 'ping') {
    send({ jsonrpc: '2.0', id, result: {} });
  } else if (method === 'tools/list') {
    send({ jsonrpc: '2.0', id, result: { tools } });
  } else if (method === 'tools/call') {
    handleToolCall(id, params);
  } else {
    send({ jsonrpc: '2.0', id, error: { code: -32601, message: `unknown method: ${method}` } });
  }
});

// Track in-flight tool calls so a closing stdin waits for them before exit.
let pendingCalls = 0;
let stdinClosed = false;
function maybeExit() {
  if (stdinClosed && pendingCalls === 0) {
    if (worker) worker.kill();
    process.exit(0);
  }
}

stdin.on('close', () => {
  stdinClosed = true;
  maybeExit();
  // Safety net: never hang forever waiting for a stuck TIA call.
  setTimeout(() => { if (worker) worker.kill(); process.exit(0); }, 180000);
});

process.on('SIGINT', () => { if (worker) worker.kill(); process.exit(0); });
process.on('exit', () => { if (worker) worker.kill(); });
