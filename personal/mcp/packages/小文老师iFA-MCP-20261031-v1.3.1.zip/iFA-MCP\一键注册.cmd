@echo off
rem ============================================================
rem  One-click register iFA Evolution MCP:
rem   1) DeepSeek Harness  (cordis.patch.yml)
rem   2) Claude Desktop    (claude_desktop_config.json)
rem  Idempotent: safe to run multiple times.
rem ============================================================
setlocal
set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"
set "IFA_DIR=%DIR%"
set "PATCH=%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml"

echo ============================================
echo  [1/2] DeepSeek Harness
if not exist "%PATCH%" (
    echo  [SKIP] not found: %PATCH%
    echo         Install DeepSeek Harness and launch it once, then rerun.
) else (
    findstr /C:"mcp-ifa-evolution" "%PATCH%" >nul 2>nul
    if not errorlevel 1 (
        echo  [OK]   ifa-evolution already registered.
    ) else (
        >>"%PATCH%" (
            echo.
            echo - insert:
            echo     - id: mcp-ifa-evolution
            echo       name: "@deepseek-ai/dsh-mcp-client"
            echo       config:
            echo         transport: stdio
            echo         serverName: ifa-evolution
            echo         command: cmd
            echo         args:
            echo           - /c
            echo           - '%DIR%\start.cmd'
            echo           - --server
            echo         toolCallTimeoutMs: 900000
        )
        echo  [DONE] registered. Restart DeepSeek Harness to take effect.
    )
)

echo ============================================
echo  [2/2] Claude Desktop
powershell -NoProfile -ExecutionPolicy Bypass -Command "$cfg=\"$env:APPDATA\Claude\claude_desktop_config.json\"; if (Test-Path $cfg) { $t=[IO.File]::ReadAllText($cfg); if ($t -notmatch \"ifa-evolution\") { try { $j=$t|ConvertFrom-Json; if (-not $j.mcpServers) { $j|Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) -Force }; $j.mcpServers|Add-Member -NotePropertyName \"ifa-evolution\" -NotePropertyValue ([pscustomobject]@{command=\"cmd\";args=@(\"/c\",($env:IFA_DIR+\"\\start.cmd\"),\"--server\")}) -Force; [IO.File]::WriteAllText($cfg,($j|ConvertTo-Json -Depth 10),(New-Object Text.UTF8Encoding($false))); Write-Host \"  [DONE] registered. Restart Claude Desktop.\" } catch { Write-Host \"  [WARN] config parse failed, merge manually (see config-examples).\" } } else { Write-Host \"  [OK]   ifa-evolution already registered.\" } } else { Write-Host \"  [SKIP] Claude Desktop config not found (ok if not installed).\" }"

echo ============================================
echo  Done. Restart your AI client, then just tell your AI:
echo    "Prepare to start iFA" (Chinese: prepare-to-start-IFA)
echo.
pause
exit /b 0
