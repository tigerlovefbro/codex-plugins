# 小文老师 iFA Evolution MCP v1.1.0

通过 **iFA Evolution 官方 gRPC Open API** 操作 iFA Evolution（Inovance FA/HMI/PLC 编程软件）的 MCP 服务器。AI（DeepSeek Harness / Claude Desktop / Cursor 等）装上它就能直接写 PLC 程序：建设备、写 ST 程序、导功能块、编译、查诊断。

> 已在真实工程上验证：创建 PLC 设备 → 写冒泡排序 → 导入气缸 FB（DUT + 状态机）→ 编译 0 错误 0 警告。

## 一、给新电脑安装（3 步）

### 1. 解压
把整个 `iFA-MCP` 文件夹放到 **`C:\ifa-mcp`**（放别处要同步改注册命令里的路径）。
本包自带嵌入式 Python 3.12，**不需要**另装 Python。

### 2. 环境自检
双击运行 `C:\ifa-mcp\启动.cmd`（不带参数 = 自检模式）。确认目标路径后关闭。

### 3. 注册到 AI 客户端：双击 `一键注册.cmd`

**什么都不用手动改。** 双击包内 **`一键注册.cmd`**，它自动完成：

- **DeepSeek Harness**：把配置追加到 `cordis.patch.yml`；
- **Claude Desktop**：把配置合并进 `claude_desktop_config.json`；
- 没装的客户端自动跳过；重复运行不会重复添加（幂等）。

然后**重启对应的 AI 客户端**即可。

> 想手动加的也可以：参考 `config-examples\` 里的两个示例文件。
> （注册脚本统一引用包内 `start.cmd`，避免中文文件名在个别系统代码页下出乱码；
> `启动.cmd` 保留，双击自检时用。）

**Claude Desktop**：`claude_desktop_config.json` 的 `mcpServers` 加：

```json
"ifa-evolution": { "command": "cmd", "args": ["/c", "C:\\ifa-mcp\\启动.cmd", "--server"] }
```

完整示例见 `config-examples\claude_desktop_config.json`。

## 二、第一次使用（只需说一句话）

重启客户端后，对 AI 说：

> **“准备开始IFA”**

AI 会自动执行 `ifa_prepare`：一次性开启扩展服务（备份原配置）→ 重启 IDE → 健康检查，
然后告诉你是否就绪。之后直接说需求即可：

- “打开工程 XX，写个冒泡排序，编译并告诉我结果”
- “导一个气缸 FB，在 Main 里实例化调用，编译通过后保存”

## 三、工具清单（20 个）

| 工具 | 说明 |
|---|---|
| `ifa_prepare` | 说「准备开始IFA」自动触发：一次性配置 + 重启 IDE + 健康检查 |
| `ifa_setup` | 一次性：开启 OpenAPI 扩展 + 重启 IDE（新电脑先跑） |
| `ifa_feedback` | 说「生成反馈」触发：读取最近操作日志（含错误），发给作者排查 |
| `ifa_health` | IDE / API / 工程状态 |
| `ifa_restart` | 重启 IDE 并重连 |
| `ifa_project_open` / `ifa_project_save` / `ifa_project_close` | 打开/保存/关闭工程（.fasln） |
| `ifa_project_create` | 新建标准工程 |
| `ifa_device_list` | 工程设备列表 |
| `ifa_compile` / `ifa_messages` | 编译 / 编译诊断（自动把设备名解析成 GUID） |
| `ifa_logic_tree` | PLC 逻辑设备与节点树 |
| `ifa_logic_read_xml` / `ifa_logic_write_xml` | 读写节点 PLCopen XML |
| `ifa_logic_read_doc` / `ifa_logic_write_doc` | 读写节点文档文本 |
| `ifa_view_tree` | HMI 视图树 |
| `ifa_call` | **万能调用**：任意 service/method，请求体按字段号 JSON |
| `ifa_schema` | 查服务/消息/枚举元数据（13 服务、255 方法、201 消息） |

资源：`ifa://inventory`（API 清单）、`ifa://schema`（消息布局）。

## 四、关键经验（写程序必读）

1. **编译要传设备 GUID**：`Compile`/`GetCompileInfo` 的 deviceId 是设备 GUID；`ifa_compile` 已自动转换，裸调 `ifa_call` 时先 `GetLogicDeviceIdByName` 换 GUID。
2. **建 POU**：`CreateSTPOUByName` 只认 `pouType="program"`；**FB/DUT 用 `ImportObjectByText`**（完整文本：`TYPE…END_TYPE`、`FUNCTION_BLOCK…`，一次可传多个）。
   ⚠️ `ImportObjectByText` 是**替换式**导入（会重建“编程”文件夹），导入后需重建任务引用（`DeleteTask`+`CreateTask` 挂回 Main）。
3. **程序体文本**：`ReplaceStPOU` 的 stText 只写**语句体**；声明放 XML 的 `<localVars>/<inputVars>/<outputVars>`。数组字面量 `arr := [..]` 不支持，用逐元素赋值。
4. **XML 是万能通道**：`GetNodeItemXml`/`UploadNodeItemXmlInfo`（PLCopen tc6_0201）可改任何 POU/DUT。
5. 网络服务占用 9001 不用管——端口发现会校验 Project 服务响应，自动跳过假端口。

## 五、目录结构

```
C:\ifa-mcp\
  启动.cmd           启动器（--server 进 MCP 模式；双击自检）
  mcp_server.py      MCP 服务器（纯 Python，stdio JSON-RPC）
  schema_dump.json   API 元数据（逆向自 iFA 程序集）
  protos\            gRPC 消息描述符
  runtime_pkgs\      grpcio / protobuf 运行库
  runtime\python\    嵌入式 Python 3.12（无需安装）
  config-examples\   注册配置示例
```

## 六、环境变量（可选）

| 变量 | 默认 |
|---|---|
| `IFA_EXE` | `C:\Inovance\iFA Evolution\Bin\iFA.exe` |
| `IFA_HOST_EXE` | `C:\Inovance\iFA Evolution\Bin\Api\FA.OpenApi.Host.exe` |
| `IFA_API_PORT` | 自动发现（9000 起） |
| `IFA_AUTO_START` | `1`（IDE 未启动时自动拉起） |
| `IFA_CALL_TIMEOUT_MS` | `180000` |

## 七、常见问题

- **AI 说连不上**：`ifa_health` 看状态；IDE 启动约 1 分钟；`ifa_restart` 兜底。
- **编译没反应**：传了设备名？改用 `ifa_compile`（自动转 GUID）。
- **扩展服务 UNIMPLEMENTED**：跑一次 `ifa_setup`。
- **工程提示已打开**：先 `ifa_project_close`。

## 八、反馈功能（出问题自动生成，客户不用做任何事）

**出错自动反馈**：任何操作失败时，服务器会自动在 MCP 文件夹根目录生成
**`反馈报告.txt`**（包含：出错工具、调用参数、完整错误堆栈、环境信息、最近日志），
同时 AI 的回复里也会直接带上报告内容。

客户出问题时二选一（都不用提前说话）：

1. **复制 AI 回复里的报告内容**发给你（出错时自动带在回复末尾）；
2. 或直接把 **`C:\ifa-mcp\反馈报告.txt`** 发给你。

> 每次出错报告自动覆盖更新；想看**全部**历史操作日志（不只是出错），
> 可让客户说“生成反馈”读 `logs\反馈日志.txt`（自动轮转，2MB 备份一份）。
