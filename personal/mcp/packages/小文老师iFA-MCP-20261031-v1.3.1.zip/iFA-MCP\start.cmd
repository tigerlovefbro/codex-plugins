@echo off
rem ============================================================
rem  iFA Evolution MCP launcher
rem    --server   : start MCP server (for AI clients)
rem    (no args)  : environment check
rem  Exit codes: 0 = ok, 4 = no Python, 5 = incomplete package
rem ============================================================
setlocal
set "DIR=%~dp0"
set "MODE=CHK"
if "%1"=="--server" set "MODE=SRV"

if not exist "%DIR%mcp_server.py" (
    echo [iFA MCP] missing mcp_server.py - incomplete package.
    exit /b 5
)
if not exist "%DIR%runtime_pkgs\grpc" (
    echo [iFA MCP] missing runtime_pkgs - incomplete package.
    exit /b 5
)

rem ---- find Python 3.8+ ----
set "PYCMD="
if exist "%DIR%runtime\python\python.exe" call :trypypath "%DIR%runtime\python\python.exe"
if defined PYCMD goto :mode_go
where python >nul 2>nul && call :trypy "python"
if defined PYCMD goto :mode_go
where py >nul 2>nul && call :trypy3
if defined PYCMD goto :mode_go
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :trypypath "%%D\python.exe"
if defined PYCMD goto :mode_go
for /d %%D in ("C:\Python3*") do call :trypypath "%%D\python.exe"
if defined PYCMD goto :mode_go
if exist "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" call :trypypath "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if defined PYCMD goto :mode_go
if "%MODE%"=="SRV" (
    echo [iFA MCP] Python 3.8+ not found.
    exit /b 4
)
echo [ERROR] Python 3.8+ not found. Install from https://www.python.org/downloads/
pause
exit /b 4

:mode_go
if "%MODE%"=="SRV" goto :srv_env

rem ================= environment check =================
echo.
echo  iFA Evolution MCP - environment check
echo  ------------------------------------
echo  Targets:
echo    IDE     : C:\Inovance\iFA Evolution\Bin\iFA.exe
echo    APIHost : C:\Inovance\iFA Evolution\Bin\Api\FA.OpenApi.Host.exe
echo    Port    : auto (9000+)
echo.
echo  Ask your AI client: "run ifa_health"
echo.
pause
exit /b 0

rem ================= server mode =================
:srv_env
if not defined IFA_EXE set "IFA_EXE=C:\Inovance\iFA Evolution\Bin\iFA.exe"
if "%PYCMD%"=="py -3" (
    py -3 "%DIR%mcp_server.py"
) else (
    "%PYCMD%" "%DIR%mcp_server.py"
)
exit /b %errorlevel%

:trypy
"%~1" -c "import sys; sys.exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>nul
if not errorlevel 1 set "PYCMD=%~1"
goto :eof

:trypy3
py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>nul
if not errorlevel 1 set "PYCMD=py -3"
goto :eof

:trypypath
if exist "%~1" call :trypy "%~1"
goto :eof
