# -*- coding: utf-8 -*-
"""
iFA Evolution MCP Server
========================
Model Context Protocol (stdio JSON-RPC 2.0) server that operates Inovance
iFA Evolution through its official gRPC Open API.

Architecture:

    AI (MCP client) -> this server (stdio JSON-RPC)
                    -> gRPC client (grpcio)
                    -> iFA Evolution IDE's Open API server (127.0.0.1:9000+)
                    -> Project / DeviceSystem / Logic / View services

The IDE (C:\\Inovance\\iFA Evolution\\Bin\\iFA.exe) hosts the full Open API on a
port starting at 9000 (QuickProServerStartPort). A standalone bootstrap host
(Bin\\Api\\FA.OpenApi.Host.exe, port 5000) can launch the IDE window via
Application.v1.IFaApplicationService/RunAsWindow.

Schema knowledge: schema_dump.json (extracted from the OpenApi assemblies) +
descriptor files in protos/ for typed calls. Every tool also supports raw
field-number based requests, so no operation is blocked by schema gaps.

Environment variables (all optional):
    IFA_EXE               iFA.exe path
    IFA_HOST_EXE          FA.OpenApi.Host.exe path
    IFA_API_PORT          fixed API port (skip auto-discovery)
    IFA_START_TIMEOUT_MS  IDE/API startup wait (default 120000)
    IFA_CALL_TIMEOUT_MS   per-call timeout (default 180000)
    IFA_AUTO_START        "1" (default) auto-start IDE/host when not running
"""
import json
import os
import re
import sys
import io
import time
import struct
import subprocess
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.join(HERE, "runtime_pkgs")
if os.path.isdir(PKG) and PKG not in sys.path:
    sys.path.insert(0, PKG)

try:
    import grpc
    from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
except Exception as _e:
    grpc = None
    descriptor_pool = None
    GRPC_IMPORT_ERR = repr(_e)
else:
    GRPC_IMPORT_ERR = None

SERVER_NAME = "iFA Evolution MCP"
SERVER_VERSION = "1.3.1"

IFA_EXE = os.environ.get("IFA_EXE", r"C:\Inovance\iFA Evolution\Bin\iFA.exe")
IFA_HOST_EXE = os.environ.get("IFA_HOST_EXE", r"C:\Inovance\iFA Evolution\Bin\Api\FA.OpenApi.Host.exe")
IFA_HOST_DIR = os.path.dirname(IFA_HOST_EXE)
START_TIMEOUT_MS = int(os.environ.get("IFA_START_TIMEOUT_MS", "300000"))
CALL_TIMEOUT_MS = int(os.environ.get("IFA_CALL_TIMEOUT_MS", "180000"))
AUTO_START = os.environ.get("IFA_AUTO_START", "1") == "1"
FIXED_PORT = os.environ.get("IFA_API_PORT", "").strip()

SCHEMA_DUMP = os.path.join(HERE, "schema_dump.json")
PROTOS_DIR = os.path.join(HERE, "protos")

# ---------------------------------------------------------------------------
# schema loading
# ---------------------------------------------------------------------------
_schema = None
_pool = None
_factory = None


def load_schema():
    global _schema
    if _schema is not None:
        return _schema
    _schema = {"services": [], "messages": {}, "enums": {}}
    try:
        with io.open(SCHEMA_DUMP, "r", encoding="utf-8") as f:
            _schema = json.load(f)
    except Exception:
        pass
    return _schema


def build_pool():
    """descriptor pool from protos/ (best effort)."""
    global _pool, _factory
    if _pool is not None:
        return _pool
    if descriptor_pool is None:
        return None
    pool = descriptor_pool.DescriptorPool()
    # well-known timestamp
    try:
        from google.protobuf import timestamp_pb2
        ts = descriptor_pb2.FileDescriptorProto()
        ts.ParseFromString(timestamp_pb2.DESCRIPTOR.serialized_pb)
        pool.Add(ts)
    except Exception:
        pass
    files = {}
    if os.path.isdir(PROTOS_DIR):
        for fn in sorted(os.listdir(PROTOS_DIR)):
            if not fn.endswith(".bin"):
                continue
            try:
                raw = open(os.path.join(PROTOS_DIR, fn), "rb").read()
                fd = descriptor_pb2.FileDescriptorProto()
                fd.ParseFromString(raw)
                files[fd.name] = fd
            except Exception:
                continue
    remaining = dict(files)
    while remaining:
        progress = False
        for name in list(remaining):
            try:
                pool.Add(remaining[name])
                del remaining[name]
                progress = True
            except Exception:
                pass
        if not progress:
            break
    _pool = pool
    _factory = message_factory.MessageFactory(pool)
    return pool


def find_type(name):
    pool = build_pool()
    if pool is None:
        return None
    try:
        return pool.FindMessageTypeByName(name)
    except KeyError:
        return None


# ---------------------------------------------------------------------------
# wire encoding/decoding helpers (raw path)
# ---------------------------------------------------------------------------
def enc_varint(v):
    if v < 0:
        v &= (1 << 64) - 1
    out = bytearray()
    while True:
        b = v & 0x7F
        v >>= 7
        if v:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def enc_field(number, wiretype, payload):
    return enc_varint((number << 3) | wiretype) + payload


def enc_value(number, value, schema_field=None, path=""):
    """encode one field from a python value; returns bytes (possibly several
    encodings for repeated)."""
    if value is None:
        return b""
    if isinstance(value, list):
        out = b""
        for item in value:
            out += enc_value(number, item, schema_field, path + "[]")
        return out
    if isinstance(value, dict):
        if "__b64" in value:
            return enc_field(number, 2, _b64d(value["__b64"]))
        if "__hex" in value:
            return enc_field(number, 2, bytes.fromhex(value["__hex"]))
        return enc_field(number, 2, enc_message(value, schema_field, path))
    if isinstance(value, bool):
        return enc_field(number, 0, enc_varint(1 if value else 0))
    if isinstance(value, int):
        # schema: fixed32/fixed64 for sfixed/fixed/float/double types
        wt = 0
        if schema_field is not None:
            t = schema_field.get("type")
            if t in (5,):  # int32
                v = value & 0xFFFFFFFF
                if value < 0:
                    v = value & 0xFFFFFFFF
                return enc_field(number, 0, enc_varint(v))
            if t in (3, 4):  # int64/uint64
                return enc_field(number, 0, enc_varint(value))
        return enc_field(number, 0, enc_varint(value))
    if isinstance(value, float):
        if schema_field is not None and schema_field.get("type") == 2:
            return enc_field(number, 5, struct.pack("<f", value))
        return enc_field(number, 1, struct.pack("<d", value))
    if isinstance(value, str):
        return enc_field(number, 2, enc_varint(len(value.encode("utf-8"))) + value.encode("utf-8"))
    if isinstance(value, bytes):
        return enc_field(number, 2, enc_varint(len(value)) + value)
    return b""


def _b64d(s):
    import base64
    return base64.b64decode(s)


def enc_message(spec, parent_schema=None, path=""):
    """spec: dict of {"1": value, ...} or {"fieldName": value} (schema-resolved)."""
    out = b""
    if not isinstance(spec, dict):
        return out
    fields_map = {}
    if parent_schema:
        for f in parent_schema.get("fields", []):
            fields_map[f["name"]] = f
    for key, value in spec.items():
        if key.startswith("__"):
            continue
        sf = None
        if key.isdigit():
            number = int(key)
            if fields_map:
                for f in fields_map.values():
                    if f["number"] == number:
                        sf = f
                        break
        else:
            if key in fields_map:
                sf = fields_map[key]
                number = sf["number"]
            else:
                raise ValueError("unknown field %r at %s (no schema)" % (key, path or "root"))
        if sf and sf.get("type") == 11 and sf.get("type_name"):
            # resolve nested schema
            nm = sf["type_name"].lstrip(".")
            msgs = load_schema()["messages"]
            if nm in msgs:
                ns = {"name": nm, "fields": msgs[nm]["layout"]["fields"]}
                out += enc_value(number, value, ns, path + "." + key)
                continue
        out += enc_value(number, value, sf, path + "." + key)
    return out


def dec_message(raw, depth=0, schema=None):
    """decode raw bytes to a field-number tree."""
    out = {}
    pos = 0
    n = len(raw)
    while pos < n:
        tag, pos2 = _read_varint(raw, pos)
        if tag is None:
            out["__parse_error"] = "bad varint at %d" % pos
            break
        field = tag >> 3
        wt = tag & 7
        pos = pos2
        key = str(field)
        value = None
        if wt == 0:
            v, pos = _read_varint(raw, pos)
            value = v
        elif wt == 1:
            if pos + 8 > n:
                break
            value = struct.unpack("<d", raw[pos:pos + 8])[0]
            pos += 8
        elif wt == 5:
            if pos + 4 > n:
                break
            value = struct.unpack("<f", raw[pos:pos + 4])[0]
            pos += 4
        elif wt == 2:
            ln, pos = _read_varint(raw, pos)
            if ln is None or pos + ln > n:
                out["__parse_error"] = "truncated at %d" % pos
                break
            payload = raw[pos:pos + ln]
            pos += ln
            # try string (allow CJK and any printable unicode)
            try:
                s = payload.decode("utf-8")
                bad = any((ord(c) < 0x20 and c not in "\r\n\t") or ord(c) == 0x7F
                          for c in s)
                if not bad and len(s) > 0:
                    value = s
            except Exception:
                pass
            if value is None:
                if depth < 6:
                    sub = dec_message(payload, depth + 1)
                    if "__parse_error" not in sub:
                        value = sub
                if value is None:
                    value = {"__hex": payload.hex()}
        else:
            out["__parse_error"] = "wiretype %d at %d" % (wt, pos)
            break
        if key in out:
            if not isinstance(out[key], list):
                out[key] = [out[key]]
            out[key].append(value)
        else:
            out[key] = value
    return out


def _read_varint(b, pos):
    v = 0
    shift = 0
    while pos < len(b):
        x = b[pos]
        pos += 1
        v |= (x & 0x7F) << shift
        if not (x & 0x80):
            return v, pos
        shift += 7
        if shift > 70:
            return None, pos
    return None, pos


# ---------------------------------------------------------------------------
# API connectivity
# ---------------------------------------------------------------------------
_state = {
    "channel": None,
    "port": None,
    "started_host": False,
    "started_ide": False,
    "last_error": "",
    "project_path": "",
}


def proc_exists(exe):
    base = os.path.splitext(os.path.basename(exe))[0].lower()
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq %s" % os.path.basename(exe)],
            shell=True, stderr=subprocess.STDOUT, creationflags=0x08000000)
        return base.encode() in out.lower()
    except Exception:
        return False


def port_listening(port):
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.4)
    try:
        s.connect(("127.0.0.1", port))
        s.close()
        return True
    except Exception:
        return False


def grpc_reachable(port, timeout=3.0):
    if grpc is None:
        return False
    try:
        ch = grpc.insecure_channel("127.0.0.1:%d" % port)
        grpc.channel_ready_future(ch).result(timeout=timeout)
        ch.close()
        return True
    except Exception:
        return False


def raw_call(channel, service, method, payload, timeout=CALL_TIMEOUT_MS / 1000.0):
    path = "/%s/%s" % (service, method)
    return channel.unary_unary(
        path,
        request_serializer=lambda m: m,
        response_deserializer=lambda b: b,
    )(payload, timeout=timeout)


def start_host():
    if _state["started_host"]:
        return
    if os.path.isfile(IFA_HOST_EXE):
        try:
            subprocess.Popen([IFA_HOST_EXE], cwd=IFA_HOST_DIR,
                             creationflags=0x08000000 | 0x00000008)
            _state["started_host"] = True
        except Exception as e:
            _state["last_error"] = "start host: %r" % e


def start_ide():
    if proc_exists(IFA_EXE):
        return
    if os.path.isfile(IFA_EXE):
        try:
            subprocess.Popen([IFA_EXE], creationflags=0x00000008)
            _state["started_ide"] = True
        except Exception as e:
            _state["last_error"] = "start ide: %r" % e


def launch_ide_via_host():
    """use the bootstrap host's RunAsWindow to open the IDE window."""
    start_host()
    for _ in range(20):
        if grpc_reachable(5000, 1.5):
            try:
                ch = grpc.insecure_channel("127.0.0.1:5000")
                raw_call(ch, "Application.v1.IFaApplicationService", "RunAsWindow",
                         b"", timeout=15)
                return True
            except Exception:
                pass
        time.sleep(1.0)
    return False


def _ports_of_process(proc_name):
    """listening TCP ports of a process (best effort)."""
    ports = set()
    try:
        out = subprocess.check_output(
            ["netstat", "-ano", "-p", "tcp"],
            shell=True, stderr=subprocess.STDOUT, creationflags=0x08000000)
        lines = out.decode("gbk", errors="replace").splitlines()
        for line in lines:
            if "LISTENING" not in line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            pid = parts[-1]
            try:
                if pid == str(_proc_pid(proc_name)):
                    addr = parts[1]
                    ports.add(int(addr.rsplit(":", 1)[1]))
            except Exception:
                continue
    except Exception:
        pass
    return ports


_proc_pid_cache = {}


def _proc_pid(proc_name):
    if proc_name in _proc_pid_cache:
        return _proc_pid_cache[proc_name]
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq %s" % proc_name],
            shell=True, stderr=subprocess.STDOUT, creationflags=0x08000000)
        m = re.search(rb"%s\s+(\d+)" % proc_name.encode(), out)
        pid = int(m.group(1)) if m else None
    except Exception:
        pid = None
    _proc_pid_cache[proc_name] = pid
    return pid


def _is_openapi_port(port, timeout=2.0):
    """channel-ready AND the Project service responds (not UNIMPLEMENTED)."""
    if grpc is None:
        return False
    try:
        ch = grpc.insecure_channel("127.0.0.1:%d" % port)
        grpc.channel_ready_future(ch).result(timeout=timeout)
        resp = ch.unary_unary(
            "/Project.v1.IProjectService/HasActiveProject",
            request_serializer=lambda m: m,
            response_deserializer=lambda b: b,
        )(b"", timeout=3)
        ch.close()
        return True
    except Exception:
        return False


def discover_port():
    """find the IDE Open API port: prefer ports owned by iFA.exe that answer
    the Project service; fall back to scanning 9000..9040 with verification."""
    if FIXED_PORT:
        try:
            p = int(FIXED_PORT)
            if _is_openapi_port(p, 2.0):
                return p
        except Exception:
            pass
    _proc_pid_cache.clear()
    owned = _ports_of_process("iFA.exe")
    for port in sorted(owned):
        if _is_openapi_port(port, 1.5):
            return port
    for port in range(9000, 9040):
        if port_listening(port) and _is_openapi_port(port, 1.2):
            return port
    return None


def connect():
    """ensure channel to the IDE API; returns channel or raises."""
    if _state["channel"] is not None:
        return _state["channel"]
    if grpc is None:
        raise RuntimeError("grpcio not available: %s" % GRPC_IMPORT_ERR)
    port = discover_port()
    if port is None and AUTO_START:
        log_event("未发现 API 端口，尝试自动拉起 IDE…")
        launch_ide_via_host()
        start_ide()
        deadline = time.time() + START_TIMEOUT_MS / 1000.0
        while time.time() < deadline:
            port = discover_port()
            if port:
                break
            time.sleep(2.0)
    if port is None:
        log_event("错误: 未找到 iFA Evolution API 端口（IDE 是否在运行？）")
        raise RuntimeError(
            "iFA Evolution API port not found. Start the IDE, or check IFA_AUTO_START.")
    log_event("API 端口发现: %d" % port)
    ch = grpc.insecure_channel("127.0.0.1:%d" % port)
    grpc.channel_ready_future(ch).result(timeout=10)
    _state["channel"] = ch
    _state["port"] = port
    return ch


def reset_channel():
    if _state["channel"] is not None:
        try:
            _state["channel"].close()
        except Exception:
            pass
    _state["channel"] = None
    _state["port"] = None


def call(service, method, spec, schema_msg=None, timeout_ms=None):
    """typed/raw call: spec = dict; returns decoded dict + raw hex."""
    ch = connect()
    if schema_msg is not None:
        # typed path via pool
        pool = build_pool()
        desc = find_type(schema_msg)
        if desc is not None and _factory is not None:
            proto = _factory.GetPrototype(desc) if hasattr(_factory, "GetPrototype") else None
            if proto is None:
                proto = _factory.GetMessageClass(desc)() if hasattr(_factory, "GetMessageClass") else None
            if proto is not None:
                for k, v in (spec or {}).items():
                    setattr(proto, k, v)
                path = "/%s/%s" % (service, method)
                resp = ch.unary_unary(path)(proto, timeout=(timeout_ms or CALL_TIMEOUT_MS) / 1000.0)
                return {"response": json.loads(_msg_to_json(resp)), "__raw": resp.SerializeToString().hex()}
    payload = enc_message(spec or {}, {"fields": []})
    resp = raw_call(ch, service, method, payload,
                    (timeout_ms or CALL_TIMEOUT_MS) / 1000.0)
    return {"response": dec_message(resp), "__raw": resp.hex()}


def _msg_to_json(msg):
    from google.protobuf import json_format
    return json_format.MessageToJson(msg, preserving_proto_field_name=True,
                                     ensure_ascii=False)


# ---------------------------------------------------------------------------
# high-level operations
# ---------------------------------------------------------------------------
def _typed(service, method, msg, spec):
    return call(service, method, spec, schema_msg=msg)


def health():
    ch = _state["channel"]
    if ch is None:
        try:
            ch = connect()
        except Exception as e:
            _state["last_error"] = "connect: %r" % e
    info = {
        "server": SERVER_NAME,
        "version": SERVER_VERSION,
        "grpc_available": grpc is not None,
        "api_port": _state["port"],
        "ide_running": proc_exists(IFA_EXE),
        "host_running": proc_exists(IFA_HOST_EXE),
        "project_active": None,
        "last_error": _state["last_error"],
        "feedback_log": LOG_FILE,
    }
    if ch is not None:
        try:
            r = raw_call(ch, "Project.v1.IProjectService", "HasActiveProject", b"",
                         timeout=10)
            info["project_active"] = dec_message(r)
        except Exception as e:
            info["project_active_error"] = str(e)
    return info


def project_has_active():
    ch = connect()
    r = raw_call(ch, "Project.v1.IProjectService", "HasActiveProject", b"")
    d = dec_message(r)
    return d


def project_open(path):
    ch = connect()
    spec = {"1": path}
    payload = enc_message(spec)
    r = raw_call(ch, "Project.v1.IProjectService", "Open", payload)
    _state["project_path"] = path
    return {"response": dec_message(r), "__raw": r.hex()}


def project_save(path=None):
    ch = connect()
    if not path:
        path = _state.get("project_path", "")
    spec = {"1": path} if path else {}
    payload = enc_message(spec)
    r = raw_call(ch, "Project.v1.IProjectService", "Save", payload,
                 timeout=60)
    return {"response": dec_message(r), "__raw": r.hex()}


def project_close():
    ch = connect()
    path = _state.get("project_path", "")
    payload = enc_message({"1": path}) if path else b""
    r = raw_call(ch, "Project.v1.IProjectService", "CloseProject", payload,
                 timeout=60)
    return {"response": dec_message(r), "__raw": r.hex()}


def project_create(path, name, template=None, device_type=None):
    # CreateProjectRequest fields (from schema dump when available)
    sch = load_schema()["messages"].get("CreateProjectRequest", {}).get("layout")
    spec = {}
    fmap = {f["name"]: f for f in sch.get("fields", [])} if sch else {}
    def setf(name, value):
        f = fmap.get(name)
        if f:
            spec[str(f["number"])] = value
    setf("projectPath", path)
    setf("projectName", name)
    if template:
        setf("template", template)
    if device_type:
        setf("deviceType", device_type)
    if not spec and sch:
        # fallback: fill by number order
        fields = sch.get("fields", [])
        if fields:
            spec[str(fields[0]["number"])] = path
        if len(fields) > 1:
            spec[str(fields[1]["number"])] = name
    ch = connect()
    payload = enc_message(spec, sch)
    r = raw_call(ch, "Project.v1.IProjectService", "CreateStandardProject", payload)
    try:
        d = dec_message(r)
        info = d.get("3") or {}
        p2 = info.get("2")
        if isinstance(p2, str):
            _state["project_path"] = p2
    except Exception:
        pass
    return {"request_spec": spec, "response": dec_message(r), "__raw": r.hex()}


def logic_tree(device_name=None, parent_node_id=""):
    """list logic devices or children nodes."""
    ch = connect()
    if device_name:
        payload = enc_message({"1": device_name})
        r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                     "GetLogicDeviceIdByName", payload)
        d = dec_message(r)
        device_id = d.get("3") or d.get("2") or ""
        payload = enc_message({"1": device_id, "2": parent_node_id})
        r2 = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                      "GetLogicChildrenNodes", payload)
        return {"device": d, "children": dec_message(r2), "__raw": r2.hex()}
    r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService", "GetAllLogicDevices", b"")
    return {"devices": dec_message(r), "__raw": r.hex()}


def logic_read_xml(device_id, node_id):
    ch = connect()
    payload = enc_message({"1": device_id, "2": node_id})
    r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService", "GetNodeItemXml", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


def logic_write_xml(device_id, node_id, xml):
    ch = connect()
    payload = enc_message({"1": device_id, "2": node_id, "3": xml})
    r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                 "UploadNodeItemXmlInfo", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


def logic_read_doc(device_id, node_id):
    ch = connect()
    payload = enc_message({"1": device_id, "2": node_id})
    r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                 "GetNodeDocumentString", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


def logic_write_doc(device_id, node_id, text):
    ch = connect()
    payload = enc_message({"1": device_id, "2": node_id, "3": text})
    r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                 "UploadNodeDocumentString", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


GUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


def resolve_device_id(ch, device_id):
    """map a device name to its GUID via the logic service."""
    if not device_id or GUID_RE.match(device_id):
        return device_id
    try:
        payload = enc_message({"1": device_id})
        r = raw_call(ch, "OpenApiLogic.v1.ILogicDeviceService",
                     "GetLogicDeviceIdByName", payload, timeout=30)
        d = dec_message(r)
        val = d.get("3")
        if isinstance(val, str) and GUID_RE.match(val):
            return val
        if isinstance(val, list):
            for item in val:
                if isinstance(item, dict) and GUID_RE.match(str(item.get("1", ""))):
                    return item["1"]
    except Exception:
        pass
    return device_id


def compile_project(device_id=""):
    ch = connect()
    did = resolve_device_id(ch, device_id)
    payload = enc_message({"1": did}) if did else b""
    r = raw_call(ch, "DeviceSystem.v1.IDeviceSystemService", "Compile", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


def get_messages(device_id=""):
    ch = connect()
    did = resolve_device_id(ch, device_id)
    payload = enc_message({"1": did}) if did else b""
    r = raw_call(ch, "DeviceSystem.v1.IDeviceSystemService", "GetCompileInfo", payload)
    return {"response": dec_message(r), "__raw": r.hex()}


def device_list():
    ch = connect()
    r = raw_call(ch, "DeviceSystem.v1.IDeviceSystemService", "GetAllDeviceInfos", b"")
    return {"response": dec_message(r), "__raw": r.hex()}


def view_tree(device_name=None, parent_node_id=""):
    ch = connect()
    if device_name:
        payload = enc_message({"1": device_name})
        r = raw_call(ch, "OpenApiView.v1.IViewDeviceProtoService",
                     "GetViewDeviceIdByName", payload)
        d = dec_message(r)
        device_id = d.get("3") or ""
        payload = enc_message({"1": device_id, "2": parent_node_id})
        r2 = raw_call(ch, "OpenApiView.v1.IViewDeviceProtoService",
                      "GetViewChildrenNodes", payload)
        return {"device": d, "children": dec_message(r2), "__raw": r2.hex()}
    r = raw_call(ch, "OpenApiView.v1.IViewDeviceProtoService",
                 "GetViewChildrenNodes", b"")
    return {"children": dec_message(r), "__raw": r.hex()}


def generic_call(service, method, request=None, timeout_ms=None):
    ch = connect()
    if request is None:
        request = {}
    if isinstance(request, dict) and request.get("__b64") is not None:
        payload = _b64d(request["__b64"])
    elif isinstance(request, dict) and request.get("__hex") is not None:
        payload = bytes.fromhex(request["__hex"])
    elif isinstance(request, str):
        payload = request.encode("utf-8")
    elif isinstance(request, (bytes, bytearray)):
        payload = bytes(request)
    else:
        # try schema resolution: find message schema by service+method in dump
        sch = None
        for s in load_schema()["services"]:
            if s.get("wire_service") == service or s.get("service") == service:
                for m in s["methods"]:
                    if m["name"] == method:
                        t = m["input"].rsplit(".", 1)[-1]
                        msgs = load_schema()["messages"]
                        if t in msgs:
                            sch = msgs[t]["layout"]
                        break
                break
        payload = enc_message(request, sch)
    resp = raw_call(ch, service, method, payload,
                    (timeout_ms or CALL_TIMEOUT_MS) / 1000.0)
    return {"response": dec_message(resp), "__raw": resp.hex()}


# ---------------------------------------------------------------------------
# MCP protocol
# ---------------------------------------------------------------------------
TOOLS = [
    {"name": "ifa_health",
     "description": "检查 iFA Evolution 与 Open API 状态：IDE 是否运行、API 端口、工程是否打开。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_project_open",
     "description": "在 iFA Evolution 中打开工程（Project.v1.IProjectService/Open）。",
     "inputSchema": {"type": "object",
                     "properties": {"path": {"type": "string", "description": "工程文件路径"}},
                     "required": ["path"]}},
    {"name": "ifa_project_save",
     "description": "保存当前工程（可带路径另存）。",
     "inputSchema": {"type": "object",
                     "properties": {"path": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_project_close",
     "description": "关闭当前工程。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_project_create",
     "description": "创建标准工程（CreateStandardProject）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "path": {"type": "string"},
                         "name": {"type": "string"},
                         "template": {"type": "string"},
                         "device_type": {"type": "string"}},
                     "required": ["path", "name"]}},
    {"name": "ifa_compile",
     "description": "编译工程（DeviceSystem Compile）。",
     "inputSchema": {"type": "object",
                     "properties": {"device_id": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_messages",
     "description": "读取编译/诊断消息列表（GetCompileInfo）。",
     "inputSchema": {"type": "object",
                     "properties": {"device_id": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_logic_tree",
     "description": "列出逻辑设备（PLC）或设备的子节点树。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_name": {"type": "string"},
                         "parent_node_id": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_logic_read_xml",
     "description": "读取逻辑节点的 PLCopen XML 文本（GetNodeItemXml）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_id": {"type": "string"},
                         "node_id": {"type": "string"}},
                     "required": ["device_id", "node_id"]}},
    {"name": "ifa_logic_write_xml",
     "description": "以 PLCopen XML 文本写回逻辑节点（UploadNodeItemXmlInfo）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_id": {"type": "string"},
                         "node_id": {"type": "string"},
                         "xml": {"type": "string"}},
                     "required": ["device_id", "node_id", "xml"]}},
    {"name": "ifa_logic_read_doc",
     "description": "读取逻辑节点的文档/声明文本（GetNodeDocumentString）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_id": {"type": "string"},
                         "node_id": {"type": "string"}},
                     "required": ["device_id", "node_id"]}},
    {"name": "ifa_logic_write_doc",
     "description": "写逻辑节点文档/声明文本（UploadNodeDocumentString）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_id": {"type": "string"},
                         "node_id": {"type": "string"},
                         "text": {"type": "string"}},
                     "required": ["device_id", "node_id", "text"]}},
    {"name": "ifa_device_list",
     "description": "列出工程设备信息（DeviceSystem GetAllDeviceInfos）。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_view_tree",
     "description": "浏览 HMI 视图设备/节点树（IViewDeviceProtoService）。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "device_name": {"type": "string"},
                         "parent_node_id": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_call",
     "description": "通用 Open API 调用：service/method + 请求体。请求体支持 "
                  "JSON 对象（键为字段号字符串如 \"1\"，或字段名），嵌套对象自动编码；"
                  "{\"__b64\": ...} 或 {\"__hex\": ...} 传原始字节。返回解码后的响应树与原始 hex。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "service": {"type": "string", "description": "wire 服务全名，如 OpenApiLogic.v1.ILogicDeviceService"},
                         "method": {"type": "string"},
                         "request": {"type": "object"},
                         "timeout_ms": {"type": "number"}},
                     "required": ["service", "method"]}},
    {"name": "ifa_schema",
     "description": "查询 API 元数据：服务与方法列表、消息字段布局、枚举值。",
     "inputSchema": {"type": "object",
                     "properties": {
                         "service": {"type": "string"},
                         "message": {"type": "string"},
                         "enum": {"type": "string"}},
                     "required": []}},
    {"name": "ifa_restart",
     "description": "重启 iFA Evolution IDE 并重新连接 API。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_setup",
     "description": "一次性环境配置：开启 OpenAPI 扩展服务（备份并修改 iFA.dll.config 的 "
                  "OpenAPIExtension=True）并重启 IDE，使 CreateSTPOUByName/ImportObjectByText/"
                  "ReplaceStPOU 等扩展方法可用。新电脑上部署后先执行一次。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_prepare",
     "description": "用户说「准备开始IFA」「准备开始 iFA」「开始IFA」等触发语时调用："
                  "自动执行一次性环境配置（ifa_setup：开启扩展服务+重启 IDE）和健康检查"
                  "（ifa_health），返回就绪状态与下一步操作建议。新电脑首次使用时必须走这一步。",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "ifa_feedback",
     "description": "生成反馈报告：读取最近的操作日志（含每次工具调用与错误信息），供用户发给"
                  "作者排查问题。用户说「生成反馈」「导出日志」「看看哪里错了」等时调用。",
     "inputSchema": {"type": "object",
                     "properties": {"tail_kb": {"type": "number", "description": "取最近多少 KB，默认 64"}},
                     "required": []}},
]

PROMPT_DEFS = [
    {"name": "prepare_ifa",
     "description": "用户说「准备开始IFA」时触发：一次性初始化 iFA Evolution 环境（配置+重启+体检）。",
     "text": """用户说“准备开始IFA”（或类似表达：准备开始 iFA / 开始IFA / 初始化IFA / 第一次用IFA）时，按以下流程执行：

1. 调用工具 ifa_prepare（它内部自动完成：开启 OpenAPI 扩展服务 → 重启 IDE → 健康检查）；
2. 用中文向用户汇报结果：IDE 是否就绪、API 端口号、工程是否打开；
3. 如果返回里 ide_running 为 false 或 last_error 非空，再调 ifa_restart 然后 ifa_health 重试一次；
4. 全部就绪后告诉用户：“环境就绪，可以开始编程了”，并举一两个例子说明能做什么：
   - “打开工程 XX，写个冒泡排序”；
   - “导一个气缸 FB，在 Main 里实例化调用，编译通过后保存”。"""},
    {"name": "ifa_workflow",
     "description": "使用 iFA Evolution Open API 的标准工作流指引。",
     "text": """在 iFA Evolution 中操作工程的标准流程：
1. ifa_health 确认 IDE 与 API 状态；
2. ifa_project_open 打开目标工程（.project 等工程文件路径）；
3. ifa_device_list 查看设备；ifa_logic_tree 遍历 PLC 节点（先不带参数取设备列表，再用 device_name 取子节点）；
4. 读写程序：ifa_logic_read_xml / ifa_logic_write_xml（PLCopen XML 全文）或 ifa_logic_read_doc / ifa_logic_write_doc（文档文本）；
5. ifa_compile 编译，ifa_messages 查看错误/警告；
6. ifa_project_save 保存，ifa_project_close 关闭；
7. 上述工具覆盖不到的能力，用 ifa_call 直接调用底层 gRPC 方法（先 ifa_schema 查方法签名与消息字段号）。"""},
]

RESOURCES = [
    {"uri": "ifa://inventory", "name": "iFA Evolution Open API 清单",
     "description": "全部 gRPC 服务、方法、输入/输出消息类型（从程序集提取）。",
     "mimeType": "application/json"},
    {"uri": "ifa://schema", "name": "iFA Open API Schema",
     "description": "消息字段布局与枚举常量。",
     "mimeType": "application/json"},
]


def _resp_ok(req_id, result):
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _resp_err(req_id, code, message):
    return {"jsonrpc": "2.0", "id": req_id,
            "error": {"code": code, "message": message}}


def _text_result(text):
    return {"content": [{"type": "text", "text": text}], "isError": False}


def _err_result(text):
    return {"content": [{"type": "text", "text": text}], "isError": True}


# ---------------------------------------------------------------------------
# feedback logging: every tool call (and its errors) is appended to a text
# file in the MCP folder so the customer can send it back for debugging.
# ---------------------------------------------------------------------------
LOG_DIR = os.path.join(HERE, "logs")
LOG_FILE = os.path.join(LOG_DIR, "反馈日志.txt")
LOG_MAX_SIZE = 2 * 1024 * 1024  # rotate at 2 MB
REPORT_FILE = os.path.join(HERE, "反馈报告.txt")


def _log_raw(text):
    try:
        if not os.path.isdir(LOG_DIR):
            os.makedirs(LOG_DIR)
        if os.path.isfile(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_SIZE:
            bak = os.path.join(LOG_DIR, "反馈日志.1.txt")
            try:
                os.replace(LOG_FILE, bak)
            except Exception:
                pass
        with io.open(LOG_FILE, "a", encoding="utf-8-sig") as f:
            f.write(text)
            f.flush()
    except Exception:
        pass


def log_startup():
    import platform
    _log_raw("\n" + "=" * 60 + "\n"
             + "[" + time.strftime("%Y-%m-%d %H:%M:%S") + "] MCP 服务器启动 v"
             + SERVER_VERSION + " | Python " + platform.python_version()
             + " | 系统 " + platform.platform() + "\n"
             + "IFA_EXE: " + IFA_EXE + "\n"
             + "IFA_HOST_EXE: " + IFA_HOST_EXE + "\n"
             + ("GRPC 可用\n" if grpc is not None
                else ("GRPC 不可用: " + str(GRPC_IMPORT_ERR) + "\n"))
             + "=" * 60 + "\n")


def log_tool_call(tname, targs):
    try:
        arg_text = json.dumps(targs, ensure_ascii=False)
        if len(arg_text) > 800:
            arg_text = arg_text[:800] + "...(共%d字符)" % len(arg_text)
    except Exception:
        arg_text = repr(targs)[:800]
    _log_raw("[" + time.strftime("%H:%M:%S") + "] ▶ " + tname + " " + arg_text + "\n")


def log_tool_result(tname, ok, ms, summary="", exc=None):
    mark = "✔" if ok else "✘"
    _log_raw("[" + time.strftime("%H:%M:%S") + "] %s %s (%.1fs)\n" % (mark, tname, ms))
    if not ok and exc:
        _log_raw("    异常: " + exc[:2000] + "\n")
    if summary:
        if len(summary) > 1500:
            summary = summary[:1500] + "...(截断)"
        _log_raw("    " + summary.replace("\n", "\n    ") + "\n")


def log_event(message):
    _log_raw("[" + time.strftime("%H:%M:%S") + "] · " + message + "\n")


def read_feedback(tail_kb=64):
    """return the recent log tail for the ifa_feedback tool."""
    if not os.path.isfile(LOG_FILE):
        return "(尚无日志)"
    try:
        size = os.path.getsize(LOG_FILE)
        read_len = min(size, tail_kb * 1024)
        with io.open(LOG_FILE, "rb") as f:
            f.seek(size - read_len)
            text = f.read().decode("utf-8-sig", errors="replace")
        if size - read_len > 0:
            text = "...(前面省略%d字节)...\n" % (size - read_len) + text
        return text
    except Exception as e:
        return "(读取日志失败: %r)" % e


def tool_schema_lookup():
    return load_schema()


def ifa_setup():
    """one-time environment setup: enable OpenAPIExtension + restart IDE."""
    out = {"config_patched": False, "backup": None, "restart": None, "health": None}
    exe_dir = os.path.dirname(IFA_EXE)
    cfg = os.path.join(exe_dir, "iFA.dll.config")
    if os.path.isfile(cfg):
        try:
            text = io.open(cfg, "r", encoding="utf-8").read()
            if "OpenAPIExtension" in text and 'value="False"' in text:
                bak = cfg + ".bak-mcp"
                if not os.path.isfile(bak):
                    io.open(bak, "w", encoding="utf-8").write(text)
                    out["backup"] = bak
                text = text.replace('<add key="OpenAPIExtension" value="False"/>',
                                    '<add key="OpenAPIExtension" value="True"/>')
                io.open(cfg, "w", encoding="utf-8").write(text)
                out["config_patched"] = True
            elif "OpenAPIExtension" in text:
                out["config_patched"] = "already-enabled"
            else:
                out["config_patched"] = "key-not-found"
        except Exception as e:
            out["config_error"] = repr(e)
    else:
        out["config_error"] = "iFA.dll.config not found at " + cfg
    # restart IDE to apply
    try:
        reset_channel()
        try:
            subprocess.call(["taskkill", "/F", "/IM", "iFA.exe"],
                            creationflags=0x08000000)
        except Exception:
            pass
        time.sleep(2)
        if AUTO_START:
            launch_ide_via_host()
            start_ide()
            connect()
        out["restart"] = "ok"
    except Exception as e:
        out["restart"] = "failed: %r" % e
    try:
        out["health"] = health()
    except Exception as e:
        out["health"] = "failed: %r" % e
    return out


def handle_tool(name, args):
    args = args or {}
    if name == "ifa_health":
        return _text_result(json.dumps(health(), ensure_ascii=False, indent=1))
    if name == "ifa_project_open":
        return _text_result(json.dumps(project_open(args["path"]), ensure_ascii=False, indent=1))
    if name == "ifa_project_save":
        return _text_result(json.dumps(project_save(args.get("path")), ensure_ascii=False, indent=1))
    if name == "ifa_project_close":
        return _text_result(json.dumps(project_close(), ensure_ascii=False, indent=1))
    if name == "ifa_project_create":
        return _text_result(json.dumps(project_create(
            args.get("path", ""), args.get("name", ""),
            args.get("template"), args.get("device_type")),
            ensure_ascii=False, indent=1))
    if name == "ifa_compile":
        return _text_result(json.dumps(compile_project(args.get("device_id", "")),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_messages":
        return _text_result(json.dumps(get_messages(args.get("device_id", "")),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_logic_tree":
        return _text_result(json.dumps(logic_tree(args.get("device_name"),
                                                  args.get("parent_node_id", "")),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_logic_read_xml":
        return _text_result(json.dumps(logic_read_xml(args["device_id"], args["node_id"]),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_logic_write_xml":
        return _text_result(json.dumps(logic_write_xml(args["device_id"], args["node_id"], args["xml"]),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_logic_read_doc":
        return _text_result(json.dumps(logic_read_doc(args["device_id"], args["node_id"]),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_logic_write_doc":
        return _text_result(json.dumps(logic_write_doc(args["device_id"], args["node_id"], args["text"]),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_device_list":
        return _text_result(json.dumps(device_list(), ensure_ascii=False, indent=1))
    if name == "ifa_view_tree":
        return _text_result(json.dumps(view_tree(args.get("device_name"),
                                                 args.get("parent_node_id", "")),
                                       ensure_ascii=False, indent=1))
    if name == "ifa_call":
        return _text_result(json.dumps(generic_call(
            args["service"], args["method"], args.get("request"),
            args.get("timeout_ms")), ensure_ascii=False, indent=1))
    if name == "ifa_schema":
        s = load_schema()
        out = {}
        if args.get("service"):
            for svc in s["services"]:
                if args["service"] in (svc.get("wire_service"), svc.get("service")):
                    out = svc
                    break
            if not out:
                out = {"error": "service not found",
                       "services": [x.get("wire_service") for x in s["services"]]}
        elif args.get("message"):
            m = s["messages"].get(args["message"])
            out = m if m else {"error": "message not found",
                               "known": sorted(s["messages"])[:200]}
        elif args.get("enum"):
            e = s["enums"].get(args["enum"])
            out = e if e else {"error": "enum not found", "known": sorted(s["enums"])}
        else:
            out = {"services": [
                {"service": x.get("wire_service"), "methods": len(x["methods"])}
                for x in s["services"]],
                "message_count": len(s["messages"]),
                "enum_count": len(s["enums"])}
        return _text_result(json.dumps(out, ensure_ascii=False, indent=1))
    if name == "ifa_restart":
        reset_channel()
        try:
            subprocess.call(["taskkill", "/F", "/IM", "iFA.exe"],
                            creationflags=0x08000000)
        except Exception:
            pass
        time.sleep(2)
        if AUTO_START:
            launch_ide_via_host()
            start_ide()
        try:
            connect()
            return _text_result(json.dumps(health(), ensure_ascii=False, indent=1))
        except Exception as e:
            return _err_result("restart failed: %r" % e)
    if name == "ifa_setup":
        return _text_result(json.dumps(ifa_setup(), ensure_ascii=False, indent=1))
    if name == "ifa_prepare":
        out = {"setup": None, "health": None, "next": ""}
        try:
            out["setup"] = ifa_setup()
        except Exception as e:
            out["setup"] = {"error": repr(e)}
        try:
            out["health"] = health()
        except Exception as e:
            out["health"] = {"error": repr(e)}
        h = out.get("health") or {}
        if h.get("ide_running") and not h.get("last_error") and h.get("api_port"):
            out["ready"] = True
            out["next"] = ("环境就绪，可以开始编程了。例如：打开工程写程序（冒泡排序/气缸FB 等）、"
                           "编译下载。需要帮助直接说需求即可。")
        else:
            out["ready"] = False
            out["next"] = ("环境还未就绪：若 IDE 未运行或端口未发现，可用 ifa_restart 重启 IDE "
                           "后再 ifa_health 确认。")
        return _text_result(json.dumps(out, ensure_ascii=False, indent=1))
    if name == "ifa_feedback":
        try:
            kb = int(args.get("tail_kb") or 64)
        except Exception:
            kb = 64
        log_text = read_feedback(kb)
        out = {"log_file": LOG_FILE,
               "提示": ("把上面日志内容或文件夹里的「反馈日志.txt」发给作者即可。"
                        "日志记录了每次操作与错误，会自动按 2MB 轮转备份。"),
               "日志": log_text}
        return _text_result(json.dumps(out, ensure_ascii=False, indent=1))
    return _err_result("unknown tool: %s" % name)


def write_error_report(tname, targs, error_text):
    """auto-generate a customer-ready feedback report on every tool error."""
    try:
        arg_text = json.dumps(targs, ensure_ascii=False)
        if len(arg_text) > 1200:
            arg_text = arg_text[:1200] + "...(截断)"
    except Exception:
        arg_text = repr(targs)[:1200]
    parts = []
    parts.append("=" * 60)
    parts.append("iFA Evolution MCP 反馈报告（自动生成）")
    parts.append("生成时间: " + time.strftime("%Y-%m-%d %H:%M:%S"))
    parts.append("服务器版本: " + SERVER_VERSION)
    parts.append("出错工具: " + tname)
    parts.append("调用参数: " + arg_text)
    parts.append("错误信息:")
    parts.append(error_text[:6000])
    parts.append("环境信息: IDE运行=" + str(proc_exists(IFA_EXE))
                 + " API端口=" + str(_state["port"])
                 + " IFA_EXE=" + IFA_EXE)
    parts.append("最近日志:")
    parts.append(read_feedback(16))
    parts.append("=" * 60)
    parts.append("把本文件（或上面全部内容）发给作者即可，作者会据此排查修复。")
    parts.append("每次出错本文件自动覆盖更新；完整历史日志见 logs\\反馈日志.txt。")
    text = "\n".join(parts) + "\n"
    try:
        with io.open(REPORT_FILE, "w", encoding="utf-8-sig") as f:
            f.write(text)
    except Exception:
        pass
    log_event("反馈报告已自动生成: %s" % REPORT_FILE)
    return text


def _with_feedback(res, tname, targs):
    """if the tool result is an error, attach the auto-generated report."""
    if not res.get("isError"):
        return res
    content = res.get("content") or []
    err_text = str(content[0].get("text", "")) if content else ""
    report = write_error_report(tname, targs, err_text)
    res["content"] = [{
        "type": "text",
        "text": err_text + "\n\n" + "【反馈已自动生成】文件: " + REPORT_FILE
                + "\n请把此文件（或以下报告内容）发给作者：\n" + report,
    }]
    return res


def main():
    log_startup()
    stdin = getattr(sys.stdin, "buffer", sys.stdin)
    stdout = getattr(sys.stdout, "buffer", sys.stdout)

    def send(obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        stdout.write(data + b"\n")
        stdout.flush()

    init_done = False
    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line.decode("utf-8"))
        except Exception:
            continue
        method = req.get("method")
        rid = req.get("id")
        params = req.get("params") or {}
        if method == "initialize":
            send(_resp_ok(rid, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}, "resources": {}, "prompts": {}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            }))
            init_done = True
        elif method == "notifications/initialized":
            pass
        elif method == "ping":
            send(_resp_ok(rid, {}))
        elif method == "tools/list":
            send(_resp_ok(rid, {"tools": TOOLS}))
        elif method == "tools/call":
            tname = params.get("name", "")
            targs = params.get("arguments") or {}
            log_tool_call(tname, targs)
            t0 = time.time()
            try:
                res = handle_tool(tname, targs)
                is_err = bool(res.get("isError"))
                content = res.get("content") or []
                summary = ""
                if is_err and content:
                    summary = str(content[0].get("text", ""))
                elif content:
                    text = str(content[0].get("text", ""))
                    summary = (text[:400] + ("...(截断)" if len(text) > 400 else ""))
                log_tool_result(tname, not is_err, time.time() - t0, summary)
                if is_err:
                    res = _with_feedback(res, tname, targs)
            except Exception as e:
                exc = traceback.format_exc()
                log_tool_result(tname, False, time.time() - t0, "", exc=exc)
                res = _err_result("tool error: %r\n%s" % (e, exc))
                res = _with_feedback(res, tname, targs)
            send(_resp_ok(rid, res))
        elif method == "resources/list":
            send(_resp_ok(rid, {"resources": RESOURCES}))
        elif method == "resources/read":
            uri = params.get("uri", "")
            try:
                if uri == "ifa://inventory":
                    text = open(SCHEMA_DUMP, "r", encoding="utf-8").read()
                elif uri == "ifa://schema":
                    text = open(SCHEMA_DUMP, "r", encoding="utf-8").read()
                else:
                    text = "unknown resource"
                send(_resp_ok(rid, {"contents": [
                    {"uri": uri, "mimeType": "application/json", "text": text}]}))
            except Exception as e:
                send(_resp_err(rid, -32603, "resource error: %r" % e))
        elif method == "prompts/list":
            send(_resp_ok(rid, {"prompts": [
                {"name": p["name"], "description": p["description"]}
                for p in PROMPT_DEFS]}))
        elif method == "prompts/get":
            pn = params.get("name", "")
            p = next((x for x in PROMPT_DEFS if x["name"] == pn), None)
            if p:
                send(_resp_ok(rid, {"description": p["description"], "messages": [
                    {"role": "user", "content": {"type": "text", "text": p["text"]}}]}))
            else:
                send(_resp_err(rid, -32602, "unknown prompt"))
        elif method == "shutdown":
            send(_resp_ok(rid, None))
            break
        else:
            send(_resp_err(rid, -32601, "unknown method: %s" % method))


if __name__ == "__main__":
    main()
